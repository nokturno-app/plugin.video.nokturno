"""Nokturno — video doplněk pro Kodi (Luna: Absolute Cinema + Sosáč + WebShare).

Zdroje (každý jde vypnout v nastavení):
- Luna: server v LAN, TMDB katalogy + streamy z WebShare přes Lunu
- Sosáč: vlastní katalogy a streamy (Stremio API, jen userId)
- WebShare přímo: hledání souborů a stream přes WebShare API (účet), bez Luny
Hledání prochází zapnuté zdroje; stejný titul z Luny a Sosáče je jen jednou
(Sosáč se přibalí jako `alt`), streamy se dohledají v druhém zdroji.
Do profilu doplňku se ukládá historie hledání, zhlédnuto/rozkoukáno (zapisuje
`service.py`), Můj seznam, snímky titulů pro Pokračovat a fronta stahování.
"""
import base64
import json
import logging
import os
import random
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
import struct
import sys
import threading
import time
import traceback
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zlib

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# Pozor na `reuselanguageinvoker` v addon.xml: tělo tohohle souboru se spouští při
# každém kliknutí znovu, ale `sys.path` patří interpretu a ten zůstává. Bez téhle
# podmínky by cesta přibývala při každém kliknutí donekonečna.
_LIB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)
# Import, který selže ve chvíli, kdy složka doplňku chybí (odinstalace nebo aktualizace
# za běhu interpretu), si Python zapamatuje jako `None` v `path_importer_cache` a složku
# pak přeskakuje navždy — líné importy níž (`remote_setup`, `qr`, `transfer`) pak padaly
# i po přeinstalaci (pád b9a7106a46c5, 8.6.1).
sys.path_importer_cache.pop(_LIB, None)
from luna_api import (LunaApi, LunaError, diagnose as luna_diagnose,  # noqa: E402
                      discover as luna_discover, parse_base_url, parse_token)
from cinemeta_api import CinemetaApi, CinemetaError  # noqa: E402
from tmdb_api import TmdbApi, TmdbError  # noqa: E402
from trend_api import CATALOG_ID as TREND_CATALOG_ID, TrendApi  # noqa: E402
from dash_api import DashApi
from opensubtitles_api import OpenSubtitlesApi  # noqa: E402
from sosac_api import SosacError, is_sosac_id as _is_stremio_sosac_id  # noqa: E402
from sosac_direct import EXPORT as SOSAC_EXPORT, SosacDirect, is_direct_id  # noqa: E402
from enrich import add_ratings, enrich, enrich_one, shutdown_pool as release_enrich  # noqa: E402
import foryou  # noqa: E402
import catindex  # noqa: E402
import concertcat  # noqa: E402
import mycat  # noqa: E402
import usage  # noqa: E402
import servers  # noqa: E402
from hellspy_api import HellspyApi, HellspyError  # noqa: E402
from sledujteto_api import SledujtetoApi, SledujtetoError  # noqa: E402
from fastshare_api import FastshareApi, FastshareError  # noqa: E402
from cztor_api import CztorApi, CztorError  # noqa: E402
from prehrajto_api import PrehrajtoApi, PrehrajtoError  # noqa: E402
from storage_api import SLOTS as STORAGE_SLOTS, StorageError, open_storage, parse_ref  # noqa: E402
from accounts import (FAIL as ACC_FAIL, OFF as ACC_OFF, OK as ACC_OK,  # noqa: E402
                      WARN as ACC_WARN, problems as accounts_problems,
                      PAUSE_CHOICES, pause as accounts_pause,
                      paused as accounts_paused, paused_for as accounts_paused_for)
from store import WATCHED_MAX, Store, migrate_profile  # noqa: E402
from source_errors import describe_failure, summarize as summarize_failures  # noqa: E402
from sync import sync_once  # noqa: E402
import kodi_settings  # noqa: E402
import watch as watch_lib  # noqa: E402
import setsync  # noqa: E402
import favprune  # noqa: E402
import syncbox  # noqa: E402
from streams import estimate_rank, langs_from_name, parse_stream, subs_from_name, video_tags  # noqa: E402
from tracks import FILE_CODES, SUBTITLE_FALLBACK, decode_subtitle, subtitle_format, subtitle_lang  # noqa: E402
from trakt_api import TraktApi, TraktError, pick_keys  # noqa: E402
from webshare_api import SORTS, WebshareApi, WebshareError, human_size  # noqa: E402
import kodi_marks  # noqa: E402 – vedle default.py, ne kopie jádra (čte videodatabázi Kodi)
import kodi_smb  # noqa: E402 – vedle default.py, SMB vlastního úložiště přes xbmcvfs
import mylist  # noqa: E402 – vedle default.py, vlastní seznam z JSON
import kodi_sources  # noqa: E402 – vedle default.py, sdílený výčet zdrojů do statistik
from engine import AUDIO_PROBE_MAX, DEFAULT_RUNTIME_S, Engine, NokturnoError, release_probe_pool, runtime_minutes  # noqa: E402
from abort import Aborted, SparePool, cancel_background, set_host_stop  # noqa: E402
from hedge import first_success  # noqa: E402
import keepalive  # noqa: E402
from crash import CrashReporter  # noqa: E402

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


# Líné importy. `remote_setup` táhne `http.server`, `qr` skládá PNG a `transfer`
# s `sealbox` kryptografii — dohromady jde o nejtěžší část importů a potřebují je jen
# tři obrazovky nastavení, ne menu, výpisy ani přehrání. `import` uvnitř funkce je po
# prvním volání jen vyhledání v `sys.modules`, takže se to nevyplatí obcházet cachí.
def _qr():
    import qr
    return qr


def _remote_setup():
    import remote_setup
    return remote_setup


def _transfer_core():
    # jmenuje se takhle, aby se `transfer_*` funkce níž nepotkaly jménem s modulem
    import transfer
    return transfer


class _KodiLogHandler(logging.Handler):
    """Varování z knihovny (např. `store.py`: selhaný zápis souboru) do kodi.log —
    bez toho by je Python jen tiše pustil na stderr, kam se v Kodi nikdo nedívá."""
    nokturno = True   # značka pro `_install_log_handler()`, `isinstance` tu nefunguje

    def emit(self, record):
        level = xbmc.LOGERROR if record.levelno >= logging.ERROR else xbmc.LOGWARNING
        xbmc.log(f"[{ADDON_ID}/{record.name}] {self.format(record)}", level)


def _install_log_handler():
    """Přidá handler jen jednou za život interpretu. S `reuselanguageinvoker` se tenhle
    soubor spouští znovu při každém kliknutí, ale kořenový logger je v modulu `logging`,
    který zůstává — bez téhle kontroly by se po deseti kliknutích každé varování
    zapsalo do kodi.log desetkrát.

    Poznávat handler přes `isinstance` tu NEJDE: každé spuštění vyrobí novou třídu
    `_KodiLogHandler`, takže handler z minula je instancí jiné třídy téhož jména.
    Proto značka atributem."""
    koren = logging.getLogger()
    if not any(getattr(h, "nokturno", False) for h in koren.handlers):
        koren.addHandler(_KodiLogHandler())
    koren.setLevel(logging.WARNING)


_install_log_handler()

# Kodi při `Application.Quit` (nebo když uživatel opustí načítající se složku) čeká,
# až skript doběhne — a dlouhé smyčky jádra dřív běžely dál, dokud neskončily samy
# (Office 2026-09-16: vypnutí přes 2 minuty, zahřívání cache ze služby prohledávalo
# zdroje po titulech). Monitor vzniká hned při importu, ne až při prvním dotazu, ať
# nepropásne požadavek, který přišel dřív. `CANCEL` drží, že se už jednou zjistilo, že Kodi
# končí (modální zrušení hledání `cancelable_search` odstraněno v `5.2.14~beta2`).
MONITOR = xbmc.Monitor()
CANCEL = threading.Event()
QUIT_PROP = "nokturno.quitting"   # stejný literál jako v service.py — služba zachytila System.OnQuit
QUIT_POLL = 0.5                   # s – vlastnost okna se nečte při každé kontrole (vlákna zdrojů se ptají často)
_quit_checked = [0.0]


def should_stop():
    """`should_stop` pro jádro (`Engine`, `StorageApi`, `SosacDirect` — viz `lib/abort.py`):
    Kodi končí, nebo uživatel zrušil hledání dialogem. Jádro pak vyhodí `Aborted`,
    router ji chytí a handle zavře bez hlášky.

    `MONITOR.abortRequested()` sám nestačí: plugin spuštěný přes JSON-RPC (zahřívání
    ze služby, HA) ho při `Application.Quit` uvidí až po zastavení síťových služeb,
    a ty čekají právě na něj (Office 2026-09-16: 37 s, s HTTP dotazem 202 s). Služba
    proto na `System.OnQuit` nastaví `QUIT_PROP` (`service.ServiceMonitor`)."""
    if CANCEL.is_set():
        return True
    if MONITOR.abortRequested():
        CANCEL.set()
        return True
    now = time.time()
    if now - _quit_checked[0] >= QUIT_POLL:
        _quit_checked[0] = now
        if xbmcgui.Window(10000).getProperty(QUIT_PROP):
            CANCEL.set()
            return True
    return False


SEARCH_PROP = "nokturno.searching"   # plugin: uživatel čeká na hledání streamů (čas, kdy začalo)
SEARCH_ACTIVE_S = 120                # starší vlastnost je pozůstatek po pádu, ne běžící hledání
SEARCH_GATE_S = 90                   # nejdéle tolik čeká práce na pozadí na konec hledání


def search_active():
    """Čeká právě teď někdo (kterýkoli proces doplňku) na hledání streamů?"""
    try:
        since = float(xbmcgui.Window(10000).getProperty(SEARCH_PROP) or 0)
    except ValueError:
        return False
    return time.time() - since < SEARCH_ACTIVE_S


def wait_for_foreground_search(limit=SEARCH_GATE_S):
    """Práce na pozadí (prefetch dalšího dílu, kontrola Hlídaných, obnova seznamu streamů)
    počká, až skončí hledání, na které uživatel čeká — jinak se oba procesy dělí o linku
    a hlavně o limity zdrojů (Přehraj.to a HellSpy omezují dotazy na adresu, rozestup mezi
    nimi ale drží každý proces zvlášť). Jádro to volá přes `Engine.gate`, jen z vlákna
    označeného `Engine.background()`."""
    end = time.time() + limit
    while search_active() and time.time() < end:
        if should_stop():
            return
        MONITOR.waitForAbort(1)
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
# výpis otevřený přes „Další“ (`paged=1`): stránka nahradí předchozí v historii Kodi
UPDATE_LISTING = False
ICON = ADDON.getAddonInfo("icon")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PAGE = 20
WS_PAGE = 40
HS_PAGE = 40
CACHE_TTL = 600
# Luna: katalogy i meta se drží déle než obecných 10 min — zahřívání na pozadí běží
# každé 2,5 h a s 10min TTL zahřívalo do prázdna (menu bylo studené 10 min po každém warm-upu)
LUNA_TTL = 4 * 3600
WARM_PROP = "nokturno.warm"   # služba ji nastaví během zahřívání: API cache jen zapisují, nečtou
SEARCH_TTL = 12 * 3600  # sjednocené s luna_api.SEARCH_TTL / webshare_api.SEARCH_TTL
ACCOUNTS_TRIGGER_PROP = "nokturno.accounts_trigger"   # stejný literál jako v service.py — žádost o obnovu
                                                      # stavu zdrojů hned, viz refresh_accounts_after_test
# „Pro tebe" — doporučení k naposledy zhlédnutým titulům (TMDB `recommendations`,
# bez vlastního klíče přes dashboard `/similar`). Žádné hledání ve zdrojích, jen TMDB,
# a detaily titulů má 30denní cache sdílená se všemi katalogy. Na pozadí se zahřívá jen typ,
# který uživatel za posledních `FORYOU_SEEN_DAYS` dní otevřel (audit 2026-09-19, nález 12).
FORYOU_TTL = 24 * 3600
FORYOU_SEEN_KEY = "foryou_seen"
FORYOU_SEEN_DAYS = 14
# Ověřované vlastní katalogy (`mycat`) mají trvalý index ověřený na pozadí; menu čte jen index.
VERIFY_TRIGGER_PROP = "nokturno.verify.trigger"   # menu s prázdným indexem popožene službu; hodnota = id katalogu
VERIFY_MANUAL_PROP = "nokturno.verify.manual"     # „cíl:počet“; stejný literál jako v service.py
FIRST_BATCH_SIZE = mycat.FIRST_BATCH        # první dávka po uložení ověřovaného katalogu (nebo nastavení koncertů)
MANUAL_BATCH_SIZE = mycat.MANUAL_BATCH      # ruční „Načíst teď“ ověří víc titulů než automatická dávka služby
# O kolik dřív než vyprší cache ji zahřívání přepočítá — musí být aspoň interval
# zahřívání (`service.WARM_EVERY`, 2,5 h), jinak kolo jen přečte platnou cache a nechá
# ji vypršet mezi dvěma koly (6.2.2 nález 29).
FORYOU_REFRESH_AFTER = FORYOU_TTL - 3 * 3600
FORYOU_DOWN_KEY = "nokturno:foryou:down"   # značka výpadku, vzor `trend_api.DOWN_KEY`
FORYOU_DOWN_TTL = 300
FORYOU_STALE_TTL = 14 * 86400   # jak staré doporučení se ještě ukáže, když TMDB neodpoví
FORYOU_PAGES = 5   # z kolika stránek katalogu se losuje „Náhodný film" (víc = pestřejší)
RANDOM_CANDIDATES = 8   # kolik titulů se u „Náhodného filmu" ověřuje na preferovaný jazyk
RANDOM_BUDGET_S = 15.0  # na celé ověřování; pak se vezme cokoli (lepší titul bez CZ než čekání)
RANDOM_WORKERS = 4
SOSAC_TAG = "[COLOR FFE0A040]Sosáč[/COLOR]"
HS_TAG = "[COLOR FFFF8A6B]HellSpy[/COLOR]"
ST_TAG = "[COLOR FF4DD0C0]Sledujteto[/COLOR]"
FS_TAG = "[COLOR FFF2C14E]FastShare[/COLOR]"
SDILEJ_TAG = "[COLOR FFF2C14E]Sdilej.cz[/COLOR]"   # týž katalog jako FastShare, účet ze Sdilej.cz
PT_TAG = "[COLOR FF9AD5FF]Přehraj.to[/COLOR]"
CZ_TAG = "[COLOR FFFF6FB5]CZtor[/COLOR]"
WS_TAG = "[COLOR FF60B0FF]WebShare[/COLOR]"
DAV_COLOR = "FFB0E57C"
DAV_TAG = f"[COLOR {DAV_COLOR}]{ADDON.getLocalizedString(30405) or 'Úložiště'}[/COLOR]"
LUNA_TAG = "[COLOR FFB39DFF]Luna[/COLOR]"
SOURCE_TAGS = {"main": LUNA_TAG, "search": WS_TAG, "sosac": SOSAC_TAG, "ws": WS_TAG, "hs": HS_TAG, "st": ST_TAG,
               "fs": FS_TAG, "pt": PT_TAG, "cz": CZ_TAG, "dav": DAV_TAG}


def source_tag(src):
    """Štítek zdroje ve výpisu; s účtem ze Sdilej.cz se FastShare jmenuje Sdilej.cz."""
    if src in ("fs", "fastshare") and fs_provider() == "sdilej":
        return SDILEJ_TAG
    return SOURCE_TAGS.get(src, "")


QUALITY_COLORS = {4: "FFE06A60", 3.5: "FFB284E0", 3: "FF6FD18A", 2: "FF6FB6F0", 1: "FFA0A0A0"}
# krátce, ať zbyde místo na zbytek řádku: „Full HD" se v úzkém sloupci nevyplatí
QUALITY_NAMES = {4: "4K", 3.5: "2K", 3: "FHD", 2: "HD", 1: "SD"}
LANG_COLORS = {"CZ": "FF7FE07F", "SK": "FF7FE07F", "EN": "FF9A9A9A"}
# EN a jazyky bez vlastní barvy dostanou stejný odstín jako GREY (níž) —
# FFE0E0E0 (skoro bílá) na vybrané položce s bílým podkladem úplně mizelo
GREY = "FF9A9A9A"
WARN_COLOR = "FFE0A040"   # neověřená shoda z ručního fulltextu (viz stream_label)
# databáze filmů (Luna/Cinemeta) vrací žánry anglicky, Sosáč rovnou česky —
# do popisu titulu patří vždy česky, neznámý žánr necháme, jak přišel
GENRES_CS = {
    "Action": "Akční", "Adventure": "Dobrodružný", "Animation": "Animovaný", "Biography": "Životopisný",
    "Comedy": "Komedie", "Crime": "Krimi", "Documentary": "Dokument", "Drama": "Drama", "Family": "Rodinný",
    "Fantasy": "Fantasy", "History": "Historický", "Horror": "Horor", "Music": "Hudební", "Musical": "Muzikál",
    "Mystery": "Mysteriózní", "Romance": "Romantický", "Sci-Fi": "Sci-fi", "Short": "Krátkometrážní",
    "Sport": "Sportovní", "Thriller": "Thriller", "War": "Válečný", "Western": "Western",
    "Action & Adventure": "Akční a dobrodružný", "Kids": "Dětský", "Reality": "Reality show",
    "Sci-Fi & Fantasy": "Sci-fi a fantasy", "War & Politics": "Válečný a politický",
}
PLAYING_PROP = "nokturno.playing"
VIEWED_PROP = "nokturno.viewed"   # služba si odsud bere „u titulu se zobrazily streamy“ pro statistiky
SYNC_PROP = "nokturno.sync"      # plugin → služba: synchronizuj hned, ne až za pět minut
FORCE_STATS_PROP = "nokturno.force_stats"   # plugin → služba: aktualizace doplňku, nečekat na SEND_EVERY
USED_PROP = "nokturno.used"    # služba si odsud bere „doplněk byl otevřen“ pro statistiky
PREF_LANGS = ("", "CZ", "SK", "EN", "HU")
STREAM_ORDERS = ("source", "quality", "size_desc", "size_asc")

# přechod z ID plugin.video.luna: data i nastavení ze starého profilu
_old_settings = migrate_profile(PROFILE)
if _old_settings:
    try:
        import xml.etree.ElementTree as _ET
        for el in _ET.parse(_old_settings).getroot().iter("setting"):
            if el.get("id") and (el.text or "") != "":
                ADDON.setSetting(el.get("id"), el.text)
    except Exception as _e:  # noqa: BLE001
        xbmc.log(f"[{ADDON_ID}] migrace nastavení: {_e}", xbmc.LOGWARNING)
STORE = Store(PROFILE)
Errors = (LunaError, CinemetaError, TmdbError, SosacError, WebshareError, HellspyError, SledujtetoError, FastshareError, CztorError,
          TraktError, StorageError, NokturnoError)

# Tvar dat v cache API (`Store.cached()`). Zvednout jen když se změní, co se do cache
# ukládá nebo jak se čte (nové pole v odpovědi, jiný klíč, jiná struktura) — staré záznamy
# by jinak přežily klidně týdny, než by je vytlačilo přirozené vypršení TTL. Do 6.1.4 se
# cache mazala při KAŽDÉ nové verzi doplňku: každá oprava textů tak celé instalaci
# vyhasila katalogy, streamy i metadata a první otevření po aktualizaci bylo studené
# (a zdroje včetně TMDB dostaly od všech instalací naráz vlnu dotazů).
CACHE_FORMAT = "6.1.4"
_ADDON_VERSION = ADDON.getAddonInfo("version")


def migrate_on_start():
    """Při startu pluginu: cache smazat jen při změně `CACHE_FORMAT`; při každé nové verzi
    doplňku (i downgradu) jen říct službě, ať s dalším statistickým hlášením nečeká až
    SEND_EVERY (6 h) — případná zpráva z dashboardu (odpověď na nahlášený log) se tak
    ukáže co nejdřív po aktualizaci, ne až za pár hodin."""
    if STORE.load("cache_version", "") != CACHE_FORMAT:
        STORE.clear_cache()
        STORE.save("cache_version", CACHE_FORMAT)
    if STORE.load("seen_version", "") != _ADDON_VERSION:
        STORE.save("seen_version", _ADDON_VERSION)
        xbmcgui.Window(10000).setProperty(FORCE_STATS_PROP, "1")


def info_install():
    """Tlačítko v kategorii Info: verze doplňku a anonymní id instalace.

    Kategorie Info nemá jediný obyčejný text: `<control type="label">` Kodi 21
    v nastavení doplňku odmítne (`error reading <control> tag`) a přeskočí celou
    kategorii, `title` se nevykreslí vůbec a zašedlý `edit` byl na TV nečitelný.
    Pevné hodnoty (web, fóra) proto nese rovnou popisek tlačítka; verze a id se
    do popisku napsat nedají, ukazuje je tenhle dialog."""
    xbmcgui.Dialog().textviewer(L(30432, "Info"),
                                "%s: %s[CR]%s: %s" % (L(30703, "Verze"), _ADDON_VERSION,
                                                      L(30695, "ID této instalace"), install_id() or "–"))


def install_id():
    """Anonymní id instalace ze statistik. Ukazuje se v Info, aby ho uživatel
    mohl uvést při hlášení problému — podle něj se v dashboardu najde jeho
    odeslaný log i hlášení o pádu.

    `Stats` se importuje až tady: na úrovni modulu v `default.py` není (drží se
    líně kvůli startu pluginu) a globální odkaz by tiše spadl na `NameError`
    — což se v betě 8 opravdu stalo a řádek v Info zůstal prázdný."""
    try:
        from stats import Stats
        return Stats(PROFILE).data["id"]
    except Exception:      # noqa: BLE001 – profil bez statistik nesmí shodit start
        return ""


# Zachyceno PŘED migrate_on_start(), který "seen_version" přepíše na aktuální verzi —
# nenulová a jiná než _ADDON_VERSION znamená, že tahle instalace už běžela dřív.
_PRIOR_SEEN_VERSION = STORE.load("seen_version", "")

migrate_on_start()

# Zvednout jen při věcné změně právního upozornění (ne u překlepu) — starší souhlas
# pak přestane platit a uživatel ho musí znovu potvrdit.
TERMS_VERSION = "3"

# Verze, se kterou právní upozornění vůbec poprvé vyšlo do stabilního vydání — jen ona
# se grandfatherí (viz `_existing_install`). Nikdy neměnit zpětně: i kdyby se text ještě
# před stabilním vydáním znovu upravil (další zvednutí TERMS_VERSION), tahle konstanta
# zůstává ukotvená na první verzi, aby ji grandfathering nesledoval navěky.
FIRST_TERMS_VERSION = "2"


# akce, které brána souhlasu pustí vždy: vedou k samotnému odsouhlasení
TERMS_FREE = ("info_terms", "settings")


def terms_accepted():
    """Souhlas drží **přepínač v nastavení** (kategorie Podmínky použití, `terms_ok`) — uživatel ho
    musí vidět a umět vzít zpět. Verze odsouhlaseného textu zůstává v profilu, protože
    v `settings.xml` by z ní bylo další pole navíc; zaškrtnutí platí vždy pro aktuální
    `TERMS_VERSION` a zapíše se při prvním přečtení."""
    if ADDON.getSetting("terms_ok") != "true":
        if STORE.load("terms_accepted", ""):
            STORE.save("terms_accepted", "")   # vzatý zpět; jinak by ho migrace zase zapnula
        return False
    if STORE.load("terms_accepted", "") != TERMS_VERSION:
        STORE.save("terms_accepted", TERMS_VERSION)
    return True


def migrate_terms():
    """Souhlas se z profilu (bety `7.6.0~beta1`–`~beta3`) překlopí do přepínače a starší
    instalace se odsouhlasí sama (`_existing_install`). Opačným směrem: po věcné změně
    textu (vyšší `TERMS_VERSION`) se přepínač vypne, aby ho uživatel potvrdil znovu.

    Běží **jednou za verzi textu** (značka `terms_migrated`). Bez toho by uložený souhlas
    v profilu zapínal přepínač po každém kliknutí, takže ruční vypnutí by nikdy nedrželo
    a doplněk by hledal dál."""
    if STORE.load("terms_migrated", "") == TERMS_VERSION:
        return
    STORE.save("terms_migrated", TERMS_VERSION)
    ulozena = STORE.load("terms_accepted", "")
    if ADDON.getSetting("terms_ok") == "true":
        if ulozena and ulozena != TERMS_VERSION:
            ADDON.setSetting("terms_ok", "false")
        return
    if ulozena == TERMS_VERSION or _existing_install():
        STORE.save("terms_accepted", TERMS_VERSION)
        ADDON.setSetting("terms_ok", "true")


LUNA_DEFAULT_URL = "http://192.168.1.10:7126"


def migrate_luna_default():
    """Od 8.4.0~beta9 je Luna ve výchozím stavu vypnutá (dřív zapnutá i s výchozí
    adresou `192.168.1.10`, takže stav zdrojů hlásil „Luna nedostupná" každému, kdo
    ji nikdy nenastavil). Kdo ji ale opravdu používá (token nebo vlastní adresa),
    ji musí mít zapnutou dál.

    Rozhoduje značka `default="true"` v profilovém settings.xml: ta říká, že
    uživatel přepínač nikdy nezměnil a jel na staré výchozí hodnotě. Výslovně
    vypnutou Lunu (hodnota bez značky) nechá být. Běží jednou (`luna_default_migrated`) —
    po změně výchozí hodnoty nese značku i vědomé vypnutí a to se nesmí přepsat."""
    if STORE.load("luna_default_migrated", ""):
        return
    STORE.save("luna_default_migrated", "1")
    try:
        with open(os.path.join(PROFILE, "settings.xml"), encoding="utf-8") as f:
            ulozeno = f.read()
    except (IOError, OSError):
        return    # čerstvá instalace
    if not re.search(r'<setting id="luna_enabled" default="true">', ulozeno):
        return
    url = setting("luna_url").strip()
    if setting("token").strip() or (url and url != LUNA_DEFAULT_URL):
        ADDON.setSetting("luna_enabled", "true")


THIRD_PARTY_DEFAULT_ON = ("pt_enabled", "sosac_enabled", "hs_enabled")


def migrate_third_party_default():
    """Od 10.4.1 jsou úložiště třetích stran ve výchozím stavu vypnutá – zapne je jen uživatel sám
    (dřív Přehraj.to, Sosáč a HellSpy zapnuté rovnou). Existující instalace o ně nesmí přijít:
    nezměněný přepínač (značka `default="true"`, jako v `migrate_luna_default`) nebo přepínač, který
    v uloženém nastavení ještě není, se zapíše natvrdo jako zapnutý. Bez profilového settings.xml
    rozhoduje dřívější verze (`_PRIOR_SEEN_VERSION`): čerstvá instalace zůstane bez nich. Běží jednou."""
    if STORE.load("third_party_default_migrated", ""):
        return
    STORE.save("third_party_default_migrated", "1")
    try:
        with open(os.path.join(PROFILE, "settings.xml"), encoding="utf-8") as f:
            ulozeno = f.read()
    except (IOError, OSError):
        ulozeno = None
    if ulozeno is None and not _PRIOR_SEEN_VERSION:
        return    # čerstvá instalace
    for sid in THIRD_PARTY_DEFAULT_ON:
        if ulozeno is None or '<setting id="%s" default="true">' % sid in ulozeno \
                or '<setting id="%s"' % sid not in ulozeno:
            ADDON.setSetting(sid, "true")


def _existing_install():
    """Instalace, která běžela už před zavedením právního upozornění, se bere jako
    automaticky odsouhlasená — nikdo starý nemusí nic doklikávat. Platí jen pro
    `FIRST_TERMS_VERSION`: případná další věcná změna textu (zvednutí verze nad rámec
    prvního vydání) tenhle grandfathering neobchází, souhlas se pak musí znovu potvrdit
    i od existující instalace."""
    return TERMS_VERSION == FIRST_TERMS_VERSION and bool(_PRIOR_SEEN_VERSION) and _PRIOR_SEEN_VERSION != _ADDON_VERSION


# Podmínky použití verze 3 (kanon texty-2026-09-26/kanon/podminky-v3.md), anglicky jako záloha
TERMS_EN = "[B]Nokturno terms of use[/B]\nVersion 3 · effective from 30 September 2026\n\n[B]1. What Nokturno is[/B]\nNokturno is an add-on for Kodi and Home Assistant. It is a player and search tool for your own storage (for example WebDAV) and for the storage services and catalogues of third parties that you enable in the settings (WebShare, Sosáč, HellSpy, Sledujteto, FastShare / Sdilej.cz, Přehraj.to, CZtor, Luna). It searches for subtitles on OpenSubtitles. You decide which sources you use. Nokturno is free, without ads and without paid features.\n\n[B]2. How searching works[/B]\nNokturno asks the enabled sources for a title's name or identifier and shows the files they return. The files are stored on the servers of those services, were uploaded by their users, and your player downloads them directly from there. Nokturno does not host or distribute any film, series or other work.\n\nNokturno does not verify the legal status of individual files. It does not check who uploaded a file or whether they had the rightsholder's consent. A file appearing in the results does not mean you may legally play it.\n\nSearching runs on your device with your accounts. The Nokturno server does not search for files. It provides title information (catalogues, TV guide, recommendations), keys for the interfaces of title-information and subtitle services, and synchronisation between your devices.\n\n[B]3. What you may and may not do[/B]\n- Use Nokturno only for content you have the right to – your own recordings, freely licensed works, and content you hold a licence or other legal title to. Playing or downloading a copyrighted work without the rightsholder's consent is prohibited.\n- Do not use Nokturno to infringe the rights of others or to distribute content you have no right to.\n- When you connect a third-party service, its terms apply to you as well. Nokturno gives you no rights to the content of those services.\n- Do not share your source accounts with other people unless the source's terms allow it.\n- Do not send automated requests to the Nokturno server, do not get around limits or blocks, and do not offer access through Nokturno as a paid service.\n\n[B]4. Reporting content and blocking[/B]\nOnly the service that stores a file can actually delete it. We therefore recommend that rightsholders report it there directly (contacts are at the end).\n\nYou can also report it to us. What a notice must contain and how we handle it is described at nokturno.stream/abuse; send it to abuse@nokturno.stream. We reply to a complete notice and block the title or file in Nokturno's results within 48 hours. The block reaches the add-on with a list from the server, older versions after they are updated.\n\n[B]5. No warranty and limitation of liability[/B]\nWe provide Nokturno \"as is\", free of charge and with no warranty of functionality, availability or of what third-party sources contain. You are responsible for what you play and download with Nokturno.\n\nTo the extent permitted by law, we are not liable for damage arising from using Nokturno or from being unable to use it, for the content, availability and terms of third-party services, or for how you use Nokturno. Liability that cannot be excluded by law is not affected.\n\nWe may restrict or end access to the server at any time, especially if these terms are breached.\n\n[B]6. Personal data[/B]\nWhich data Nokturno sends, why, how long we keep it and how to ask for its deletion is described at nokturno.stream/privacy.\n\n[B]7. Governing law[/B]\nThese terms are governed by the law of the Czech Republic. If you are a consumer habitually resident in another country, you keep the protection the law of that country gives you.\n\n[B]8. Changes to these terms[/B]\nEvery version has a number and a date. We will announce significant changes in the add-on, and Kodi and Home Assistant will ask for your consent again.\n\n[B]9. Contacts[/B]\n- reporting content: abuse@nokturno.stream (procedure at nokturno.stream/abuse)\n- personal data: privacy@nokturno.stream\n- everything else: kontakt@nokturno.stream\n- help with the add-on: the help pages and Discord (not for legal matters)"
TERMS_SOURCES_EN = "[B]Reporting directly to the source[/B]\n- WebShare – abuse@webshare.cz\n- Sosáč / Streamuj.tv – streamuj.tv/advertise (DMCA)\n- HellSpy – hellspy.to/contact\n- Sledujteto – sledujteto.cz/nahlasit-nelegalni-soubor\n- FastShare – fastshare.cz/abuse\n- Sdilej.cz – abuse@sdilej.cz\n- Přehraj.to – prehrajto.cz/nahlasit-nelegalni-soubor\n- CZtor – contact via cztor.com/kontakt\n- OpenSubtitles – copyright@opensubtitles.org (DMCA)"


def terms_text():
    return L(30729, TERMS_EN) + "\n\n" + L(30734, TERMS_SOURCES_EN)


def info_terms():
    """Tlačítko v kategorii Info: plný text právního upozornění, kdykoli k nahlédnutí."""
    xbmcgui.Dialog().textviewer(L(30728, "Legal notice"), terms_text())


def ensure_terms():
    """Musí proběhnout dřív, než plugin cokoli vyhledá nebo přehraje. Bez souhlasu se
    v menu Nokturna ukáže text a otázka Souhlasím / Nesouhlasím, odjinud — z widgetu
    nebo JSON-RPC — jen oznámení: modál v cestě, kterou nikdo neklikl, by zasekl
    přehrávání i vypínání Kodi (viz CLAUDE.md). Souhlas tak jde dát jen v menu nebo
    v nastavení, spuštěním z widgetu ho obejít nelze.

    Dřív dialog otevíral nastavení a spoléhal, že přepínač je první kategorie; od 7.6.1
    je poslední, takže ho uživatel po aktualizaci nenašel a menu se neotevřelo
    (log uživatele 2026-09-23). Proto se souhlas ukládá rovnou jako v průvodci."""
    if terms_accepted():
        return True
    if not browsing_nokturno():
        notify(L(30733, "First accept the legal notice in the Nokturno menu."), xbmcgui.NOTIFICATION_WARNING, 6000)
        return False
    dialog = xbmcgui.Dialog()
    dialog.textviewer(L(30728, "Legal notice"), terms_text())
    if not dialog.yesno(L(30728, "Legal notice"),
                        L(30749, "Do you agree to the terms of use above?"),
                        yeslabel=L(30748, "I agree"), nolabel=L(30732, "I don't agree")):
        return False
    ADDON.setSetting("terms_ok", "true")
    return terms_accepted()


def note_foryou_open(ctype):
    """Zapamatuje, že uživatel otevřel „Pro tebe" — podle toho se rozhoduje, jestli
    má služba seznam zahřívat na pozadí (viz `service.foryou_warm_urls`)."""
    with STORE.updating(FORYOU_SEEN_KEY, {}) as seen:
        seen[str(ctype)] = int(time.time())


def foryou_wanted(ctype, days=FORYOU_SEEN_DAYS):
    """Otevřel uživatel „Pro tebe" za posledních `days` dní?"""
    kdy = (STORE.load(FORYOU_SEEN_KEY, {}) or {}).get(str(ctype)) or 0
    return bool(kdy) and time.time() - kdy < days * 86400


def is_sosac_id(item_id):
    """Sosáč napřímo (`sosacd_…`) i starší Stremio režim (`sosac2_…`)."""
    return is_direct_id(item_id) or _is_stremio_sosac_id(item_id)


def L(sid, fallback=""):
    """Nové řetězce se z strings.po načtou až po restartu Kodi — proto záloha v kódu."""
    return ADDON.getLocalizedString(sid) or fallback


def Lf(sid, *args):
    """Lokalizovaný řetězec s %s; když překlad zástupný symbol nemá, jen připojí hodnoty."""
    text = L(sid)
    try:
        return text % args if "%" in text else " ".join([text] + [str(a) for a in args])
    except TypeError:
        return " ".join([text] + [str(a) for a in args])


def setting(key, default=""):
    return ADDON.getSetting(key) or default


def on(key, default="true"):
    return setting(key, default) != "false"


def build_url(**params):
    return BASE_URL + "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v not in (None, "")})


def runplugin(**params):
    return f"RunPlugin({build_url(**params)})"


# --- zdroje ---------------------------------------------------------------------

def warming():
    """Běží zahřívání cache ze služby? Pak se API cache jen zapisují, ne čtou — jinak
    zahřátí s TTL rovným intervalu jen ověřilo, že cache je čerstvá, a nic neobnovilo."""
    return xbmcgui.Window(10000).getProperty(WARM_PROP) == "1"


def get_luna():
    if not on("luna_enabled"):
        return None
    raw_token = setting("token")
    token = parse_token(raw_token)
    if not token:
        return None
    base = parse_base_url(raw_token, setting("luna_url", LUNA_DEFAULT_URL))
    return LunaApi(base, token, cache=STORE, cache_ttl=LUNA_TTL, fresh=warming())


def get_sosac():
    if not on("sosac_enabled", "false"):
        return None
    # veřejné JSONy Sosáče + streamuj.tv s účtem Streamuj. Starší cesta přes
    # Stremio rozhraní Sosáče (userId, login k Sosáči) je pryč — katalogy jsou
    # ve veřejných exportech a k přehrání stačí Streamuj.
    su, sp = setting("streamuj_username").strip(), setting("streamuj_password").strip()
    if su and sp:
        return SosacDirect(su, sp, cache=STORE, cache_ttl=CACHE_TTL, index_store=STORE.index(), fresh=warming(),
                           should_stop=should_stop)
    return None


def get_sosac_db():
    """Veřejný katalog Sosáče (žádný účet, žádný přepínač) — vlastní databáze
    filmů a seriálů česky, funguje vždy. `apis["sosac"]` výš zůstává jen pro
    přihlášené přehrávání a stahování; katalog samotný účet nepotřebuje."""
    return SosacDirect(cache=STORE, cache_ttl=CACHE_TTL, index_store=STORE.index(), fresh=warming(),
                       should_stop=should_stop)


def expand_streams(apis, streams, meta, video):
    """„Zobrazit všechny streamy“: sloučené verze zvlášť. Schované verze nemají přečtené
    hlavičky — dočtou se (nejvýš `PROBE_DEADLINE`), ukazatel v rohu jako při hledání."""
    bar = xbmcgui.DialogProgressBG()
    bar.create(L(30000, "Nokturno"), L(30238, "Načítám streamy…"))
    try:
        return engine_of(apis).expand_streams(
            streams, (meta, video), on_audio_progress=lambda done, total: bar.update(int(done * 100 / max(total, 1))))
    finally:
        bar.close()


def alts_param(stream):
    """Náhradní odkazy sloučené verze (`_alts`) do adresy přehrání — viz `resolve_first`."""
    return "|".join(a["url"] for a in stream.get("_alts") or [] if a.get("url")) or None


# Kolik streamů se při přehrání zkusí, než to doplněk vzdá. Zdroj umí selhat celý —
# vyčerpaný kredit FastShare, vypršelý účet, výpadek — a do 7.6.1 tím spadlo celé
# přehrání, i když tentýž film ležel na dalších zdrojích (log uživatele 2026-09-22:
# 11 nalezených streamů, vybraný a jeho jediná sloučená kopie obě z FastShare
# s kreditem 0 MB → „FastShare: na soubor 7.6 GB nestačí kredit“ a konec). Strop je
# tu proto, že každý pokus je dotaz do zdroje: u opravdu mrtvého se jinak čeká na
# tolik timeoutů, kolik je streamů.
PLAY_FALLBACKS = 5


def version_urls(stream):
    """Odkazy téže verze souboru: stream a jeho sloučené kopie (v pořadí `play_candidates`)."""
    out = []
    for s in [stream] + list(stream.get("_alts") or []):
        url = s.get("url")
        if url and url not in out:
            out.append(url)
    return out


def play_candidates(chosen, streams, limit=PLAY_FALLBACKS):
    """Dvojice (odkaz, stream) k přehrání v pořadí: zvolený stream, jeho sloučené
    kopie, pak ostatní nálezy i s jejich kopiemi. Stream u odkazu je ten, ze kterého
    se po úspěchu berou titulky a jazyky — u sloučené kopie je to ona, ne rodič."""
    poradi, videne = [], set()

    def pridat(stream):
        for s in [stream] + list(stream.get("_alts") or []):
            url = s.get("url")
            if url and url not in videne:
                videne.add(url)
                poradi.append((url, s))

    pridat(chosen)
    for s in streams or []:
        if len(poradi) >= limit:
            break
        if s is not chosen:
            pridat(s)
    return poradi[:max(limit, 1)]


def url_scheme(url):
    """Zdroj odkazu (`ws`, `hs`, `fs`, …) — klíč do statistik a pravidlo pro souběžné pokusy."""
    return re.sub(r"[^a-z0-9]", "", (url or "").split(":", 1)[0].lower())[:12] or "x"


def hedge_group(urls, same):
    """Kolik prvních odkazů smí běžet souběžně: jen z `same` prvních (tatáž verze souboru)
    a jen z různých zdrojů — dvě rozklíčování téhož zdroje najednou by si šlapala na účet
    a token (WebShare)."""
    seen = []
    for url in urls[:same]:
        scheme = url_scheme(url)
        if scheme in seen:
            break
        seen.append(scheme)
    return len(seen)


def resolve_first(apis, urls, same=1):
    """Rozklíčovat první odkaz, který jde — sloučené verze jsou tentýž film jinde. Vrátí
    (reference, odkaz); když nejde žádný, vyhodí chybu toho prvního.

    `same` = kolik prvních odkazů je tatáž verze souboru (vybraný stream a jeho sloučené kopie).
    Loudá-li se první déle než pár vteřin (zdroj neodpovídá), rozklíčuje se souběžně i další
    z nich a bere se, co přijde dřív (`hedge.first_success`). Jiná verze se zkouší až po selhání.

    Do statistik jde nejvýš jedno selhání na přehrání: jen za vybraný (první) odkaz.
    Záložní pokusy (`play_candidates`, až 5) by jinak jedno přehrání s vadným účtem
    započítaly několikrát."""
    urls = list(urls)
    if not urls:
        raise NokturnoError(L(30102))

    def failed(i, url, err):
        if i == 0:
            usage.count(STORE, "play_fail:" + url_scheme(url))
        xbmc.log(f"[{ADDON_ID}] stream nejde přehrát, zkouším další verzi: {err}", xbmc.LOGINFO)
    used, link = first_success(urls, lambda url: resolve_url(apis, url), group=hedge_group(urls, same),
                               errors=Errors, on_fail=failed)
    usage.count(STORE, "play_ok:" + url_scheme(used))
    return used, link


def resolve_url(apis, url):
    """'streamuj:…' (Sosáč), 'ws:<ident>' (WebShare), 'hs:', 'st:' a 'dav:' se mění na
    finální odkaz až při přehrání — odkazy zdrojů vyprší po pár hodinách. Rozklíčování
    dělá jádro (`Engine.resolve`); tady navíc přežije token WebShare mezi voláními."""
    if url and url.startswith("streamuj:") and not isinstance(apis.get("sosac"), SosacDirect):
        # Sosáč v nastavení vypnutý, ale účet Streamuj vyplněný — rozkoukaný titul z dřívějška
        return SosacDirect(setting("streamuj_username"), setting("streamuj_password"), cache=STORE).resolve(url)
    engine = engine_of(apis)
    link = engine.resolve(url)
    if url and url.startswith("ws:"):
        remember_ws_token(engine.ws)
    return link


def get_webshare():
    if not on("ws_enabled", "false"):
        return None
    user, pw = setting("ws_username").strip(), setting("ws_password").strip()
    if not user or not pw:
        return None
    # token WebShare přežije mezi voláními pluginu – šetří login
    return WebshareApi(user, pw, token=xbmcgui.Window(10000).getProperty("nokturno.ws_token"), cache=STORE)


def get_hellspy():
    """HellSpy nemá účet ani token — stačí přepínač v nastavení."""
    if not on("hs_enabled", "false"):
        return None
    return HellspyApi(cache=STORE)


def get_sledujteto():
    """Sledujteto — přihlášený účet. Token si klient drží v úložišti doplňku,
    heslo se posílá jen při přihlášení. Přehrávat jde jen s Premium."""
    if not on("st_enabled", "false"):
        return None
    email, pw = setting("st_email").strip(), setting("st_password")
    if not email or not pw:
        return None
    return SledujtetoApi(email, pw, cache=STORE)


def fs_provider():
    """Účet ke katalogu FastShare: 0 = fastshare.cz, 1 = sdilej.cz (týž katalog, jiný účet)."""
    return "sdilej" if setting("fs_provider") == "1" else "fastshare"


def get_fastshare():
    """FastShare — jméno a heslo. Hledá se bez přihlášení, k přehrání se přihlásí
    a soubor jde z kreditu účtu (nebo neomezeného tarifu)."""
    if not on("fs_enabled", "false"):
        return None
    user, pw = setting("fs_username").strip(), setting("fs_password")
    if not user or not pw:
        return None
    return FastshareApi(user, pw, cache=STORE, provider=fs_provider())


def get_prehrajto():
    """Přehraj.to — stačí přepínač. Účet je nepovinný: bez něj je vidět jen první
    strana hledání a hraje se překódovaný soubor, s Premium účtem původní."""
    if not on("pt_enabled", "false"):
        return None
    return PrehrajtoApi(setting("pt_email").strip(), setting("pt_password"), cache=STORE)


def cztor_client():
    """Klient CZtor i bez spárování — pro párování a stav účtu. Tokeny drží úložiště
    doplňku, takže je vidí plugin i služba (obnovovací token se použitím mění)."""
    name = xbmc.getInfoLabel("System.FriendlyName") or "Kodi"
    return CztorApi(STORE, device_name=f"Nokturno ({name})")


def get_cztor():
    """CZtor — jen zapnutý a spárovaný. Heslo účtu doplněk nikdy nevidí (párování PINem)."""
    if not on("cz_enabled", "false"):
        return None
    api = cztor_client()
    return api if api.paired() else None


def get_storages():
    """Vlastní úložiště z nastavení (až tři). Síť se tu nevolá — seznam souborů
    se načte až při prvním hledání a hodinu se pamatuje (`storage_api.INDEX_TTL`)."""
    out = []
    for slot in range(1, STORAGE_SLOTS + 1):
        url = setting(f"dav{slot}_url").strip()
        if not url or setting(f"dav{slot}_enabled") == "false":   # vypnuté = jako nevyplněné, údaje zůstávají
            continue
        try:
            out.append(open_storage(url, setting(f"dav{slot}_username"), setting(f"dav{slot}_password"),
                                    setting(f"dav{slot}_name"), slot=slot, cache=STORE, should_stop=should_stop,
                                    backend=kodi_smb.KodiSmbBackend))
        except StorageError as e:
            log_error(f"úložiště {slot}: {e}")
    return out


def storage_for(apis, url):
    """`dav:<slot>:<cesta>` → (úložiště, cesta); server se bere z nastavení, ne z odkazu."""
    slot, path = parse_ref(url)
    api = next((s for s in apis.get("dav") or [] if s.slot == slot), None)
    if api is None:
        raise StorageError(L(30104))
    return api, path


def remember_ws_token(api):
    if api and api.token:
        xbmcgui.Window(10000).setProperty("nokturno.ws_token", api.token)


def get_trakt():
    if not on("trakt_enabled", "false"):
        return None
    cid, sec = pick_keys(setting("trakt_client_id"), setting("trakt_client_secret"), get_dash())
    return TraktApi(cid, sec, tokens=STORE.trakt(), on_tokens=STORE.set_trakt)


def get_cinemeta():
    """Vlastní databáze filmů a seriálů (Stremio/Cinemeta) — bez účtu, funguje vždy,
    i když Luna nebo Sosáč nejsou dostupné. Katalog i hledání se na ni spolehnou,
    kdykoli hlavní zdroj chybí (viz `_search_merge`, `main_menu`)."""
    return CinemetaApi(cache=STORE)


def get_trend():
    """Žebříček z vlastních statistik Nokturna (dashboard) — na rozdíl od ostatních
    zdrojů výš nepotřebuje účet ani klíč, funguje vždycky stejně jako Cinemeta."""
    return TrendApi(cache=STORE)


def get_dash():
    """Obsah řízený dashboardem (katalogy, podobné tituly, TV program) — bez účtu,
    s krátkým timeoutem a zálohou z cache, výpadek dashboardu menu nezdrží. S vlastním klíčem
    TMDB se vlastní katalogy berou přímo z TMDB a server je jen záloha."""
    return DashApi(cache=STORE, tmdb=get_tmdb())


# Vykoupení z věznice Shawshank: titulek k němu na OpenSubtitles je vždycky,
# takže prázdná odpověď znamená vadný klíč, ne titul bez titulků
OS_PROBE_ID = "tt0111161"


def get_opensubtitles():
    """Titulky z OpenSubtitles — záchrana pro tituly, které je ve zdrojích nemají.

    Klíč k API si uživatel nezakládá: rozdává ho dashboard (`/os-key`, cache týden),
    protože do repozitáře nesmí a proxovat dotazy přes server nejde — denní kvóta
    stahování se u OpenSubtitles počítá na IP toho, kdo stahuje. Bez klíče (dashboard
    nedostupný, nebo ho nemá nastavený) se zdroj tiše vynechá a titulky se berou jen
    ze souboru a z WebShare jako dřív.

    Jméno a heslo jsou dobrovolná — bez nich platí pět stažených titulků na IP za den,
    s účtem dvacet. Heslo jde jen do `/login`, ukládá se z něj jen vydaný token.
    """
    if not on("os_enabled"):
        return None
    key = get_dash().opensubtitles_key()
    if not key:
        return None
    return OpenSubtitlesApi(key, store=STORE, username=setting("os_username"),
                            password=setting("os_password"),
                            user_agent="Nokturno v%s" % _ADDON_VERSION)


def get_tmdb():
    """Vlastní klíč uživatele (zdarma, viz nápověda v nastavení) — přednostní
    náhrada za veřejný katalog Sosáče/Cinemetu, když Luna neběží: umí česky
    i to, co ony ne (popis, obsazení). Bez klíče se prostě nepoužije."""
    key = setting("tmdb_api_key").strip()
    return TmdbApi(key, cache=STORE) if key else None


def engine_options():
    """Nastavení doplňku ve tvaru, kterému rozumí jádro: výběry z indexu na hodnotu,
    přepínače na bool, účty jen když je zdroj zapnutý (klienty ale staví `KodiEngine`
    z `get_*()` výš, tady jsou hlavně předvolby řazení a chování)."""
    return {
        "pref_lang": PREF_LANGS[int(setting("pref_lang", "0"))],
        "sort_streams": STREAM_ORDERS[int(setting("sort_streams", "0"))],
        "hide_sd": on("hide_sd", "false"),
        "hide_3d": on("hide_3d", "false"),
        "hide_dv": on("hide_dv", "false"),
        "hide_dv_only": on("hide_dv_only", "false"),
        "hide_hdr": on("hide_hdr", "false"),
        "hide_av1": on("hide_av1", "false"),
        "hide_lowq": on("hide_lowq", "true"),
        "pref_surround": on("pref_surround", "false"),
        "max_bitrate_mbps": setting("max_bitrate_mbps", "0"),
        "audio_probe": setting("audio_probe", str(AUDIO_PROBE_MAX)),
        "cross_search": on("cross_search"),
        "search_streams": on("search_streams"),
        "merge_streams": True,   # verze, mezi kterými se nevybírá, jako jeden řádek (`group_streams`)
        "probe_background": True,   # hlavičky nad limit a sloučených verzí dočíst na pozadí do cache
        # seznam streamů starší než 72 h (do 14 dní) ukázat hned a obnovit na pozadí — otevření
        # titulu po pár dnech tak nestojí 7–20 s hledání napříč zdroji
        "stale_streams": True,
        "fresh": warming(),
        # Adresa má výchozí hodnotu, takže je vyplněná i u vypnuté Luny — bez
        # `luna_enabled` by stav zdrojů hlásil „běží, ale chybí token" každému,
        # kdo zdroj nikdy nezapnul.
        "luna_enabled": on("luna_enabled"),
        "luna_url": setting("luna_url", LUNA_DEFAULT_URL),
        # Kodi drží token Luny pod klíčem `token`, jádro ho zná jako `luna_token`.
        # Klienty si KodiEngine staví z `get_*()`, takže do 6.3.1 tenhle klíč jádro
        # vůbec nepotřebovalo — stav zdrojů podle něj ale pozná „Luna bez tokenu"
        # a bez něj hlásil chybějící token i u správně nastavené Luny.
        "luna_token": setting("token") if on("luna_enabled") else "",
        "cz_enabled": on("cz_enabled", "false"),
        "ws_username": setting("ws_username") if on("ws_enabled", "false") else "",
        "st_email": setting("st_email") if on("st_enabled", "false") else "",
        "fs_username": setting("fs_username") if on("fs_enabled", "false") else "",
        "fs_provider": fs_provider(),
        # jádro si podle e-mailu pozná účet (stránkování a původní soubor) — heslo
        # sem nepatří, klienta si staví `get_prehrajto()`
        "pt_enabled": on("pt_enabled", "false"),
        "pt_email": setting("pt_email").strip() if on("pt_enabled", "false") else "",
        "hs_enabled": on("hs_enabled", "false"),
        "tmdb_api_key": setting("tmdb_api_key"),
        # klíč Last.fm pro katalogy koncertů (`mycat.refresh_concert` ho čte přes `_opt`)
        "lastfm_key": setting("lastfm_key").strip(),
    }


class KodiEngine(Engine):
    """Sdílené jádro nad nastavením doplňku.

    Klienty zdrojů staví z `get_luna()` a spol., ne z holých voleb jako HA a Stremio:
    Kodi má u každého zdroje přepínač, zahřívání na pozadí (`warming()` → cache jen
    zapisovat), delší TTL Luny a token WebShare v okně mezi voláními pluginu. Hledání
    streamů, párování duplicit, čtení hlaviček, dotazy pro fulltext i rozklíčování
    odkazů jsou už jen v jádru — dřív to samé leželo podruhé tady v `default.py`.
    """

    FACTORIES = {"luna": get_luna, "sosac": get_sosac, "sosac_db": get_sosac_db, "ws": get_webshare,
                 "hs": get_hellspy, "st": get_sledujteto, "fs": get_fastshare, "pt": get_prehrajto, "cz": get_cztor, "storages": get_storages, "tmdb": get_tmdb,
                 "cinemeta": get_cinemeta, "trend": get_trend, "dash": get_dash,
                 "osub": get_opensubtitles}

    def __init__(self):
        self._clients = {}
        super().__init__(engine_options(), PROFILE, store=STORE, should_stop=should_stop)
        self.gate = wait_for_foreground_search

    def _client(self, name):
        if name not in self._clients:
            self._clients[name] = self.FACTORIES[name]()
        return self._clients[name]

    luna = property(lambda self: self._client("luna"))
    sosac = property(lambda self: self._client("sosac"))
    sosac_db = property(lambda self: self._client("sosac_db"))
    ws = property(lambda self: self._client("ws"))
    osub = property(lambda self: self._client("osub"))
    hs = property(lambda self: self._client("hs"))
    st = property(lambda self: self._client("st"))
    fs = property(lambda self: self._client("fs"))
    pt = property(lambda self: self._client("pt"))
    cz = property(lambda self: self._client("cz"))

    def cztor_client(self):
        return cztor_client()
    storages = property(lambda self: self._client("storages"))
    tmdb = property(lambda self: self._client("tmdb"))
    cinemeta = property(lambda self: self._client("cinemeta"))
    trend = property(lambda self: self._client("trend"))
    dash = property(lambda self: self._client("dash"))


def get_apis():
    """Klienty zdrojů pod jmény, na která je zvyklý zbytek doplňku, plus jádro pod `engine`."""
    engine = KodiEngine()
    return {"engine": engine, "luna": engine.luna, "sosac": engine.sosac, "ws": engine.ws, "hs": engine.hs,
            "st": engine.st, "fs": engine.fs, "pt": engine.pt, "cz": engine.cz, "dav": engine.storages, "cinemeta": engine.cinemeta, "sosac_db": engine.sosac_db,
            "tmdb": engine.tmdb, "trend": engine.trend, "dash": engine.dash}


def engine_of(apis):
    """Jádro k `apis` z `get_apis()`; holý slovník (testy, starší volání) dostane vlastní."""
    engine = apis.get("engine")
    if engine is None:
        engine = apis["engine"] = KodiEngine()
    return engine


def source_for(item_id):
    return "sosac" if is_sosac_id(item_id) else "luna"


def api_for(apis, item_id):
    api = apis[source_for(item_id)]
    if api is None:
        raise LunaError(L(30104))
    return api


def notify(msg, kind=xbmcgui.NOTIFICATION_INFO, ms=4000):
    xbmcgui.Dialog().notification(L(30000), msg, kind, ms)


def log_error(err):
    xbmc.log(f"[{ADDON_ID}] {err}", xbmc.LOGERROR)


SOURCE_LABELS = {
    LunaError: "Luna", CinemetaError: "Cinemeta", TmdbError: "TMDB",
    SosacError: "Sosáč", WebshareError: "WebShare", HellspyError: "HellSpy", SledujtetoError: "Sledujteto",
    FastshareError: "FastShare", PrehrajtoError: "Přehraj.to", CztorError: "CZtor", StorageError: L(30405, "Úložiště"),
    TraktError: "Trakt.tv",
}


def describe_error(e):
    """Jméno zdroje před chybovou hláškou — ať je jasné, který přesně selhal
    (dřív se u víc-zdrojového hledání hlásilo natvrdo „Server Luna neodpovídá“
    i při chybě jinde, třeba na WebShare). Hlášky jádra už zdroj nesou samy."""
    if isinstance(e, NokturnoError):
        return str(e)
    return f"{error_label(e)}: {e}"


def error_label(e):
    if isinstance(e, NokturnoError):
        # „WebShare: …“, „Úložiště: …“ — zdroj je v hlášce, jinak je to obecná chyba jádra
        head, sep, _rest = str(e).partition(":")
        return head.strip() if sep and len(head) <= 20 else L(30000, "Nokturno")
    return getattr(e, "source_label", None) or next(
        (v for k, v in SOURCE_LABELS.items() if isinstance(e, k)), type(e).__name__)


class SourceFailure(Exception):
    """Neočekávaná chyba zdroje mimo jeho vlastní typ výjimky — nese jméno zdroje."""

    def __init__(self, label, err):
        super().__init__(str(err))
        self.source_label = label


def skipped_notice(errors):
    """Upozornění, že se zdroj přeskočil a výsledky jsou z ostatních — bez adres
    a tokenů, ty jsou jen v logu (viz `lib/source_errors.py`)."""
    lines = summarize_failures((error_label(e), e) for e in errors)
    return f"{'; '.join(lines)} – {L(30366, 'přeskočeno')}"


def describe_errors(errors):
    lines, seen = [], set()
    for e in errors:
        line = describe_error(e)
        if line not in seen:
            seen.add(line)
            lines.append(line)
    return "\n".join(lines)


# --- položky ------------------------------------------------------------------

CONTENT_SORTS = {
    "movies": (xbmcplugin.SORT_METHOD_VIDEO_YEAR, xbmcplugin.SORT_METHOD_VIDEO_RATING),
    "tvshows": (xbmcplugin.SORT_METHOD_VIDEO_YEAR, xbmcplugin.SORT_METHOD_VIDEO_RATING),
    "episodes": (xbmcplugin.SORT_METHOD_EPISODE,),
}


LABEL2_MASKS = {
    xbmcplugin.SORT_METHOD_VIDEO_YEAR: "%Y",
    xbmcplugin.SORT_METHOD_VIDEO_RATING: "%R",
}
# druhý sloupec u výchozího řazení (a podle názvu) — rok u titulů, u ostatního Kodi výchozí
DEFAULT_LABEL2 = {"movies": "%Y", "tvshows": "%Y"}


def set_content(content):
    """Typ obsahu + nabídka řazení. Bez `addSortMethod` skiny ukazovaly „Řazení: žádné“
    a katalog nešel seřadit podle roku ani hodnocení, i když je `fill_info` plní.
    První je „jak přišlo“ — pořadí ze zdroje (žebříček, seřazené streamy) zůstává výchozí.

    Masky výslovně, Kodi (`ModuleXbmcplugin.cpp::addSortMethod`) jinak dosadí popisek `%T`
    a druhý sloupec `%D`:
    - `%T` ukázal místo našeho popisku titul z info tagu — katalog a hledání tak měly
      „Matrix“ bez roku, Můj seznam „Matrix (1999)“ (beta16),
    - `%D` = stopáž. Arctic Fuse (`Label_MediaList_Year`) kreslí vpravo Label2, a když je
      prázdný, rok — takže titul se stopáží (Můj seznam, snímek ji nese od bety 20) měl
      vpravo délku, titul bez ní (žebříček, `/trending` stopáž neposílá) rok. U filmů
      a seriálů proto vždy `%Y`, stejně všude (2026-09-16, nahlásil uživatel)."""
    xbmcplugin.setContent(HANDLE, content)
    label2 = DEFAULT_LABEL2.get(content, "")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED, "%L", label2)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE, "%L", label2)
    for method in CONTENT_SORTS.get(content, ()):
        xbmcplugin.addSortMethod(HANDLE, method, "%L", LABEL2_MASKS.get(method, label2))


# ikony, které smí poslat dashboard (`dash_api.ICONS`) → naše sada
DASH_ICONS = {
    "": "DefaultVideoPlaylists.png", "movies": "DefaultMovies.png", "series": "DefaultTVShows.png",
    "star": "DefaultFavourites.png", "top": "DefaultMusicTop100.png", "new": "DefaultRecentlyAddedMovies.png",
    "halloween": "DefaultAddonVideo.png", "calendar": "DefaultYear.png", "trophy": "DefaultMusicTop100.png",
    "christmas": "DefaultYear.png", "fairytale": "DefaultMovies.png", "comedy": "DefaultMovies.png",
    "romance": "DefaultMovies.png", "family": "DefaultAddonVideo.png", "animation": "DefaultMovies.png",
}


def dash_catalog_items(apis, placement, ctype=None):
    """Katalogy zapnuté na dashboardu pro dané umístění — jako složky menu."""
    dash = apis.get("dash")
    if dash is None:
        return
    for e in dash.menu(placement=placement, ctype=ctype):
        dash_entry_item(e)


def dash_entry_item(entry):
    """Jedna položka menu z dashboardu: složka s podkategoriemi (`children`) vede na
    další výpis, obyčejný katalog rovnou na tituly."""
    icon = DASH_ICONS.get(entry["icon"], DASH_ICONS[""])
    if entry.get("children"):
        folder_item(entry["title"], build_url(action="dash_group", catalog=entry["slug"], type=entry["kind"]),
                    icon=icon)
    else:
        folder_item(entry["title"], build_url(action="catalog", type=entry["kind"], catalog=entry["slug"],
                                              src="dash"), icon=icon)


HOME_ROW_PROP = "nokturno.home.%d"   # Window(home).Property — nadpis řady ve skinu Estuary Nokturno
HOME_COUNT_SKIN = "nokturno.home.count"   # Skin.String — kolik slotů má skin načítat (slot 1 vždy)
HOME_REV_PROP = "nokturno.home.rev"   # změna = skin načte řady znovu (je v adrese widgetu)
HOME_ROWS_KEY = "home_rows"         # klíče řad na domovské obrazovce (`home_choices`), v pořadí; None = výchozí


def home_choices():
    """Co si uživatel může dát na domovskou obrazovku skinu: (klíč, název). Můj seznam a Pro Tebe
    vedle vlastních katalogů (klíč `mycat:<id>`)."""
    builtin = [("fav", L(30060, "Můj seznam")),
               ("foryou_movie", "%s – %s" % (L(30605, "Pro Tebe"), L(30012, "Filmy"))),
               ("foryou_series", "%s – %s" % (L(30605, "Pro Tebe"), L(30013, "Seriály")))]
    return builtin + [("mycat:" + c["id"], "%s (%s)" % (c.get("name") or L(30972, "Vlastní katalog"),
                                                         L(30013, "Seriály") if c.get("kind") == "series" else L(30012, "Filmy")))
                      for c in mycats()]


def home_chosen():
    """Vybrané klíče v pořadí výběru; dokud uživatel nevybíral, Můj seznam a katalogy z menu Filmy/Seriály."""
    chosen = STORE.load(HOME_ROWS_KEY, None)
    if isinstance(chosen, list):
        return chosen
    return ["fav"] + ["mycat:" + c["id"] for c in mycats() if c.get("menu")]


def home_rows(apis):
    """Řady pod položkou Nokturno ve skinu Estuary Nokturno: všechny katalogy zapnuté na dashboardu
    (Vánoce, Film pro dnešní den… z hlavního menu i z Filmů a Seriálů) a to, co si uživatel vybral
    v Nastavení vzhledu (`home_pick`): Můj seznam, Pro Tebe, vlastní katalogy."""
    dash = apis.get("dash")
    rows = [("dash", e["kind"], e["slug"], e["title"]) for e in (dash.menu() if dash else [])]
    names = dict(home_choices())
    cats = {c["id"]: c for c in mycats()}
    for key in home_chosen():
        if key.startswith("mycat:") and key[6:] in cats:
            c = cats[key[6:]]
            rows.append(("mycat", c.get("kind", "movie"), c["id"], c.get("name") or L(30972, "Vlastní katalog")))
        elif key in ("fav", "foryou_movie", "foryou_series"):
            rows.append((key, "series" if key.endswith("series") else "movie", key, names[key]))
    return rows


def home_pick():
    """Výběr řad na domovskou obrazovku skinu Estuary Nokturno (tlačítko v Nastavení vzhledu, spouští ho
    uživatel — dialog je tu v pořádku). Pořadí řad = pořadí v seznamu."""
    choices = home_choices()
    current = set(home_chosen())
    sel = xbmcgui.Dialog().multiselect(L(31069, "Řady na domovské obrazovce"), [n for _, n in choices],
                                       preselect=[i for i, (k, _) in enumerate(choices) if k in current])
    if sel is None:
        return
    STORE.save(HOME_ROWS_KEY, [choices[i][0] for i in sel])
    xbmcgui.Window(10000).setProperty(HOME_REV_PROP, str(int(time.time())))


def list_home_row(apis, slot):
    """N-tá řada z `home_rows` jako widget (skin má pevný počet slotů, prázdný slot schová).
    Nadpis jde do vlastnosti okna Home, adresa widgetu se tak s katalogy nemění."""
    rows = home_rows(apis)
    win = xbmcgui.Window(10000)
    # počet řad si skin pamatuje (Skin.String) a prázdné sloty po startu Kodi vůbec nevolá
    if xbmc.getInfoLabel("Skin.String(%s)" % HOME_COUNT_SKIN) != str(len(rows)):
        xbmc.executebuiltin("Skin.SetString(%s,%d)" % (HOME_COUNT_SKIN, len(rows)))
    if not 1 <= slot <= len(rows):
        win.clearProperty(HOME_ROW_PROP % slot)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    src, kind, key, title = rows[slot - 1]
    win.setProperty(HOME_ROW_PROP % slot, title)
    if src == "dash":   # u složky vrátí server slité položky podkategorií
        list_catalog(apis, kind, key, "dash")
    elif src == "fav":
        list_favourites()
    elif src.startswith("foryou"):
        list_foryou(apis, kind)
    else:
        list_mycat(apis, kind, key, widget=True)


def list_dash_group(apis, slug, ctype):
    """Podkategorie složky z dashboardu. Když složka mezitím zmizela nebo podkategorie
    ztratila (server posílá jen neprázdné), otevře se rovnou jako katalog — server u
    složky vrátí slité položky potomků, takže uživatel neskončí v prázdném výpisu."""
    dash = apis.get("dash")
    children = dash.group(slug) if dash else []
    if not children:
        list_catalog(apis, ctype, slug, "dash")
        return
    for entry in children:
        dash_entry_item(entry)
    xbmcplugin.endOfDirectory(HANDLE)


IMDB_ID_RE = re.compile(r"^tt\d{5,10}$")


def similar_context(ctype, item_id):
    """„Podobné tituly“ v kontextovém menu — jen u titulů s IMDb id (TMDB je jinak nenajde)."""
    if not IMDB_ID_RE.match(str(item_id or "")):
        return []
    url = build_url(action="similar", type=ctype, id=item_id)
    # ve výpisu Nokturna jen přepnout obsah, z widgetu/domovské obrazovky otevřít okno Videa
    cmd = f"Container.Update({url})" if browsing_nokturno() else f"ActivateWindow(Videos,{url},return)"
    return [(L(30482, "Podobné tituly"), cmd)]


def episodes_context(series_id, season, alt=None):
    """„Seznam dílů“ v kontextovém menu dílu – z Pokračovat ve sledování se jinak k jinému dílu
    než dalšímu na řadě nedalo dostat (Discord 2026-09-28)."""
    if not series_id or season is None:
        return []
    def cmd(url):
        return f"Container.Update({url})" if browsing_nokturno() else f"ActivateWindow(Videos,{url},return)"
    # „Všechny série“: ze Seznamu dílů se do jiné série nedalo dostat (Discord 2026-09-28)
    return [(L(30979, "Seznam dílů"), cmd(build_url(action="episodes", id=series_id, season=int(season), alt=alt))),
            (L(30980, "Všechny série"), cmd(build_url(action="seasons", id=series_id, alt=alt)))]


# Až tři vlastní seznamy: slot 1 má původní id nastavení (`mylist_url`…) i odkazy bez
# `slot`, ať oblíbené a widgety z doby jednoho seznamu vedou dál na něj.
MYLIST_SLOTS = {1: (30981, "Vlastní seznam"), 2: (30989, "Vlastní seznam 2"), 3: (30990, "Vlastní seznam 3")}


def mylist_slot(value):
    """Číslo slotu z parametru adresy; chybějící nebo neplatné = 1."""
    try:
        slot = int(value)
    except (TypeError, ValueError):
        return 1
    return slot if slot in MYLIST_SLOTS else 1


def mylist_name(slot):
    return L(*MYLIST_SLOTS[slot])


def mylist_url(slot, **params):
    return build_url(action="mylist", **({"slot": slot} if slot != 1 else {}), **params)


# Ikona položky v menu (`mylistN_icon`, index do seznamu) – jen standardní sada skinu,
# vlastní PNG ne. Index 0 = dřívější pevná ikona. Pořadí se nesmí měnit, nové jen na konec.
MYLIST_ICONS = ("DefaultVideoPlaylists.png", "DefaultMovies.png", "DefaultTVShows.png",
                "DefaultMusicVideos.png", "DefaultMusicAlbums.png", "DefaultAddonMusic.png",
                "DefaultFavourites.png", "DefaultRecentlyAddedMovies.png", "DefaultGenre.png",
                "DefaultYear.png", "DefaultActor.png", "DefaultFolder.png")
# Místo v kořeni menu (`mylistN_pos`); 0 = dřívější místo pod Filmy, Seriály a katalogy
MYLIST_POS_CATALOGS, MYLIST_POS_TOP, MYLIST_POS_WATCH, MYLIST_POS_BOTTOM = 0, 1, 2, 3


def mylist_prefix(slot):
    return "mylist" if slot == 1 else f"mylist{slot}"


def mylist_enabled(slot):
    """Přepínač „Používat tento seznam“; vypnutý zůstane vyplněný, jen se v menu neukáže."""
    return setting(f"{mylist_prefix(slot)}_enabled", "true") != "false"


def mylist_choice(slot, key, count):
    """Index volby spinneru; neplatná nebo chybějící hodnota = 0 (výchozí)."""
    try:
        value = int(setting(f"{mylist_prefix(slot)}_{key}", "0") or 0)
    except ValueError:
        return 0
    return value if 0 <= value < count else 0


def mylist_source(slot=1):
    """Adresa vlastního seznamu a hlavičky požadavku z nastavení."""
    prefix = mylist_prefix(slot)
    return (setting(f"{prefix}_url").strip(),
            mylist.parse_headers([setting(f"{prefix}_header1"), setting(f"{prefix}_header2")]))


def mylist_menu_item(position=MYLIST_POS_CATALOGS):
    """Vlastní seznamy v kořeni menu na daném místě, jen s vyplněnou adresou; víc seznamů
    na jednom místě jde podle čísla slotu, vypnutý se přeskočí. Název z poslední načtené verze (bez dotazu na
    síť, menu se tím nezdrží), jinak obecný."""
    for slot in MYLIST_SLOTS:
        url, _ = mylist_source(slot)
        if url and mylist_enabled(slot) and mylist_choice(slot, "pos", 4) == position:
            folder_item(mylist.cached_title(STORE, url) or mylist_name(slot), mylist_url(slot),
                        icon=MYLIST_ICONS[mylist_choice(slot, "icon", len(MYLIST_ICONS))])


def list_mylist(apis, path="", slot=1):
    """Skupiny jako složky, položky jako přehratelné řádky. `path` = indexy skupin."""
    url, headers = mylist_source(slot)
    tree, error = mylist.load(STORE, url, headers) if url else (None, "")
    if error:
        xbmc.log(f"[{ADDON_ID}] vlastní seznam {slot} nejde načíst: {error}", xbmc.LOGWARNING)
        notify(L(30985, "Vlastní seznam nejde načíst.") + (" " + L(30986, "Ukazuje se poslední známý stav.")
               if tree else ""), xbmcgui.NOTIFICATION_WARNING, 6000)
    here = mylist.node(tree, path) if tree else None
    if here is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(HANDLE, here["title"] or mylist_name(slot))
    for i, g in enumerate(here["groups"]):
        li = xbmcgui.ListItem(label=g["title"])
        li.setArt({"icon": "DefaultFolder.png", **({"thumb": g["thumb"]} if g["thumb"] else {})})
        xbmcplugin.addDirectoryItem(HANDLE, mylist_url(slot, path=f"{path}.{i}".strip(".")),
                                    li, isFolder=True)
    for it in here["items"]:
        title = it["title"] + (f" ({it['year']})" if it["year"] else "")
        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": "DefaultVideo.png",
                   **({"thumb": it["thumb"], "poster": it["thumb"], "fanart": it["thumb"]} if it["thumb"] else {})})
        tag = li.getVideoInfoTag()
        tag.setTitle(it["title"])
        if it["year"]:
            tag.setYear(it["year"])
        if it["duration"]:
            tag.setDuration(it["duration"])
        if it["plot"]:
            tag.setPlot(it["plot"])
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="mylist_play", refs="|".join(it["refs"]), name=title),
                                    li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def mylist_play(apis, refs, name=""):
    """Položka vlastního seznamu: první odkaz, který jde (smazaný soubor, vypršelý účet),
    ostatní jsou kopie téže položky jinde."""
    try:
        used, link = resolve_first(apis, [r for r in (refs or "").split("|") if r])
    except Errors as e:
        notify(str(e) or L(30102), xbmcgui.NOTIFICATION_ERROR, 6000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(label=name or used, path=link)
    li.getVideoInfoTag().setTitle(name or used)
    kind = used.split(":", 1)[0]
    STORE.remember_item(used, {"type": kind, "id": used, "title": name or used, "art": {}})
    mark_playing(used, name, kind=kind, replay=sw_replay(action="mylist_play", refs=used, name=name))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def next_page_item(url):
    """„Další“ jako obyčejná složka s `paged=1`. Výpis ji zavře s `updateListing=True`, takže
    stránka nahradí předchozí v historii: Zpět vede rovnou do menu (Discord 2026-09-28)
    a výběr začne na první položce. Dřív tlačítko `action=page` + `Container.Update(…,replace)`
    – první klik jen zatočil kolečkem a výběr zůstal uprostřed."""
    folder_item(L(30021), url + "&paged=1", icon="DefaultFolder.png")


def folder_item(label, url, icon=None, context=None, info=""):
    """`info` = jedna dvě věty do popisu, jinak skin vlevo ukazuje „Nejsou dostupné žádné informace“."""
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": icon or ICON})
    if info:
        li.getVideoInfoTag().setPlot(info)
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def action_item(label, url, icon=None, context=None, thumb=False, info=""):
    """Položka, která jen spustí akci s dialogem (nastavení, novinky, průvodce). Není složka —
    Kodi ji po kliknutí spustí s handle −1, takže se nekreslí žádný výpis a do kodi.log
    nepadá `GetDirectory - Error getting …` (to hlásí každý `endOfDirectory(succeeded=False)`)."""
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": icon or ICON, "thumb": icon or ICON} if thumb else {"icon": icon or ICON})
    if info:
        li.getVideoInfoTag().setPlot(info)
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


def bare_title(meta):
    """Titul bez roku – u Sosáče jen titul bez jazyků a originálu."""
    if is_sosac_id(meta.get("id")):
        return meta.get("_title") or meta.get("name") or ""
    return meta.get("name") or meta.get("id") or ""


# Cinemeta/TMDB u epizod bez vlastního (přeloženého) názvu vrací místo prázdné
# hodnoty doslovný placeholder "Episode 3" (nebo v češtině "3. epizoda"/"3. díl") –
# jako `or` fallback ho nic nechytí, je to neprázdný řetězec. Do statistik tak šlo
# "3. epizoda" místo názvu seriálu – různé seriály se stejným generickým placeholderem
# u první epizody (`n:series:<rok>:1 epizoda`) se pak slily do jednoho falešného
# item_key (`db.canonical_key`) a dashboard/TMDB takový "titul" nedohledá (vypadne
# z veřejného žebříčku trendů, viz Dashboard/backend/stats.py::_resolve_for_client).
_EPISODE_PLACEHOLDER_RE = re.compile(r"^(episode\s+\d+|\d+\.?\s*(epizoda|díl))$", re.IGNORECASE)


def episode_stats_title(video, meta):
    """Titul epizody do statistik – `video["title"]`, ale jen když není generický
    placeholder (viz výše); jinak název seriálu jako u filmu/seriálu bez epizody."""
    t = (video or {}).get("title")
    if t and not _EPISODE_PLACEHOLDER_RE.match(t):
        return t
    return bare_title(meta)


def display_name(meta):
    """Název do seznamu — bez roku; u Sosáče jen titul bez jazyků a originálu.

    Do 5.2.7~beta21 „Matrix (1999)“. Rok ale od bety 16/20 kreslí každý seznam zvlášť
    (Label2 `%Y`, info tag), takže v názvu byl dvakrát (2026-09-16, přání uživatele)."""
    return bare_title(meta)


_TITLE_YEAR_RE = re.compile(r"\s*\((\d{4})\)$")


def strip_year(title, year=None):
    """Snímky uložené do bety 21 mají v názvu „ (1999)“ — při kreslení ho uřízne, jen když
    sedí s rokem snímku (nebo rok neznáme), ať nepřijde o závorku, která k názvu patří."""
    title = str(title or "")
    m = _TITLE_YEAR_RE.search(title)
    if m and (not str(year or "").isdigit() or m.group(1) == str(year)[:4]):
        return title[:m.start()]
    return title


def split_episode_id(item_id):
    """'tt0903747:1:2' / 'sosac2_21849:1:2' → (základ, sezóna, epizoda) nebo (id, None, None)."""
    parts = str(item_id).split(":")
    if len(parts) >= 3 and parts[-1].isdigit() and parts[-2].isdigit():
        return ":".join(parts[:-2]), int(parts[-2]), int(parts[-1])
    return item_id, None, None


def snapshot(meta, ctype, video=None, series_id=None, alt=None):
    """Snímek titulu pro seznamy bez dotazu na API (Pokračovat, Můj seznam, Naposledy)."""
    return {
        "type": "series" if (video or ctype == "series") else "movie",
        "id": (video or {}).get("id") or meta.get("id"),
        "series": series_id or (meta.get("id") if video else None),
        "alt": alt,
        "title": (video or {}).get("title") or display_name(meta),
        "tvshow": (meta.get("_title") or meta.get("name")) if (video or ctype == "series") else "",
        "season": (video or {}).get("season"),
        "episode": (video or {}).get("episode"),
        "plot": (video or {}).get("overview") or (video or {}).get("description") or meta.get("description") or "",
        "year": str(meta.get("year") or meta.get("releaseInfo") or "")[:4],
        "art": art_for(meta, video),
        # totéž, co kreslí `fill_info` v katalogu — bez toho měl Můj seznam/Pokračovat jen
        # název a popis, žádné hvězdičky, žánr ani stopáž (2026-09-16, nahlásil uživatel)
        "rating": meta.get("imdbRating") or "",
        "votes": meta.get("voteCount") or 0,
        "rating_source": meta.get("ratingSource") or "",
        "ratings": meta.get("ratings") or {},
        "genres": [str(g) for g in (meta.get("genres") or [])],
        "runtime": (video or meta).get("runtime") or "",
        "mpaa": str(meta.get("mpaa") or ""),
        "released": release_date((video or meta).get("released")),
    }


# zdroj hodnocení z jádra (`ratingSource`) → jméno hodnocení v Kodi; skiny podle
# `ListItem.Rating(imdb)` / `(themoviedb)` kreslí logo. Kodi scrapery TMDB píšou `themoviedb`.
RATING_TYPES = {"imdb": "imdb", "tmdb": "themoviedb", "sosac": "sosac"}


def rate(metas, ctype):
    """Ke hlavnímu hodnocení i druhé (IMDb i TMDB naráz, Discord 2026-09-28), viz `add_ratings`."""
    add_ratings(metas, STORE, "series" if ctype == "series" else "movie", tmdb=get_tmdb(), dash=get_dash())


def set_rating(li, tag, rating, votes=None, source=None, others=None):
    """Hodnocení s názvem zdroje; bez zdroje (starší cache) jako dřív výchozí.
    `others` = další hodnocení `{zdroj: číslo}` – skin je ukáže vedle hlavního s logem."""
    rating = float(rating)
    tag.setRating(rating, int(votes or 0), RATING_TYPES.get(source or "", ""), True)
    for src, value in (others or {}).items():
        if src in RATING_TYPES and src != source:
            tag.setRating(float(value), 0, RATING_TYPES[src], False)
    # skin kreslí z ratingu hvězdičky; procento posíláme zvlášť jako vlastnost
    li.setProperty("RatingPercent", f"{round(rating * 10)} %")


def thin_snapshot(info):
    """Snímek bez popisu i bez fotky — vznikl, když se titul přidal do Mého seznamu/
    stahování dřív, než pro něj doběhlo obohacení (TMDB, přepočet dabingu na pozadí
    u čerstvě přidaných titulů). Bez záchrany zůstane navždy prázdný, i když už
    mezitím data dorazila — `snapshot()` se z API znovu nevolá samo od sebe."""
    if info is None or info.get("type") in ("ws", "hs", "dav"):
        return False   # soubory bez meta — není z čeho dohledat
    if "rating" not in info:
        return True    # snímek ze starší verze bez hodnocení/žánrů/stopáže → jednou dohledat
    return not info.get("plot") and not (info.get("art") or {})


def apply_watched(li, key, context=None):
    """Zhlédnuto (fajfka) a bod pro pokračování z vlastní evidence.

    `context`: další položky kontextového menu. Kodi při každém `addContextMenuItems` přepisuje
    položky od indexu 0, proto se menu skládá tady najednou.
    """
    tag = li.getVideoInfoTag()
    count = STORE.playcount(key)
    # i nula výslovně: přehratelné položce (widget, Pokračovat s uloženým streamem) by
    # jinak Kodi dosadilo počet z vlastní videodatabáze, který Nokturno nevede
    tag.setPlaycount(count)
    resume, total = STORE.resume(key)
    try:
        if resume and not count:
            tag.setResumePoint(resume, total)
        else:
            # pozice 0 s nenulovou délkou: Kodi bere bod za nastavený (`CBookmark::IsSet`
            # = délka > 0), takže nedosadí starou záložku ze své databáze, a ukazatel
            # rozkoukání nekreslí (`IsPartWay` chce i pozici > 0)
            tag.setResumePoint(0, total or 1)
    except Exception:  # noqa: BLE001 – Kodi < 20
        pass
    li.addContextMenuItems(list(context or []) +
                           [(L(30044) if count else L(30043), runplugin(action="toggle_watched", id=key))])


def fav_context(key, ctype, series_id=None, alt=None):
    label = L(30062) if STORE.is_favourite(key) else L(30061)
    return (label, runplugin(action="toggle_fav", id=key, type=ctype, series=series_id, alt=alt))


_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def release_date(value):
    """`RRRR-MM-DD` z data vydání (TMDB `2026-09-16`, Cinemeta `2026-09-16T00:00:00.000Z`),
    jinak prázdné. Arctic Fuse 3 ukazuje v detailu `ListItem.Premiered`, ne rok."""
    value = str(value or "")[:10]
    return value if _DATE_RE.match(value) else ""


def fill_info(li, meta, ctype="movie", video=None, tech=True):
    """`tech=False` vynechá stopáž a hodnocení.

    V seznamu streamů jsou to údaje o filmu, ne o streamu, ale skiny je vykreslují jako
    samostatné sloupce vpravo (Arctic Fuse) a ubírají tím šířku popisku streamu.
    """
    tag = li.getVideoInfoTag()
    tag.setMediaType("episode" if video else ("tvshow" if ctype == "series" else "movie"))
    title = (video or {}).get("title") or (meta.get("_title") if is_sosac_id(meta.get("id")) else None) \
        or meta.get("name") or ""
    tag.setTitle(title)
    if meta.get("_orig"):
        tag.setOriginalTitle(meta["_orig"])
    if ctype == "series":
        tag.setTvShowTitle(meta.get("_title") or meta.get("name") or "")
    plot = (video or {}).get("overview") or (video or {}).get("description") or meta.get("description") or ""
    genres = ", ".join(genre_label(g) for g in (meta.get("genres") or []))
    if genres:
        # žánr na stejný řádek jako popis — s prázdným řádkem za ním zabral v panelu
        # skinu (Arctic Fuse, tři řádky) dva ze tří řádků a na popis zbyl jeden
        plot = f"[B]{genres}[/B] · {plot}" if plot else genres
    tag.setPlot(plot)
    year = str(meta.get("year") or meta.get("releaseInfo") or "")[:4]
    if tech and year.isdigit():
        tag.setYear(int(year))
    if tech and not video and release_date(meta.get("released")):
        tag.setPremiered(release_date(meta.get("released")))
    if meta.get("genres"):
        tag.setGenres([str(g) for g in meta["genres"]])
    try:
        if tech and meta.get("imdbRating"):
            # počet hlasů zná jen TMDB — Luna/Cinemeta/Sosáč ne
            set_rating(li, tag, meta["imdbRating"], meta.get("voteCount"), meta.get("ratingSource"),
                       meta.get("ratings"))
    except (TypeError, ValueError):
        pass
    if meta.get("mpaa"):  # věkový rating (jen TMDB, přednostně český)
        tag.setMpaa(str(meta["mpaa"]))
    if meta.get("trailerYoutubeId"):
        tag.setTrailer(f"plugin://plugin.video.youtube/play/?video_id={meta['trailerYoutubeId']}")
    # IMDb id: podle něj Kodi (OpenSubtitles apod.) hledá titulky
    if meta.get("imdb_id") or str(meta.get("id", "")).startswith("tt"):
        tag.setIMDBNumber(meta.get("imdb_id") or meta.get("id"))
    minutes = runtime_minutes((video or meta).get("runtime"))
    if tech and minutes:
        tag.setDuration(minutes * 60)
    if video:
        tag.setSeason(int(video.get("season") or 0))
        tag.setEpisode(int(video.get("episode") or 0))
        if video.get("released"):
            tag.setFirstAired(str(video["released"])[:10])
    cast = None
    extras = meta.get("app_extras") or {}
    if isinstance(extras, dict) and extras.get("cast"):
        cast = [(c.get("name", ""), c.get("character", ""), c.get("photo") or "") for c in extras["cast"][:15]]
    elif isinstance(meta.get("cast"), list) and meta["cast"] and isinstance(meta["cast"][0], dict):
        # TMDB — jméno, role a fotka rovnou ve tvaru API (viz tmdb_api.py:meta)
        cast = [(c.get("name", ""), c.get("character", ""), c.get("photo") or "") for c in meta["cast"][:15]]
    elif isinstance(meta.get("cast"), list):
        # Luna/Cinemeta (přes Sosáč) — jen jména, bez fotky
        cast = [(str(c), "", "") for c in meta["cast"][:15]]
    if cast:
        try:
            tag.setCast([xbmc.Actor(n, r, i, p) for i, (n, r, p) in enumerate(cast)])
        except Exception:  # noqa: BLE001 – starší API
            pass
    if isinstance(meta.get("director"), list) and meta["director"]:
        tag.setDirectors([str(d) for d in meta["director"]])
    if isinstance(meta.get("writer"), list) and meta["writer"]:
        tag.setWriters([str(w) for w in meta["writer"]])


# rozlišení, které se pošle skinu, když se kvalita jen odhadla z názvu
TIER_SIZE = {4: (3840, 2160), 3.5: (2560, 1440), 3: (1920, 1080), 2: (1280, 720), 1: (720, 576)}


def quality_name(height):
    """Výška obrazu → „4K“/„FHD“/„HD“/„SD“ (opak `TIER_SIZE`). Hranice jsou nižší než
    jmenovité rozlišení, protože kinoformát má obraz oříznutý — 1920×800 je pořád Full HD."""
    h = int(height or 0)
    for hranice, rank in ((1700, 4), (1300, 3.5), (900, 3), (600, 2)):
        if h >= hranice:
            return QUALITY_NAMES[rank]
    return QUALITY_NAMES[1] if h else ""
# „5.1" je šest kanálů — skin chce jejich počet, ne zápis se středem
CHANNEL_COUNT = {"1.0": 1, "2.0": 2, "2.1": 3, "5.1": 6, "6.1": 7, "7.1": 8}


def fill_streamdetails(li, s):
    """Technické údaje o stopách do položky.

    Odznak kvality si skin kreslí sám, jakmile o položce ví rozlišení — tak to
    dělají i jiné doplňky a vypadá to jako zbytek rozhraní, na rozdíl od obrázku
    přibaleného doplňkem. Ze stejných údajů skin bere i ikony zvuku a jazyků.

    Přesné rozlišení je z hlavičky souboru; když se číst nedalo, pošle se
    typické rozlišení odhadnuté třídy, ať odznak nechybí. Že jde o odhad, je
    poznat v popisku podle vlnovky.
    """
    info = s.get("_media") or {}
    width, height = info.get("width") or 0, info.get("height") or 0
    if not height:
        width, height = TIER_SIZE.get(s.get("quality_rank") or 0, (0, 0))
    tag = li.getVideoInfoTag()
    if height:
        tag.addVideoStream(xbmc.VideoStreamDetail(width=width, height=height))
    tracks = info.get("audio") or []
    if tracks:
        for t in tracks:
            tag.addAudioStream(xbmc.AudioStreamDetail(
                channels=CHANNEL_COUNT.get(t.get("channels") or "", 0),
                codec=(t.get("codec") or "").lower(),
                language=(t.get("lang") or "").lower()))
    else:
        for code, chans in (s.get("channels") or {}).items():
            tag.addAudioStream(xbmc.AudioStreamDetail(
                channels=CHANNEL_COUNT.get(f"{chans:.1f}", 0), language=str(code).lower()))
    for code in sorted(set(s.get("subs") or [])):
        tag.addSubtitleStream(xbmc.SubtitleStreamDetail(language=str(code).lower()))


def fill_info_snapshot(li, snap):
    """Info z uloženého snímku (bez API)."""
    tag = li.getVideoInfoTag()
    is_ep = snap.get("season") is not None
    tag.setMediaType("episode" if is_ep else ("tvshow" if snap.get("type") == "series" else "movie"))
    tag.setTitle(strip_year(snap.get("title"), snap.get("year")))
    if snap.get("tvshow"):
        tag.setTvShowTitle(snap["tvshow"])
    plot = snap.get("plot") or ""
    genres = ", ".join(genre_label(g) for g in (snap.get("genres") or []))
    if genres:
        plot = f"[B]{genres}[/B] · {plot}" if plot else genres
        tag.setGenres(list(snap["genres"]))
    tag.setPlot(plot)
    if str(snap.get("year") or "").isdigit():
        tag.setYear(int(snap["year"]))
    try:
        if snap.get("rating"):
            set_rating(li, tag, snap["rating"], snap.get("votes"), snap.get("rating_source"), snap.get("ratings"))
    except (TypeError, ValueError):
        pass
    if snap.get("mpaa"):
        tag.setMpaa(str(snap["mpaa"]))
    minutes = runtime_minutes(snap.get("runtime"))
    if minutes:
        tag.setDuration(minutes * 60)
    if is_ep:
        tag.setSeason(int(snap.get("season") or 0))
        tag.setEpisode(int(snap.get("episode") or 0))
    if release_date(snap.get("released")):
        (tag.setFirstAired if is_ep else tag.setPremiered)(release_date(snap["released"]))
    base = split_episode_id(snap.get("id"))[0]
    if str(base).startswith("tt"):
        tag.setIMDBNumber(base)
    li.setArt(snap.get("art") or {})


def art_for(meta, video=None):
    art = {
        "poster": meta.get("poster") or "",
        "fanart": meta.get("background") or "",
        "landscape": meta.get("landscapePoster") or "",
        "clearlogo": meta.get("logo") or "",
        "thumb": (video or {}).get("thumbnail") or meta.get("poster") or "",
    }
    return {k: v for k, v in art.items() if v}


def add_meta_item(meta, ctype, alt=None, tag_source=False, label=None):
    """`alt` = id téhož titulu v Sosáči (sloučený výsledek hledání) → streamy z obou zdrojů.

    `tag_source`: ve smíšeném hledání označit tituly, které má jen Sosáč (v katalozích Sosáče je to zbytečné).
    `label`: vlastní popisek místo názvu (TV program: čas a stanice před názvem).
    """
    label = label or display_name(meta)
    if tag_source and is_sosac_id(meta.get("id")):
        label = f"{label}  [COLOR {GREY}]· Sosáč[/COLOR]"
    li = xbmcgui.ListItem(label=label)
    li.setArt(art_for(meta))
    fill_info(li, meta, ctype)
    fav = fav_context(meta["id"], ctype, alt=alt)
    similar = similar_context(ctype, meta["id"]) + [watch_context(ctype, meta["id"], alt)]
    if ctype == "series":
        li.addContextMenuItems([fav] + similar)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="seasons", id=meta["id"], alt=alt), li, isFolder=True)
    else:
        apply_watched(li, meta["id"], [fav] + streams_context("movie", meta["id"], alt=alt) + similar)
        add_playable(li, "movie", meta["id"], alt=alt)


def add_playable(li, ctype, item_id, series_id=None, alt=None):
    """Film nebo díl — stream se vždy vybírá v dialogu na dva řádky (`choose_stream`).

    Ve výpisu Nokturna je položka `action=title` — ne-složka bez IsPlayable: klik ji Kodi spustí
    jako skript s handle −1 (`CGUIMediaWindow::OnClick` → `RunScriptWithParams`) → `pick_title()`
    najde streamy s ukazatelem, který jde zrušit, ukáže dialog a vybraný stream pustí přes
    `PlayMedia`. Zrušený dialog tak nic nehlásí. Přehrát v detailu (Estuary, Arctic Fuse přes
    TMDb Helper, tlačítko Play) tutéž položku rozklíčovává s normálním handle → `play(ask=1)`.
    Ve widgetu a na domovské obrazovce je položka přehratelná s `ask=1`. Nastavení „Výběr streamu“
    (automaticky / seznam / dialog) zrušeno v `5.2.14~beta2`, seznam streamů jako složka zůstal
    jen v kontextovém menu (stažení streamu, uvolněný fulltext).

    U epizod se předává i id seriálu — Sosáč dává epizodám vlastní id
    (`sosac2_1877:1:1`), ze kterého se meta seriálu nedá odvodit.
    """
    # rozkoukaný/dřív zhlédnutý titul má u sebe zapamatovanou vnitřní referenci streamu
    # (viz mark_playing, Player.save_resume) — ta na rozdíl od podepsaného odkazu zdroje
    # nevyprší, `play()` tak může přeskočit hledání napříč zdroji a rovnou pokračovat na
    # stejném streamu (dozná se, jestli mezitím zmizel ze zdroje, a spadne na hledání samo).
    resumed = STORE.resume_stream(item_id)
    stream_url, stream_subs = resumed if resumed else (None, None)
    if browsing_nokturno() and not stream_url:
        url = build_url(action="title", type=ctype, id=item_id, series=series_id, alt=alt)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
        return
    li.setProperty("IsPlayable", "true")
    # `ask=1` = dialog; bez `ask` (Up Next, HA) hraje zapamatovaný nebo nejlepší stream bez ptaní.
    # Uplatní se jen v plném hledání (`stream_url` prázdný, nebo se uložená reference nedala přehrát).
    url = build_url(action="play", type=ctype, id=item_id, series=series_id, alt=alt, ask="1",
                    url=stream_url, subs=stream_subs)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


def streams_context(ctype, item_id, series_id=None, alt=None):
    """„Vybrat stream“ a „Stáhnout“ v kontextovém menu — oba otevřou dialog výběru (`pick_title`).
    Vybrat stream i u položky, která by jinak hrála rovnou (Pokračovat ve sledování s uloženým streamem),
    Stáhnout vybraný stream zařadí do fronty stahování místo přehrání. Výpis streamů jako složka od
    `5.2.14~beta4` není (na přání uživatele vše v modálním okně)."""
    params = dict(type=ctype, id=item_id, series=series_id, alt=alt)
    # dlouhé podržení → „Vybrat stream“ vždy hledá znovu, bez cache (`fresh=1`)
    return [(L(30513, "Vybrat stream"), runplugin(action="title", fresh="1", **params)),
            (L(30070, "Stáhnout"), runplugin(action="title_download", **params))]


def add_snapshot_item(key, snap, extra_context=None):
    """Položka ze snímku (Pokračovat, Můj seznam, Naposledy)."""
    if snap.get("type") == "ws":
        f = {"ident": snap["id"][3:], "name": snap.get("title", ""), "img": (snap.get("art") or {}).get("thumb", ""),
             "size_h": snap.get("size_h", ""), "positive": 0, "negative": 0}
        add_ws_file(f, extra_context)
        return
    # HellSpy a vlastní úložiště mají snímek z `play_hs`/`play_dav` — bez těchhle větví šel
    # jejich klíč do `api_for` jako titul a Pokračovat skončilo chybou Luny (audit 2026-09-14)
    if snap.get("type") == "hs":
        _prefix, file_id, file_hash = snap["id"].split(":", 2)
        add_hs_file({"id": file_id, "hash": file_hash, "name": snap.get("title") or snap["id"],
                     "size_h": snap.get("size_h", "")}, extra_context)
        return
    if snap.get("type") == "dav":
        try:
            slot, path = parse_ref(snap["id"])
        except StorageError:
            return
        api = next((s for s in get_storages() if s.slot == slot), None)
        if api is None:
            return   # úložiště už není v nastavení
        meta = {"poster": snap["art"].get("poster"), "background": snap["art"].get("fanart"),
                "landscapePoster": snap["art"].get("landscape"), "logo": snap["art"].get("clearlogo"),
                "description": snap.get("plot"), "year": snap.get("year")} if snap.get("art") else None
        add_dav_file(api, {"path": path, "name": snap.get("title") or path.rsplit("/", 1)[-1],
                           "size_h": snap.get("size_h", "")}, extra_context, meta=meta)
        return
    label = strip_year(snap.get("title"), snap.get("year")) or key
    if snap.get("tvshow") and snap.get("season") is not None:
        label = f"{snap['tvshow']} – {int(snap['season'])}x{int(snap['episode'] or 0):02d} {label}"
    li = xbmcgui.ListItem(label=label)
    fill_info_snapshot(li, snap)
    ctx = [fav_context(key, snap.get("type", "movie"), snap.get("series"), snap.get("alt"))] + (extra_context or [])
    if snap.get("type") == "series" and snap.get("season") is None:
        li.addContextMenuItems(ctx + similar_context("series", key) + [watch_context("series", key, snap.get("alt"))])
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="seasons", id=key, alt=snap.get("alt")), li, isFolder=True)
        return
    kind = "series" if snap.get("season") is not None else "movie"
    similar = similar_context("movie", key) + [watch_context("movie", key, snap.get("alt"))] if kind == "movie" else []
    if kind == "series":
        ctx += episodes_context(snap.get("series"), snap.get("season"), snap.get("alt"))
    apply_watched(li, key, ctx + streams_context(kind, key, snap.get("series"), snap.get("alt")) + similar)
    add_playable(li, kind, key, series_id=snap.get("series"), alt=snap.get("alt"))


def add_ws_file(f, extra_context=None):
    key = "ws:" + f["ident"]
    votes = f"+{f['positive']}/-{f['negative']}" if (f.get("positive") or f.get("negative")) else ""
    label = f"{f['name']}  [COLOR FF9A9A9A]{f.get('size_h', '')} {votes}[/COLOR]"
    li = xbmcgui.ListItem(label=label)
    if f.get("img"):
        li.setArt({"thumb": f["img"], "icon": f["img"]})
    tag = li.getVideoInfoTag()
    tag.setMediaType("video")
    tag.setTitle(f["name"])
    tag.setPlot(f"{WS_TAG}  {f.get('size_h', '')}  {votes}")
    ctx = [(L(30070), runplugin(action="download_ws", ident=f["ident"], name=f["name"]))] + (extra_context or [])
    apply_watched(li, key, ctx)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action="play_ws", ident=f["ident"], name=f["name"]), li, isFolder=False)


def dav_titles(apis, files, deadline=6.0):
    """Metadata z TMDB k souborům úložiště podle jejich názvu: `{cesta: meta}`, u dílu seriálu s `season`/`episode`."""
    found = engine_of(apis).storage_titles([f["path"] for f in files], deadline=deadline)
    return {path: dict(meta, type=ctype, season=season, episode=episode)
            for path, (meta, ctype, season, episode) in found.items()}


def add_dav_file(api, f, extra_context=None, meta=None):
    """Soubor z vlastního úložiště ve výpisu hledání (a v Pokračovat/Naposledy přes `add_snapshot_item`).
    `meta` (z `dav_titles`) doplní plakát, popis, rok, žánr a u dílu seriálu sérii a epizodu;
    popisek (název souboru) zůstává."""
    key = f"dav:{api.slot}:{f['path']}"
    folder = f["path"].rsplit("/", 1)[0] if "/" in f["path"] else ""
    label = f"{f['name']}  [COLOR FF9A9A9A]{f.get('size_h', '')}[/COLOR]"
    li = xbmcgui.ListItem(label=label)
    tag = li.getVideoInfoTag()
    tag.setMediaType("video")
    tag.setTitle(f["name"])
    plot = f"[COLOR {DAV_COLOR}]{api.name}[/COLOR]  {f.get('size_h', '')}\n{folder}"
    if meta:
        li.setArt(art_for(meta, None))
        plot = f"{meta['description']}\n\n{plot}" if meta.get("description") else plot
        year = str(meta.get("year") or "")[:4]
        if year.isdigit():
            tag.setYear(int(year))
        if meta.get("genres"):
            tag.setGenres([str(g) for g in meta["genres"]])
        if meta.get("season") is not None:
            tag.setTvShowTitle(meta.get("_title") or meta.get("name") or "")
            tag.setSeason(int(meta["season"]))
            tag.setEpisode(int(meta.get("episode") or 0))
    tag.setPlot(plot)
    apply_watched(li, key, list(extra_context or []))   # např. „Odebrat z Pokračovat“ z výpisu
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(
        HANDLE, build_url(action="play_dav", slot=api.slot, path=f["path"], name=f["name"]), li, isFolder=False)


def add_hs_file(f, extra_context=None):
    """Soubor z HellSpy ve výpisu hledání. Odkaz se dohledává až při přehrání."""
    key = f"hs:{f['id']}:{f['hash']}"
    label = f"{f['name']}  [COLOR FF9A9A9A]{f.get('size_h', '')}[/COLOR]"
    li = xbmcgui.ListItem(label=label)
    tag = li.getVideoInfoTag()
    tag.setMediaType("video")
    tag.setTitle(f["name"])
    tag.setPlot(f"{HS_TAG}  {f.get('size_h', '')}")
    if f.get("duration"):
        tag.setDuration(int(f["duration"]))
    ctx = [(L(30070), runplugin(action="download_hs", id=f["id"], hash=f["hash"], name=f["name"]))]
    apply_watched(li, key, ctx + (extra_context or []))
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(
        HANDLE, build_url(action="play_hs", id=f["id"], hash=f["hash"], name=f["name"]), li, isFolder=False)


# --- meta a streamy -------------------------------------------------------------

def meta_for(apis, meta_type, item_id):
    """Detail titulu — TMDB, Luna/Sosáč, veřejný katalog Sosáče, Cinemeta (viz `Engine._meta_for`)."""
    return engine_of(apis)._meta_for(meta_type, item_id)


def load_meta(apis, ctype, item_id, series_id=None):
    """Meta titulu (u epizody meta seriálu + konkrétní video) pro popis a OSD."""
    return engine_of(apis).meta(ctype, item_id, series_id)


def title_queries(apis, meta, video, ctype, alt=None, strict=True):
    """Dotazy pro fulltextové zdroje a filtr názvu souboru — viz `Engine._title_queries`.
    `strict=False` (ruční „Zkusit uvolněný fulltext") pustí soubor se slovy kdekoli v názvu."""
    return engine_of(apis)._title_queries(meta, video, ctype, alt, strict)


DIRECT_SOURCES = ("ws", "hs", "st", "fs", "pt")   # fulltextové zdroje, kde bývá tentýž soubor jako u Luny


def drop_duplicates(streams):
    """Soubor nalezený přes Lunu i napřímo je jeden soubor — párování podle názvu a
    velikosti dělá jádro (`Engine._merge_direct`); tady se jen označí přímé nálezy."""
    for s in streams:
        parse_stream(s)
        if s.get("source") in DIRECT_SOURCES:
            s["_direct"] = True
    return Engine._merge_direct(streams)


def load_meta_video(meta, item_id):
    """Díl z meta seriálu podle id epizody, u filmu None (pro hledání na WebShare)."""
    _base, season, episode = split_episode_id(item_id)
    if season is None:
        return None
    return next((v for v in meta.get("videos") or []
                 if int(v.get("season") or 0) == season and int(v.get("episode") or 0) == episode), None)


def collect_streams(apis, ctype, item_id, meta, alt=None, progress=None, strict=True, errors=None, track=True,
                    refresh=False):
    """Streamy ze všech zdrojů, vyfiltrované a seřazené podle nastavení — `Engine.raw_streams`.

    Každý zdroj běží pod vlastní pojistkou jádra: když selže (vypnutý addon Luny,
    výpadek WebShare…), jeho chyba přijde do `errors` jako `SourceFailure` a hledá
    se dál v ostatních; co s tím udělat (upozornit), řeší volající. `progress`,
    je-li dán, dostává `set(done, total)` po každé fázi — čtení hlaviček je
    z nich zdaleka nejdelší —, `source(label, count)` po dokončení každého
    jednotlivého zdroje, ať je vidět odkud kolik streamů zatím přišlo, a
    `audio(done, total)` v průběhu čtení hlaviček, ať je vidět kolik je ověřeno.
    """
    errors = [] if errors is None else errors
    failures = []
    engine = engine_of(apis)
    started = time.time()
    if track:   # práce na pozadí (prefetch, Hlídané) počká, než se hledání dokončí — viz `wait_for_foreground_search`
        xbmcgui.Window(10000).setProperty(SEARCH_PROP, str(started))
    try:
        streams = engine.raw_streams(ctype, item_id, alt, on_progress=progress.set if progress else None,
                                     failures=failures, strict=strict, meta_video=(meta, load_meta_video(meta, item_id)),
                                     on_source_done=progress.source if progress else None,
                                     on_audio_progress=progress.audio if progress else None,
                                     **({"refresh": True} if refresh else {}))
    finally:
        if track:
            xbmcgui.Window(10000).clearProperty(SEARCH_PROP)
        errors.extend(SourceFailure(label, err) for label, err in failures)
        remember_ws_token(engine.ws)
    xbmc.log(f"[{ADDON_ID}] streamy {item_id}: {describe_timings(engine.last_timings)}", xbmc.LOGINFO)
    if track:   # do statistik jen hledání, na které uživatel čekal (ne zahřívání dalšího dílu)
        usage.timing(STORE, time.time() - started)
        usage.count(STORE, "search" if streams else "empty")
        if not streams:
            usage.miss(STORE, item_id, bare_title(meta or {}))
    return streams


def describe_timings(t):
    """Jeden řádek do logu: kolik která fáze hledání streamů trvala (`Engine.last_timings`)."""
    # kam se u čtení hlaviček ztrácí čas (`Engine._fill_audio`): ze serveru / čtení / pozadí / zpracování
    detail = t.get("hlavičky detail") or {}
    kde = f" [{', '.join(f'{k} {v:.2f}' for k, v in detail.items())}]" if detail else ""
    if t.get("cache"):
        druh = " (starší, obnovuje se na pozadí)" if t.get("stará cache") else " (částečná)" if t.get("částečná cache") else ""
        return (f"z cache{druh}, celkem {t.get('celkem', 0)} s · hlavičky {t.get('hlavičky', 0)}{kde}"
                f" ({t.get('hlaviček', 0)}, nedočteno {t.get('hlaviček nedočteno', 0)}) · {t.get('streamů', 0)} streamů")
    def poradi(kv):
        """Zdroj, který nestihl rozpočet, má místo času značku „>20s“ (`str`) — řadí se
        nakonec. Bez tohohle rozlišení `sorted()` porovná `str` s `float` a spadne:
        `TypeError: '<' not supported between instances of 'str' and 'float'` (pád
        nahlášený z 6.2.7). Stačilo, aby se jeden zdroj opozdil a jiný odpověděl."""
        return (1, 0.0) if isinstance(kv[1], str) else (0, kv[1])
    zdroje = ", ".join(f"{k} {v}" for k, v in sorted((t.get("zdroje") or {}).items(), key=poradi))
    return (f"celkem {t.get('celkem', 0)} s · hlavní {t.get('hlavni', 0)} · souběžně {t.get('souběžně', 0)}"
            f" ({zdroje}){' · znovu česky' if t.get('znovu česky') else ''} · úložiště navíc {t.get('úložiště navíc', 0)}"
            f" · hlavičky {t.get('hlavičky', 0)}{kde} ({t.get('hlaviček', 0)}, nedočteno {t.get('hlaviček nedočteno', 0)},"
            f" na pozadí {t.get('hlavičky na pozadí', 0)}, předčteno {t.get('předčteno', 0)})"
            f"{' · pozdě: ' + ', '.join(t['pozdě']) if t.get('pozdě') else ''}"
            f" · {t.get('streamů', 0)} streamů (sloučeno {t.get('sloučeno', 0)})")


def storage_first(streams):
    """Soubory z vlastního úložiště vždy na začátek, jinak ve stejném pořadí.

    Mezi desítkami streamů z WebShare a HellSpy se vlastní soubor ztrácel (u Bláznivé
    dovolené byl 5. z 61 a uživatel ho nenašel) — přitom je to ten, kvůli kterému
    úložiště má, a přehrává se bez závislosti na cizí službě."""
    return [s for s in streams if s.get("source") == "dav"] + [s for s in streams if s.get("source") != "dav"]


def stream_signature(s):
    """Co si z vybraného streamu pamatovat: zdroj, kvalita a jazyky zvuku."""
    parse_stream(s)
    return {"source": s.get("source") or "", "quality": s.get("quality_rank") or 0,
            "langs": sorted(s.get("langs") or [])}


def preferred_stream(streams, pref):
    """Stream odpovídající zapamatované volbě, nebo None (→ dialog / nejlepší).

    Nejdřív přesná shoda (zdroj, kvalita, všechny jazyky), pak aspoň zdroj a
    kvalita — u dalšího dílu bývá zvuk stejný, ale ne vždy jsou stejné značky.
    """
    if not pref:
        return None
    want = set(pref.get("langs") or [])
    for strict in (True, False):
        for st in streams:
            parse_stream(st)
            if (st.get("source") or "") != pref.get("source") or float(st.get("quality_rank") or 0) != float(pref.get("quality") or 0):
                continue
            if strict and not want <= set(st.get("langs") or []):
                continue
            return st
    return None


def pref_param(s):
    sig = stream_signature(s)
    return f"{sig['source']}|{sig['quality']}|{','.join(sig['langs'])}"


def pref_from_param(value):
    try:
        source, quality, langs = (value or "").split("|", 2)
    except ValueError:
        return None
    return {"source": source, "quality": float(quality or 0), "langs": [x for x in langs.split(",") if x]}


SOURCE_GROUP = {"main": "Luna", "search": "WebShare", "ws": "WebShare",
                "sosac": "Sosáč", "hs": "HellSpy", "st": "Sledujteto", "fs": "FastShare", "pt": "Přehraj.to", "cz": "CZtor",
                "dav": L(30405, "Úložiště")}


def stream_tracks(s):
    """Zvukové stopy streamu jako (jazyk, kanály, kodek) DOHROMADY za stopu —
    aby šlo filtrovat kombinaci (např. CZ 5.1), a ne párovat jazyk a kanály
    nezávisle přes různé stopy (CZ 2.0 + EN 5.1 by jinak filtru „CZ a 5.1"
    vyhovělo taky, i když žádná stopa ve skutečnosti CZ 5.1 není).

    Kodek zná jen stream, u kterého se přečetla hlavička souboru (`_tracks`) —
    zdroje samy o kodeku nic neříkají, proto ho ostatní stopy mají `None`.
    """
    tracks = s.get("_tracks") or []
    if tracks:
        return [{"lang": t.get("lang"), "channels": t.get("channels"), "codec": t.get("codec")} for t in tracks]
    raw = s["label"]
    for junk in ("(WS)", "Sosáč"):
        raw = raw.replace(junk, "")
    raw = raw.strip()
    channels = s.get("channels") or {}
    langs = set(s.get("langs") or []) | langs_from_name(raw)
    return [{"lang": code, "channels": (f"{channels[code]:.1f}" if code in channels else None), "codec": None}
            for code in langs] or [{"lang": None, "channels": None, "codec": None}]


def stream_facets(s):
    """Kvalita, zvuk (jazyk/kanály/kodek), titulky a zdroj — přesně to, co vidí
    uživatel v `stream_label`, jen bez barev a řádkování. Používá to i filtr
    streamů, aby nabízel a pároval přesně to, co je v řádku vidět.
    """
    parse_stream(s)
    raw = s["label"]
    for junk in ("(WS)", "Sosáč"):
        raw = raw.replace(junk, "")
    raw = raw.strip()
    tracks = stream_tracks(s)
    subs = set(s.get("subs") or []) | subs_from_name(raw)
    return {
        "quality_rank": s.get("quality_rank") or 0,
        "langs": {t["lang"] for t in tracks if t["lang"]},
        "channels": {t["channels"] for t in tracks if t["channels"]},
        "codecs": {t["codec"] for t in tracks if t["codec"]},
        "subs": subs,
        "source": "Sdilej.cz" if s.get("source") == "fs" and fs_provider() == "sdilej"
        else SOURCE_GROUP.get(s.get("source"), s.get("source") or ""),
        "tracks": tracks,
    }


def apply_stream_filter(streams, fq="", flang="", fch="", fcodec="", fsub="", fsrc=""):
    """Streamy, které vyhovují filtru z dialogu výběru (`filter_dialog`). Prázdný filtr = beze změny.

    Jazyk, kanály a kodek se ověřují na téže stopě (viz `stream_tracks`) — stream
    projde, jen když aspoň jedna jeho stopa vyhovuje všem třem najednou.
    """
    want_q = {x for x in fq.split(",") if x}
    want_lang = {x for x in flang.split(",") if x}
    want_ch = {x for x in fch.split(",") if x}
    want_codec = {x for x in fcodec.split(",") if x}
    want_sub = {x for x in fsub.split(",") if x}
    want_src = {x for x in fsrc.split(",") if x}
    if not (want_q or want_lang or want_ch or want_codec or want_sub or want_src):
        return list(streams)
    out = []
    for st in streams:
        f = stream_facets(st)
        if want_q and str(f["quality_rank"]) not in want_q:
            continue
        if want_sub and not (f["subs"] & want_sub):
            continue
        if want_src and f["source"] not in want_src:
            continue
        if (want_lang or want_ch or want_codec) and not any(
            (not want_lang or t["lang"] in want_lang)
            and (not want_ch or t["channels"] in want_ch)
            and (not want_codec or t["codec"] in want_codec)
            for t in f["tracks"]
        ):
            continue
        out.append(st)
    return out


FILTER_KINDS = ("q", "lang", "ch", "codec", "sub", "src")


def filter_params(filt):
    """{"q": [...], "lang": [...], …} → parametry `apply_stream_filter` (`fq`, `flang`, …)."""
    return {"f" + k: ",".join((filt or {}).get(k) or []) for k in FILTER_KINDS}


def filter_dialog(streams, active=None):
    """Výběr filtru podle toho, co se u titulu doopravdy našlo → {"q": [...], …}, nebo None
    (zrušeno, nebo není podle čeho filtrovat). Sdílí ho složka se seznamem streamů
    dialog výběru streamu (`choose_stream`)."""
    facets = [stream_facets(st) for st in streams]
    qualities = sorted({f["quality_rank"] for f in facets if f["quality_rank"]}, reverse=True)
    langs = sorted({c for f in facets for c in f["langs"]})
    # kanály sestupně (7.1 → 1.0), ne abecedně — "5.1" by jinak stálo za "7.1"
    channels = sorted({c for f in facets for c in f["channels"]}, key=lambda c: -float(c))
    codecs = sorted({c for f in facets for c in f["codecs"]})
    subs = sorted({c for f in facets for c in f["subs"]})
    sources = sorted({f["source"] for f in facets if f["source"]})

    options, kinds = [], []
    for q in qualities:
        options.append(f"{L(30208, 'Kvalita')}: {QUALITY_NAMES.get(q, '')}")
        kinds.append(("q", str(q)))
    for code in langs:
        options.append(f"{L(30209, 'Zvuk')}: {code}")
        kinds.append(("lang", code))
    for ch in channels:
        options.append(f"{L(30215, 'Kanály')}: {ch}")
        kinds.append(("ch", ch))
    for codec in codecs:
        options.append(f"{L(30216, 'Kodek')}: {codec}")
        kinds.append(("codec", codec))
    for code in subs:
        options.append(f"{L(30210, 'Titulky')}: {code}")
        kinds.append(("sub", code))
    for src in sources:
        options.append(f"{L(30211, 'Zdroj')}: {src}")
        kinds.append(("src", src))
    if not options:
        notify(L(30212, "Není podle čeho filtrovat"))
        return None

    active = active or {}
    preselect = [i for i, (kind, val) in enumerate(kinds) if val in (active.get(kind) or [])]
    chosen = xbmcgui.Dialog().multiselect(L(30213, "Filtr streamů"), options, preselect=preselect)
    if chosen is None:
        return None
    new = {k: [] for k in FILTER_KINDS}
    for i in chosen:
        kind, val = kinds[i]
        new[kind].append(val)
    if any(new.values()):
        # zapamatovat jen skutečný filtr, ne jeho úplné zrušení — viz „Použít poslední filtr“.
        # Soubor je v profilu tohohle Kodi, takže si ho každá instalace pamatuje sama za sebe.
        STORE.set_last_stream_filter(new)
    return new


FULLTEXT = "fulltext"


def reading_progress(count, total):
    """Ukazatel v rohu „Dočítám údaje N/M“, zatímco je výběr streamu otevřený — `Dialog().select`
    se za běhu měnit nedá, `DialogProgressBG` ano. `count()` vrátí, na kolik streamů se ještě čeká
    (`Engine.refresh_media(..., apply=False)`). Vrátí funkci, která ukazatel zavře."""
    stop = threading.Event()
    bar = xbmcgui.DialogProgressBG()
    bar.create(L(30000, "Nokturno"), "")

    closed = threading.Lock()   # zavírá ho buď konec dočítání, nebo zavření výběru — jen jednou

    def close_bar():
        if closed.acquire(blocking=False):
            bar.close()

    def run():
        while True:
            left = count()
            if not left:
                # hotovo: ukazatel pryč (jinak se v rohu dál točí kolečko na 100 %) a krátké oznámení
                close_bar()
                if not stop.is_set():
                    notify(L(30006, "Údaje dočteny – klikni na Obnovit modal streamů"))
                return
            done = total - left
            bar.update(int(done * 100 / total), message=f"{L(30005, 'Dočítám údaje o streamech')} {done}/{total}")
            if stop.wait(0.5):
                return
    worker = threading.Thread(target=run, name="nokturno-reading", daemon=True)
    try:
        worker.start()
    except RuntimeError:
        # „can't start new thread" (Android, 10.10.2): ukazatel je jen kosmetika, výběr jede bez něj
        close_bar()
        return lambda: None

    def close():
        stop.set()
        worker.join(1)
        close_bar()
    return close


def choose_stream(streams, preferred=None, relax=False, expand=None, refresh=None):
    """Výběr streamu v dialogu na dva řádky — jediný způsob výběru od `5.2.14~beta2` (klik ve výpisu,
    Přehrát v detailu, widget, TMDb Helper), od `beta4` i jediné místo (výpis streamů jako složka zrušen).
    Nahoře Filtr streamů, Zrušit filtr, Použít poslední filtr. `preferred` (zapamatovaná volba
    u seriálu) je předvybraný. `relax=True` přidá dole „Zkusit uvolněný fulltext“ a jeho volba
    vrátí `FULLTEXT`. `expand()` vrátí seznam se sloučenými verzemi (`_alts`) každou zvlášť —
    nabízí se jako „Zobrazit všechny streamy“ před fulltextem, jen když je co rozbalit.
    `refresh(streams)` (`Engine.refresh_media`) doplní hlavičky dočtené po `PROBE_DEADLINE`
    a vrátí, na kolik streamů se ještě čeká — dokud nějaké, je nahoře „Obnovit – dočteno N/M“.
    Vrací stream, `FULLTEXT`, nebo None."""
    active = {}
    if setting("stream_filter_last") == "true":
        # „Automaticky použít poslední filtr“ — jen když u titulu něco nechá, jinak
        # by dialog začínal hláškou „Filtr nic nenechal“
        last = STORE.last_stream_filter() or {}
        last = {k: list(last.get(k) or []) for k in FILTER_KINDS}
        if any(last.values()) and apply_stream_filter(streams, **filter_params(last)):
            active = last
    wait_total = 0
    while True:
        waiting = refresh(streams) if refresh else 0
        wait_total = max(wait_total, waiting) if waiting else 0
        shown = apply_stream_filter(streams, **filter_params(active))
        if not shown:
            notify(L(30214, "Filtr nic nenechal, zobrazeny všechny streamy"), xbmcgui.NOTIFICATION_WARNING)
            active, shown = {}, list(streams)
        entries = []   # (popisek, volba) nad seznamem streamů
        if waiting:
            entries.append((L(30999, "Obnovit modal streamů"), "refresh"))
        if len(streams) > 1:
            on = any(active.values())
            count = f"({len(shown)}/{len(streams)})" if on else f"({len(streams)})"
            entries.append((f"[B]{L(30213, 'Filtr streamů')}[/B]  {count}", "filter"))
            if on:
                entries.append((L(30363, "Zrušit filtr"), "clear"))
            last = STORE.last_stream_filter() or {}
            last = {k: list(last.get(k) or []) for k in FILTER_KINDS}
            if any(last.values()) and last != {k: list(active.get(k) or []) for k in FILTER_KINDS}:
                last_count = len(apply_stream_filter(streams, **filter_params(last)))
                if last_count:   # 0 shodných by bylo jen matoucí tlačítko do prázdna
                    entries.append((f"{L(30364, 'Použít poslední filtr')}  ({last_count})", "last"))
        rows = []
        for label, _v in entries:
            rows.append(xbmcgui.ListItem(label=label))
        for st in shown:
            top, bottom = stream_lines(st)
            if st.get("_alts"):
                top = f"{top}  [COLOR {GREY}]×{len(st['_alts']) + 1}[/COLOR]"
            row = xbmcgui.ListItem(label=top, label2=bottom)
            icon = quality_icon(st)
            if icon:
                row.setArt({"icon": icon, "thumb": icon})
            rows.append(row)
        tail = []   # volby pod seznamem streamů
        hidden = sum(len(st.get("_alts") or ()) for st in streams)
        if expand and hidden:
            tail.append("all")
            rows.append(xbmcgui.ListItem(label=f"{L(30558, 'Zobrazit všechny streamy')}  ({len(streams) + hidden})"))
        if relax:
            tail.append(FULLTEXT)
            rows.append(xbmcgui.ListItem(label=L(30335, "Hledat volněji podle názvu souboru")))
        shown, tail = list(shown), list(tail)   # dočítání na pozadí nesmí za běhu dialogu změnit, co se počítá z idx
        focus = next((i for i, st in enumerate(shown) if st is preferred), None)
        close_bar = reading_progress(lambda: refresh(streams, apply=False), wait_total) if waiting else None
        try:
            idx = xbmcgui.Dialog().select(L(30024), rows, useDetails=True,
                                          preselect=len(entries) + focus if focus is not None else -1)
        finally:
            if close_bar:
                close_bar()
        if idx < 0:
            return None
        if idx >= len(entries) + len(shown):
            pos = idx - len(entries) - len(shown)
            if not 0 <= pos < len(tail):   # idx mimo řádky (10.11.0, IndexError) – otevřít dialog znovu
                continue
            if tail[pos] == FULLTEXT:
                return FULLTEXT
            streams = expand()
            continue
        if idx >= len(entries):
            return shown[idx - len(entries)]
        volba = entries[idx][1]
        if volba == "refresh":
            continue
        if volba == "filter":
            new = filter_dialog(streams, active)
            if new is not None:
                active = new
        elif volba == "clear":
            active = {}
        else:
            active = last


def browsing_nokturno():
    """Běží plugin z výpisu Nokturna v okně Videa (klik na položku)? Z widgetu, domovské
    obrazovky nebo detailu otevřeného odtamtud je aktivní jiné okno a kontejner není náš —
    změřeno na Office 2026-09-14: klik ve výsledcích = okno 10025 + `plugin.video.nokturno`,
    widget/domovská obrazovka = 10000 + prázdný `Container.PluginName`."""
    return bool(xbmc.getCondVisibility("Window.IsMedia")) and xbmc.getInfoLabel("Container.PluginName") == ADDON_ID


def chose_from_start():
    """Vybral uživatel u rozkoukané položky „Přehrát od začátku“? Kodi předává pluginu čtvrtý
    argument `resume:true|false` (ScriptRunner) a resume point z `setResolvedUrl` volbu přebije
    (`CPluginDirectory::GetPluginResult` → STARTOFFSET_RESUME). `resume:false` ale přijde i z
    `Player.Open` (karta HA, Up Next) — tam se pokračovat má, proto jen když se hraje právě
    zaměřená rozkoukaná položka (klik v seznamu, widgetu, kontextové menu)."""
    if len(sys.argv) < 4 or sys.argv[3] != "resume:false":
        return False
    if not xbmc.getCondVisibility("ListItem.IsResumable"):
        return False
    focused = urllib.parse.urlsplit(xbmc.getInfoLabel("ListItem.FileNameAndPath"))
    mine = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))
    return bool(mine) and dict(urllib.parse.parse_qsl(focused.query)) == mine


def format_duration(seconds):
    """`9722` → `1:39` (h:mm) — kompaktní zápis stopáže do popisku streamu."""
    h, m = divmod(int(seconds) // 60, 60)
    return f"{h}:{m:02d}" if h else f"{m} min"


VIDEO_TAGS = (
    (r"\b(?:x|h)\.?265\b|\bhevc\b", "HEVC"),
    (r"\b(?:x|h)\.?264\b|\bavc\b", "H.264"),
    (r"\bav1\b", "AV1"),
    (r"\b10[ ._-]?bit\b", "10bit"),
)


def video_info(s, name):
    """Druhý řádek výběru streamu: rozlišení (jen přečtené z hlavičky souboru — z názvu
    se neví), video kodek z názvu souboru a formát obrazu (DV, HDR10, 3D…) z `video_tags`,
    tedy z hlavičky souboru, jinak z názvu."""
    import re as _re
    parts = []
    media = s.get("_media") or {}
    if media.get("width") and media.get("height"):
        parts.append(f"{media['width']}×{media['height']}")
    low = (name or "").lower()
    for pattern, tag in VIDEO_TAGS:
        if _re.search(pattern, low) and tag not in parts:
            parts.append(tag)
    parts += video_tags(dict(s, label=name))
    return " ".join(parts)


def stream_label_parts(s):
    """Díly popisku streamu (každý už obarvený) — skládá je `stream_label` do jednoho
    řádku pro výpis a `stream_list_item` do dvou řádků pro dialog výběru."""
    parse_stream(s)
    tag = source_tag(s.get("source"))
    raw = s["label"]
    for junk in ("(WS)", "Sosáč"):
        raw = raw.replace(junk, "")
    raw = raw.strip()
    quality = QUALITY_NAMES.get(s.get("quality_rank", 0), "")
    if quality and s.get("_estimated"):
        quality = "~" + quality   # jádro kvalitu odhadlo z velikosti (název ji neřekl)
    elif not quality and s.get("size_gb"):
        # soubor bez kvality v názvu (typicky přímo z WebShare): odhad podle velikosti, s vlnovkou
        quality = "~" + QUALITY_NAMES.get(estimate_rank(s["size_gb"]), "")
    import re as _re
    rest = _re.sub(r"\b(4K|2K|Full HD|UHD|QHD|FHD|HD|SD)\b", "", raw)   # \b → „HDR“ zůstane celé
    rest = " ".join(rest.replace(" - ", " ").split())
    if s.get("source") == "sosac":
        rest = ""   # u Sosáče je zbytek jen jazyk, ten je už ve zvuku

    # Kvalita je první — na ni se v seznamu kouká nejdřív. Vše, co nemá vlastní
    # barvu (žádný [COLOR] okolo), Kodi vykreslí bílou textovou barvou skinu;
    # na vybrané položce s bílým podkladem to pak úplně zmizí. Proto má i
    # velikost výslovnou barvu (GREY se na bílém podkladu čte jako tmavý text).
    head = []
    if s.get("_storage"):
        # vlastní soubor: štítek úložiště jako první, ne až za zvukem a velikostí na konci řádku
        head.append(f"[COLOR {DAV_COLOR}][B]{s['_storage']}[/B][/COLOR]")
        tag = ""
    if s.get("_loose"):
        # z ručního „Zkusit fulltext" — přísný filtr ho zahodil jako podobný,
        # ale možná jiný titul; uživatel to musí posoudit sám podle názvu souboru
        head.append(f"[COLOR {WARN_COLOR}]?[/COLOR]")
    quality_text = f"[COLOR {QUALITY_COLORS.get(s.get('quality_rank', 0), GREY)}][B]{quality or raw}[/B][/COLOR]"
    audio, langs, seen_langs = [], [], set()
    tracks = s.get("_tracks") or []
    if tracks:
        # přečteno z hlavičky souboru: každá stopa zvlášť i s kodekem
        for t in tracks:
            inside = " ".join(x for x in (t.get("codec"), t.get("channels"), t.get("lang")) if x)
            if inside:
                audio.append(f"[COLOR {LANG_COLORS.get(t.get('lang'), GREY)}][{inside}][/COLOR]")
            code = t.get("lang")
            if code and code not in seen_langs:
                seen_langs.add(code)
                langs.append(f"[COLOR {LANG_COLORS.get(code, GREY)}][B]{code}[/B][/COLOR]")
    else:
        # zdroj o stopách mlčí — poskládá se z toho, co je po ruce
        channels = s.get("channels") or {}
        pref = PREF_LANGS[int(setting("pref_lang", "0"))]
        # jazyk odhadnutý z názvu souboru (`_langs_from_name` z jádra) leží přímo v `langs`,
        # ale ověřený není — vlnovka jako u odhadu, který se do `langs` nedostal
        guessed = set(s.get("langs") or []) if s.get("_langs_from_name") else set()
        known = set(s.get("langs") or []) - guessed
        for code in sorted(known | guessed | langs_from_name(raw), key=lambda c: (c != pref, c)):
            mark = "" if code in known else "~"
            txt = f"{mark}{code}"
            langs.append(f"[COLOR {LANG_COLORS.get(code, GREY)}][B]{txt}[/B][/COLOR]")
            if code in channels:
                txt += f" {channels[code]:.1f}"
            audio.append(f"[COLOR {LANG_COLORS.get(code, GREY)}][{txt}][/COLOR]")
    # klíče jako v nastavení „stream_layout“ (`STREAM_PARTS`); co uživatel v pořadí nemá, se nezobrazí
    parts = {"head": head, "quality": quality_text, "audio": "  ".join(audio), "langs": "  ".join(langs),
             "size": "", "length": "", "bitrate": "", "subs": "", "source": "", "file": "", "video": ""}
    if s.get("size_gb"):
        parts["size"] = f"[COLOR {GREY}][B]{s['size_gb']:.1f} GB[/B][/COLOR]"
    if s.get("_length_s"):
        mark = "~" if s.get("_length_est") else ""
        parts["length"] = f"[COLOR {GREY}]{mark}{format_duration(s['_length_s'])}[/COLOR]"
    if s.get("bitrate"):
        mark = "~" if s.get("_bitrate_est") else ""
        parts["bitrate"] = f"[COLOR {GREY}]{mark}{s['bitrate']:g} Mb/s[/COLOR]"
    subs = set(s.get("subs") or []) | subs_from_name(raw)
    if subs:
        parts["subs"] = f"[COLOR {GREY}]Tit.: {' '.join(sorted(subs))}[/COLOR]"
    if tag:
        parts["source"] = tag
    if rest and quality:
        parts["file"] = f"[COLOR {GREY}]{rest}[/COLOR]"
    video = video_info(s, s.get("_ws_name") or raw)
    if video:
        parts["video"] = f"[COLOR {GREY}]{video}[/COLOR]"
    return parts


# Co ukazovat u streamu a v jakém pořadí (nastavení „stream_layout“, od `5.2.14~beta4`): `a,b|c,d`,
# svislítko odděluje horní a dolní řádek dialogu. Nahradilo šest přepínačů show_size a spol.
STREAM_PARTS = ("langs", "size", "video", "audio", "bitrate", "length", "subs", "source", "file")
STREAM_LAYOUT_DEFAULT = "langs,size|video,audio,bitrate,length,subs,source,file"
_OLD_SHOW = {"size": "show_size", "length": "show_length", "source": "show_source", "file": "show_file",
             "subs": "show_subs", "bitrate": "show_bitrate"}


def stream_layout():
    """(horní řádek, dolní řádek) jako seznamy klíčů. Neplatná hodnota → výchozí pořadí.
    Výchozí hodnota u instalace, která dřív vypnula některý přepínač `show_*`, ho vynechá."""
    raw = setting("stream_layout", STREAM_LAYOUT_DEFAULT).strip()
    rows = _remote_setup().parse_order(raw, set(STREAM_PARTS)) if raw else None
    if rows is None:
        rows = _remote_setup().parse_order(STREAM_LAYOUT_DEFAULT, set(STREAM_PARTS))
    if raw in ("", STREAM_LAYOUT_DEFAULT):
        off = {key for key, old in _OLD_SHOW.items() if setting(old, "true") == "false"}
        rows = [[k for k in row if k not in off] for row in rows]
    return rows[0], rows[1]


def stream_layout_reset():
    ADDON.setSetting("stream_layout", STREAM_LAYOUT_DEFAULT)
    notify(L(30512, "Pořadí údajů u streamu vráceno na výchozí"))


QUALITY_ICON_DIR = os.path.join(ADDON.getAddonInfo("path"), "resources", "media", "quality")
QUALITY_ICON_KEYS = {4: "4k", 3.5: "2k", 3: "fhd", 2: "hd", 1: "sd"}


def quality_icon(s):
    """Odznak kvality do dialogu výběru (UHD 4K, FHD 1080…, s HDR i DV) — cesta k PNG, nebo "".
    Obrázky kreslí `tools/make_quality_icons.py`."""
    parse_stream(s)
    key = QUALITY_ICON_KEYS.get(s.get("quality_rank") or 0)
    if not key:
        return ""
    tags = video_info({}, s.get("_ws_name") or s.get("label") or "").split()
    suffix = "-hdr" if any(t.startswith(("HDR", "DV", "HLG")) for t in tags) else ""
    return os.path.join(QUALITY_ICON_DIR, f"{key}{suffix}.png")


def stream_lines(s):
    """Dva řádky streamu v dialogu výběru (`select(useDetails=True)`) — jednořádkový popisek ani
    výpis streamů jako složka od `5.2.14~beta4` nejsou. Co a v jakém pořadí, určuje `stream_layout()`;
    výchozí je nahoře jazyk a velikost, dole technika.

    Jazyk bez vlnovky přišel od zdroje nebo z hlavičky souboru, s vlnovkou je
    jen odhad z názvu souboru — stejně jako „~4K" u odhadnuté kvality."""
    p = stream_label_parts(s)
    # s odznakem kvality (`quality_icon`) je nápis zbytečný — zůstává jen odhad „~4K“ a neznámá kvalita
    shown_quality = [] if quality_icon(s) and not s.get("_estimated") else [p["quality"]]
    top_keys, bottom_keys = stream_layout()
    top = "  ".join(x for x in p["head"] + shown_quality + [p[k] for k in top_keys] if x)
    bottom = "  ".join(x for x in [p[k] for k in bottom_keys] if x)
    return top, bottom


def mark_playing(key, title="", year=None, kind="movie", stream_url=None, stream_subs=None, stream_langs=None,
                 replay=None, pick=None):
    # stream_url/stream_subs: vnitřní reference zvoleného streamu (ne podepsaný odkaz zdroje,
    # ten vyprší) — služba (Player.save_resume) si je uloží k pozici, ať se dá „Pokračovat ve
    # sledování“ pustit rovnou bez nového hledání (viz add_playable/add_snapshot_item)
    # stream_langs: jazyky zvuku, které o streamu tvrdí zdroj — služba podle nich pozná češtinu
    # i u souboru, jehož stopy jazyk neuvádějí (`Player.apply_tracks`, `tracks.pick_audio`)
    # replay: adresa pluginu, kterou totéž pustí ostatní ve skupině SyncWatch (služba ji
    # pošle, když je tohle Kodi vedoucí)
    xbmcgui.Window(10000).setProperty(PLAYING_PROP, json.dumps(
        {"id": key, "title": title, "year": year, "kind": kind,
         "stream_url": stream_url, "stream_subs": stream_subs, "stream_langs": stream_langs or [],
         "replay": replay, "pick": pick}))


SUBS_DIR = os.path.join(PROFILE, "subs")
SUBS_MAX_BYTES = 2 * 1024 * 1024   # titulky mají desítky kB; víc je omyl odkazu (video)
SUBS_KEEP_S = 2 * 86400
# na titulky se před přehráním čeká nejvýš tolik — WebShare u nedostupného souboru odpovídá
# „temporarily unavailable“ až po 5–13 s (Office 2026-09-16) a přehrání by stálo
SUBS_BUDGET_S = 4.0


def subtitle_refs(apis, chosen, resolved_path, video=None, ctype="movie"):
    """Odkazy na titulky ke zvolenému streamu, případně zpřesněné otiskem souboru.

    Ve výpisu streamů se titulky z OpenSubtitles hledají podle IMDb id, takže sedí
    k titulu, ale ne nutně k tomuhle souboru (jiný sestřih, jiné fps). Otisk je páruje
    přímo se souborem, jenže stojí `Range` dotaz na jeho konec — proto se počítá až tady,
    u jednoho streamu, a jen když k němu nemáme lepší titulky: soubor s vlastními titulky
    ani nález z WebShare (ten je vybraný podle názvu releasu) se tím nezdržuje.
    """
    refs = list(chosen.get("subtitles") or [])
    if not refs or any(not r.startswith("os:") for r in refs):
        return refs
    try:
        presne = engine_of(apis).subtitles_by_hash(resolved_path, video, ctype)
    except Exception as e:  # noqa: BLE001 – titulky nesmí shodit přehrání
        xbmc.log(f"[{ADDON_ID}] titulky podle otisku: {e}", xbmc.LOGINFO)
        return refs
    if not presne:
        return refs
    xbmc.log(f"[{ADDON_ID}] titulky: otisk souboru sedí ({len(presne)})", xbmc.LOGINFO)
    return presne + [r for r in refs if r not in presne]


# služba titulků v dialogu Kodi (P25): jména jazyků, jak je posílá Kodi (`languages`), a zpět
SUBS_KODI_LANGS = {"czech": "CZ", "slovak": "SK", "english": "EN", "hungarian": "HU"}
SUBS_KODI_NAMES = {"CZ": ("Czech", "cs"), "SK": ("Slovak", "sk"), "EN": ("English", "en"), "HU": ("Hungarian", "hu")}


def subs_service_search(apis, p):
    """Nokturno jako služba titulků v dialogu Kodi (přehrávač → Titulky → Stáhnout titulky).

    Bez služby byl dialog prázdný a „Vyhledat titulky“ Kodi zasekl (P25). Kodi volá
    `plugin://…?action=search&languages=…` knihovnou pluginu (`default.py`), takže se volání
    od dialogu pozná podle `languages` (router). Hledá se na OpenSubtitles podle IMDb id
    přehrávaného titulu (`fill_info` ho dává do `VideoPlayer.IMDBNumber`), u dílu i podle
    sezóny a čísla; bez id a při ručním hledání podle textu. Kvótu bere až stažení."""
    engine = engine_of(apis)
    # nejdřív jazyky z nastavení Nokturna: Kodi má výchozí jen angličtinu a málokdo to mění
    # (Office 2026-10-15: dialog nabídl k Matrixu jen anglické titulky)
    chtene = [p.get("preferredlanguage", "")] + p.get("languages", "").split(",")
    jazyky = list(dict.fromkeys(list(engine._subtitle_langs()) + [SUBS_KODI_LANGS[j.strip().lower()] for j in chtene
                                                                  if j.strip().lower() in SUBS_KODI_LANGS]))
    api = engine.osub
    nalezeno = []
    if api is None:
        notify(L(31070, "OpenSubtitles je vypnuté (Nastavení → Zdroje a účty → OpenSubtitles)."))
    elif p.get("action") == "manualsearch":
        nalezeno = api.hledej(jazyky=jazyky, dotaz=p.get("searchstring", ""))
    else:
        imdb = xbmc.getInfoLabel("VideoPlayer.IMDBNumber")
        cislo = lambda label: int(xbmc.getInfoLabel(label) or 0) if xbmc.getInfoLabel(label).isdigit() else 0
        season, episode = cislo("VideoPlayer.Season"), cislo("VideoPlayer.Episode")
        if imdb.startswith("tt"):
            nalezeno = api.hledej_cachovane(imdb, jazyky, season, episode)
        else:
            dotaz = xbmc.getInfoLabel("VideoPlayer.TVShowTitle") or xbmc.getInfoLabel("VideoPlayer.Title")
            nalezeno = api.hledej(jazyky=jazyky, dotaz=dotaz) if dotaz else []
    for t in nalezeno:
        jmeno, iso = SUBS_KODI_NAMES.get(t.get("lang"), ("Unknown", ""))
        li = xbmcgui.ListItem(label=jmeno, label2=t.get("release") or "OpenSubtitles")
        # icon = hodnocení 0–5, thumb = kód jazyka pro vlaječku; otisk souboru = sedí časově
        li.setArt({"icon": "5" if t.get("hash_match") else str(min(4, int(t.get("downloads") or 0) // 1000)),
                   "thumb": iso})
        li.setProperty("sync", "true" if t.get("hash_match") else "false")
        li.setProperty("hearing_imp", "false")
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="subs_download", id=t["file_id"]), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def subs_service_download(apis, file_id):
    """Vybrané titulky z dialogu Kodi: stáhnou se jako u přehrání (UTF-8, jazyk v názvu souboru)
    a Kodi dostane cestu k souboru jako položku výpisu – zkopíruje si ji a zapne."""
    try:
        refs = [f"os:{int(file_id)}"]
    except (TypeError, ValueError):
        refs = []
    for cesta in local_subtitles(apis, refs):
        xbmcplugin.addDirectoryItem(HANDLE, cesta, xbmcgui.ListItem(label=cesta), isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def local_subtitles(apis, refs):
    """Titulky ze zdroje (`ws:<ident>`, odkaz Sosáče) stáhne do profilu a vrátí cesty.

    Kodi pozná jazyk externích titulků jen z názvu souboru a podepsaný odkaz zdroje
    ho neobsahuje, takže služba nevěděla, které titulky jsou české. Jazyk se tu
    určí z textu (`tracks.subtitle_lang`) a zapíše do názvu (`nokturno-….cze.srt`),
    text jde do UTF-8 s BOM — české titulky ve windows-1250 jinak Kodi ukazuje
    s rozsypanou diakritikou. Preferovaný jazyk jde v seznamu první.

    Rozklíčování i stažení běží souběžně a čeká se nejvýš `SUBS_BUDGET_S`; co do té
    doby nedoběhne, přehrání nezdrží (vlákno dožije se svým HTTP timeoutem). Token
    WebShare je v tu chvíli už platný — odkaz na samotný stream se rozklíčoval před
    titulky. Titulky, které se nepodaří rozklíčovat, se vynechají (dřív výjimka
    z `resolve_url` shodila celé přehrání), co se nepodaří stáhnout, jde odkazem."""
    refs = [r for r in refs if r]
    if not refs:
        return []
    try:
        xbmcvfs.mkdirs(SUBS_DIR)
        now = time.time()
        for name in os.listdir(SUBS_DIR):
            path = os.path.join(SUBS_DIR, name)
            if now - os.path.getmtime(path) > SUBS_KEEP_S:
                os.remove(path)
    except OSError as e:
        xbmc.log(f"[{ADDON_ID}] složka titulků: {e}", xbmc.LOGWARNING)

    import hashlib
    from concurrent.futures import wait as wait_futures

    def fetch(ref):
        try:
            link = resolve_url(apis, ref)
        except Errors as e:
            xbmc.log(f"[{ADDON_ID}] titulky {ref}: {e}", xbmc.LOGINFO)
            return None
        if not link:
            return None
        url, _sep, header_part = link.partition("|")
        headers = {"User-Agent": "Mozilla/5.0"}
        headers.update(dict(urllib.parse.parse_qsl(header_part)))
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=8) as resp:
                raw = resp.read(SUBS_MAX_BYTES + 1)
            if not raw or len(raw) > SUBS_MAX_BYTES:
                return link, ""
            text = decode_subtitle(raw)
            lang = subtitle_lang(text)
            name = "nokturno-" + hashlib.sha1(ref.encode("utf-8")).hexdigest()[:10]
            if lang:
                name += "." + FILE_CODES[lang]
            path = os.path.join(SUBS_DIR, f"{name}.{subtitle_format(text)}")
            with open(path, "w", encoding="utf-8-sig") as f:
                f.write(text)
            return path, lang
        except Exception as e:  # noqa: BLE001 – síť, zápis; titulky nesmí shodit přehrání
            xbmc.log(f"[{ADDON_ID}] titulky {ref} se nestáhly, předám odkaz: {e}", xbmc.LOGINFO)
            return link, ""

    pool = ThreadPoolExecutor(max_workers=min(len(refs), 4))
    futures = [pool.submit(fetch, ref) for ref in refs]
    wait_futures(futures, timeout=SUBS_BUDGET_S)
    pool.shutdown(wait=False)
    fetched = []
    for ref, future in zip(refs, futures):
        if not future.done():
            xbmc.log(f"[{ADDON_ID}] titulky {ref}: nestihly se do {SUBS_BUDGET_S:g} s, přehrávám bez nich",
                     xbmc.LOGINFO)
            continue
        if future.result():
            fetched.append(future.result())
    pref = PREF_LANGS[int(setting("pref_lang", "0"))]
    rank = {lang: i for i, lang in enumerate(SUBTITLE_FALLBACK.get(pref, ()))}
    order = sorted(range(len(fetched)), key=lambda i: (rank.get(fetched[i][1], len(rank)), i))
    return [fetched[i][0] for i in order]


def mark_viewed(key, title="", year=None, kind="movie"):
    """Titul, u kterého se právě zobrazily streamy — nezávisle na tom, jestli si
    uživatel nějaký pustí. Vypovídá o zájmu líp než počítání přehrání: spousta
    streamů nejde přehrát vůbec (mrtvý odkaz, region, žádná titulková stopa)
    a to není chyba diváka. Kolikrát za den se to stane, neřeší ani tohle, ani
    služba — dedup „jednou denně" dělá server podle času posledního zobrazení."""
    xbmcgui.Window(10000).setProperty(VIEWED_PROP, json.dumps(
        {"id": key, "title": title, "year": year, "kind": kind}))


def mark_used():
    """Otevření doplňku – službě to stačí pro „naposledy použito“ ve statistikách."""
    xbmcgui.Window(10000).setProperty(USED_PROP, str(int(time.time())))


# Kde se Kodi potkávají (`sync_mode`): 0 = Home Assistant, 1 = dashboard (slepý relay, od
# 8.4.0~beta17 výchozí, viz `migrate_sync_mode_default`).
#
# Třetí volba „HA i dashboard" existovala mezi `9.99.0~sync4` a `6.6.0~beta1`, kdy
# byl relay jediná cesta, jak mít dashboard a zároveň nepřijít o data v kartě HA.
# Od bety 1 chodí do skupiny i samotná integrace (pole „Kód skupiny z Kodi"), takže
# je to zbytečná druhá cesta k témuž — a dvě volby, které dělají totéž, se v UI
# nedají vysvětlit. Kdo má HA a chce dashboard, zadá týž kód i v integraci; HA je
# pak členem skupiny jako každé Kodi. Uložená „2" se při startu překlopí na relay
# (`migrate_sync_mode`).
SYNC_MODE_HA, SYNC_MODE_RELAY = "0", "1"
SYNC_MODE_BOTH_OLD = "2"          # jen pro migraci, do nastavení už se nedostane


def sync_via_relay():
    """Jede synchronizace přes dashboard, ne přes Home Assistant?"""
    return on("sync_enabled", "false") and setting("sync_mode") == SYNC_MODE_RELAY


def sync_via_ha():
    """Jede synchronizace přes Home Assistant?"""
    return on("sync_enabled", "false") and setting("sync_mode") == SYNC_MODE_HA


def migrate_sync_mode():
    """Uložená volba „HA i dashboard" (`2`) přejde na dashboard.

    Dashboard, ne Home Assistant: kdo si „obojí" vybral, chtěl dashboard a HA měl
    navíc. Kartu v HA dohoní tím, že týž kód skupiny zadá i v integraci — tam je
    od 6.6.0 pole „Kód skupiny z Kodi". Oznámení je jednorázové, ale samotné
    přepsání nastavení se dělá bezpodmínečně: volba `2` už v `settings.xml`
    neexistuje a Kodi by na ni spadlo zpátky na výchozí hodnotu.
    """
    # Číst se musí ze souboru, ne přes `getSetting`: volbu `2` už `settings.xml`
    # nezná, takže ji Kodi odmítne načíst (`failed to load value "2" for setting
    # sync_mode` při každém spuštění pluginu i služby) a `getSetting` vrátí výchozí
    # `0`. Podmínka nad ním by tedy nikdy nesedla, migrace by neproběhla a starý
    # zápis by v souboru zůstal napořád — včetně toho hluku v kodi.log.
    try:
        with open(os.path.join(PROFILE, "settings.xml"), encoding="utf-8") as f:
            ulozeno = f.read()
    except (IOError, OSError):
        return
    if not re.search(r'id="sync_mode"[^>]*>%s</setting>' % SYNC_MODE_BOTH_OLD, ulozeno):
        return
    ADDON.setSetting("sync_mode", SYNC_MODE_RELAY)
    notify(L(30688, "Synchronizace jede přes dashboard. S Home Assistantem zadej "
                    "týž kód skupiny i v nastavení integrace."), ms=8000)


def migrate_catalogs_v2():
    """Jednou na instalaci (značka `catalogs_v2`): předvolby vlastních katalogů z bety 1, které uživatel
    nezměnil, zmizí (smazání přes deník, ať se synchronizuje), výsledky zrušených „Filmů ve vysoké kvalitě“
    (`hq_index`) se vyprázdní a koncertní katalogy přejdou do modulu Koncerty. Výjimka menu neshodí;
    značka se zapíše až po úspěchu."""
    if STORE.load("catalogs_v2", ""):
        return
    try:
        for cat in mycats():
            if mycat.beta1_untouched(cat):
                mycat.delete(STORE, cat["id"])
        if STORE.load("hq_index", {}):
            STORE.save("hq_index", {})
        concertcat.migrate_catalogs(STORE)
        STORE.save("catalogs_v2", "1")
    except Exception as e:  # noqa: BLE001 – menu nesmí spadnout
        log_error(f"migrate_catalogs_v2: {e}")


def migrate_sync_mode_default():
    """Od 8.4.0~beta17 je výchozí středisko dashboard, dřív Home Assistant.

    Hodnota se značkou `default="true"` v profilovém settings.xml jde po nové výchozí
    hodnotě, takže kdo synchronizaci přes HA nastavil a volbu střediska nikdy nezměnil,
    přešel by potichu na dashboard. Takovému uživateli se HA zapíše výslovně. Kdo
    synchronizaci nikdy nenastavil, dostane novou výchozí hodnotu. Běží jednou
    (`sync_default_migrated`), jinak by se přepsalo i pozdější vědomé přepnutí."""
    if STORE.load("sync_default_migrated", ""):
        return
    STORE.save("sync_default_migrated", "1")
    try:
        with open(os.path.join(PROFILE, "settings.xml"), encoding="utf-8") as f:
            ulozeno = f.read()
    except (IOError, OSError):
        return    # čerstvá instalace
    if not re.search(r'<setting id="sync_mode" default="true">%s</setting>' % SYNC_MODE_HA, ulozeno):
        return
    if on("sync_enabled", "false") or setting("sync_url").strip() or setting("sync_key").strip():
        ADDON.setSetting("sync_mode", SYNC_MODE_HA)


def sync_settings():
    """(adresa HA, klíč) nebo None. Používá to i „Staženo v HA" a `list_ha_files()` —
    soubory stahuje a podepsané odkazy vydává HA, slepý relay žádné nemá."""
    if not sync_via_ha():
        return None
    url, key = setting("sync_url").strip(), setting("sync_key").strip()
    return (url, key) if url and key else None


def sync_targets():
    """Kam se tohle Kodi synchronizuje: `[("ha", (adresa, klíč))]` nebo
    `[("relay", kód)]`. Prázdný seznam = není kam. Seznam (a ne jedna hodnota)
    zůstal ze dvou středisek naráz — volajícím se tím nic nemění a kdyby se
    někdy vrátilo víc cílů, není co přepisovat."""
    if sync_settings():
        return [("ha", sync_settings())]
    if sync_via_relay() and setting("sync_code").strip():
        return [("relay", setting("sync_code").strip())]
    return []


# Okruhy nastavení a účtů umí jen relay — Home Assistant je střed pro `Store`,
# volby doplňku a přihlášení do jeho rozhraní nepatří (proto je `settings.xml`
# u obou přepínačů schovává, když je vybraný Home Assistant).
SYNC_CIRCLE_SETTINGS = {"watched": "sync_watched", "favourites": "sync_favourites",
                        "history": "sync_history", "watchlist": "sync_watchlist", "catalogs": "sync_catalogs",
                        "concerts": "sync_concerts",
                        "settings": "sync_settings",
                        "accounts": "sync_accounts"}
SYNC_RELAY_ONLY = ("settings", "accounts")


def sync_circles(relay=None):
    """Okruhy zapnuté v nastavení. Prázdný výběr = neposílá se ani nepřijímá nic."""
    if relay is None:
        relay = setting("sync_mode") == SYNC_MODE_RELAY
    return tuple(okruh for okruh, klic in SYNC_CIRCLE_SETTINGS.items()
                 if on(klic, "false" if okruh in SYNC_RELAY_ONLY else "true")
                 and (relay or okruh not in SYNC_RELAY_ONLY))


def sync_values(relay=None):
    """Hodnoty nastavení pro okruhy `settings`/`accounts`, nebo None, když ani
    jeden neběží — pak jádro nastavení vůbec neřeší."""
    circles = sync_circles(relay)
    if not any(okruh in circles for okruh in SYNC_RELAY_ONLY):
        return None
    return kodi_settings.values(ADDON, ADDON_PATH)


def sync_write_settings(changes):
    """Zápis nastavení, které přišlo z druhého Kodi."""
    zapsano = kodi_settings.apply(ADDON, changes)
    if not zapsano:
        return
    if any(k.startswith("ws_") for k in zapsano):
        xbmcgui.Window(10000).clearProperty("nokturno.ws_token")   # jiný účet = nový login
    if any(setsync.circle_of(k) == setsync.CIRCLE_ACCOUNTS for k in zapsano):
        STORE.clear_cache()     # cache patří k účtům, které tu byly do teď
    xbmc.log(f"[{ADDON_ID}] synchronizace přepsala nastavení: {', '.join(sorted(zapsano))}",
             xbmc.LOGINFO)


def sync_relay_once(name=""):
    """Jedno kolo přes relay. Vrací totéž co `sync.sync_once`."""
    return syncbox.sync_once(STORE, setting("sync_code").strip(), circles=sync_circles(True),
                             name=name, settings=sync_values(True),
                             on_settings=sync_write_settings)


def request_sync():
    xbmcgui.Window(10000).setProperty(SYNC_PROP, "1")


def list_ha_files():
    """Soubory stažené integrací do HA — přehratelné z tohohle Kodi přes adresu HA
    (může být i Nabu Casa, pak hraje i mimo síť). Podepsané odkazy dává HA."""
    cfg = sync_settings()
    if not cfg:
        notify(L(30186, "Synchronizace není zapnutá nebo nastavená (u Home Assistantu adresa a klíč, u dashboardu "
                        "kód skupiny)"), xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    base, key = cfg
    try:
        req = urllib.request.Request(base.rstrip("/") + "/api/nokturno/files", headers={"X-Nokturno-Key": key})
        with urllib.request.urlopen(req, timeout=20) as resp:
            files = json.loads(resp.read().decode("utf-8")).get("files") or []
    except Exception as e:  # noqa: BLE001 – HA nedostupná, špatný klíč
        notify(f"{L(30188, 'Synchronizace selhala')}: {str(e)[:80]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    set_content("movies")
    for f in files:
        size = human_size(f.get("size") or 0)
        subs = f"  [COLOR {GREY}]tit.[/COLOR]" if f.get("subtitles") else ""
        li = xbmcgui.ListItem(label=f"{f.get('name', '')}  [COLOR {GREY}]{size}[/COLOR]{subs}")
        li.setProperty("IsPlayable", "true")
        li.getVideoInfoTag().setTitle(f.get("name", ""))
        url = base.rstrip("/") + f.get("path", "")   # podepsaná relativní cesta z HA
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def sync_now():
    """Ruční synchronizace — z hlavního menu i z nastavení.

    V režimu „obojí" se projdou obě střediska; výpadek jednoho nezastaví druhé
    a hlásí se, co se povedlo dohromady."""
    cile = sync_targets()
    jmeno = xbmc.getInfoLabel("System.FriendlyName")
    if not cile:
        notify(L(30186, "Synchronizace není zapnutá nebo nastavená (u Home Assistantu adresa a klíč, u dashboardu "
                        "kód skupiny)"), xbmcgui.NOTIFICATION_WARNING, 5000)
    else:
        odeslano = prijato = 0
        chyby = []
        for kam, cfg in cile:
            if kam == "relay":
                ok, pushed, pulled, why = sync_relay_once(jmeno)
            else:
                ok, pushed, pulled, why = sync_once(STORE, cfg[0], cfg[1], jmeno,
                                                    circles=sync_circles(False))
            odeslano, prijato = odeslano + pushed, prijato + pulled
            if not ok:
                chyby.append(why)
        notify(f"{L(30188, 'Synchronizace selhala')}: {'; '.join(chyby)}" if chyby
               else (L(30187, "Synchronizováno: odesláno %d, přijato %d") % (odeslano, prijato)),
               xbmcgui.NOTIFICATION_ERROR if chyby else xbmcgui.NOTIFICATION_INFO, 5000)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)


def _sync_apply(code):
    """Uloží kód skupiny a zapne synchronizaci přes relay."""
    ADDON.setSetting("sync_code", code)
    ADDON.setSetting("sync_mode", "1")
    ADDON.setSetting("sync_enabled", "true")


def sync_create():
    """Založí skupinu, nebo u existující znovu otevře připojení, a ukáže kód,
    který se opíše na dalším Kodi.

    Kód je zároveň šifrovací klíč — server ho nikdy nevidí a bez něj data nikdo
    nepřečte ani neobnoví. Proto se ukazuje v `textviewer` (jde odrolovat a nechat
    na obrazovce), ne v mizející notifikaci."""
    code = setting("sync_code").strip()
    znovu = bool(code) and syncbox.valid_code(code)
    if not znovu:
        code = syncbox.new_code()
    try:
        syncbox.Relay(syncbox.keys_for(code), syncbox.device_id(STORE)).open_group()
    except syncbox.SyncError as e:
        xbmcgui.Dialog().ok(L(30180, "Synchronizace"), f"{L(30188, 'Synchronizace selhala')}: {e}")
        return
    _sync_apply(code)
    nadpis = L(30679, "Připojení je znovu otevřené. Na dalším Kodi zadej tento kód:") if znovu else L(30671, "Skupina je založená. Na dalším Kodi zadej tento kód:")
    xbmcgui.Dialog().textviewer(L(30180, "Synchronizace"),
                                f"{nadpis}[CR][CR][B]{code}[/B][CR][CR]"
                                f"{L(30680, 'Připojení je otevřené 30 minut.')}[CR]"
                                f"{L(30672, 'Nové zařízení se může kódem připojit do 30 minut.')}")


def sync_join():
    """Připojí tohle Kodi ke skupině podle kódu z prvního Kodi."""
    code = xbmcgui.Dialog().input(L(30673, "Zadej kód skupiny z prvního Kodi"),
                                  defaultt=setting("sync_code").strip())
    if not code:
        return
    if not syncbox.valid_code(code):
        xbmcgui.Dialog().ok(L(30180, "Synchronizace"), L(30675, "Kód nemá správný tvar."))
        return
    code = syncbox.format_code(code)
    # `sync_circles(True)`: středisko se uloží až v `_sync_apply()` po úspěchu, ale
    # připojení je relay z definice — jinak by první kolo vynechalo nastavení a účty
    # právě u zařízení, které je potřebuje nejvíc
    ok, pushed, pulled, why = syncbox.sync_once(STORE, code, circles=sync_circles(True),
                                                name=xbmc.getInfoLabel("System.FriendlyName"),
                                                settings=sync_values(True),
                                                on_settings=sync_write_settings)
    if not ok:
        xbmcgui.Dialog().ok(L(30180, "Synchronizace"), f"{L(30188, 'Synchronizace selhala')}: {why}")
        return
    _sync_apply(code)
    xbmcgui.Dialog().ok(L(30180, "Synchronizace"),
                        f"{L(30674, 'Připojeno. Synchronizace běží na pozadí.')}[CR][CR]"
                        + (L(30187, "Synchronizováno: odesláno %d, přijato %d") % (pushed, pulled)))


def sync_leave():
    """Odhlásí tohle Kodi ze skupiny — na relayi smaže jeho blob. Uložená data
    zůstávají, jen se přestanou vyměňovat."""
    code = setting("sync_code").strip()
    if not code or not syncbox.valid_code(code):
        notify(L(30676, "Zatím žádná skupina"), xbmcgui.NOTIFICATION_WARNING, 5000)
        return
    if not xbmcgui.Dialog().yesno(L(30180, "Synchronizace"), L(30677, "Odejít ze skupiny?")):
        return
    try:
        syncbox.Relay(syncbox.keys_for(code), syncbox.device_id(STORE)).forget()
    except syncbox.SyncError as e:
        log_error(e)   # relay nedostupný: blob tam zůstane, retence ho po čase smaže
    ADDON.setSetting("sync_code", "")
    ADDON.setSetting("sync_enabled", "false")
    notify(L(30678, "Skupina opuštěna."), xbmcgui.NOTIFICATION_INFO, 5000)


def sub_status():
    """Tlačítko v nastavení: kolik dní zbývá z předplatného WebShare."""
    ws = get_webshare()
    if ws is None:
        xbmcgui.Dialog().ok(L(30000), L(30230, "WebShare není zapnutý nebo nemá vyplněný účet."))
        return
    try:
        st = ws.account_status()
    except WebshareError as e:
        xbmcgui.Dialog().ok(L(30000), f"WebShare: {e}")
        return
    if st["vip"]:
        msg = Lf(30231, st["days"], st["until"][:10])
    else:
        msg = L(30232, "VIP není aktivní.")
    xbmcgui.Dialog().ok(L(30000), msg)


def accounts_set():
    """Má uživatel vyplněný aspoň jeden účet nebo zdroj, který účet nepotřebuje nastavit?"""
    return any(setting(k).strip() for k in ("token", "streamuj_username", "ws_username", "st_email", "fs_username",
                                            "tmdb_api_key", "dav1_url", "dav2_url", "dav3_url"))


# --- Nastavit z mobilu -----------------------------------------------------------------

# kategorie nastavení, které jdou vyplnit z mobilu; Pokročilé jsou jen tlačítka akcí,
# Stahování chce cestu vybranou v Kodi
REMOTE_SETUP_CATEGORIES = ("terms", "sources", "storage", "playback", "streamlist", "sync", "stats")
# kategorie, jejíž skupiny se na stránce z mobilu ukážou jako samostatné sekce (ne jako
# nadpisy uvnitř jedné) — "sources" slučuje deset dřívějších kategorií zdrojů/účtů do
# jedné kvůli stropu 20 kategorií v settings.xml, ale na mobilu má vypadat pořád jako
# deset rozbalovacích sekcí, ne jedna s 35 poli
REMOTE_SETUP_SPLIT = ("sources",)
REMOTE_SETUP_TIMEOUT = 1800
# tlačítka z settings.xml, která mají na stránce z mobilu vlastní akci: id → (akce, pole, která čte)
REMOTE_SETUP_ACTIONS = {"luna_find_action": ("luna_find", ["luna_url"]),
                        "luna_check_action": ("luna_check", ["luna_url", "token"]),
                        "terms_show_action": ("terms_show", [])}
STREAM_PART_LABELS = (("langs", 30501), ("size", 30502), ("video", 30503), ("audio", 30504), ("bitrate", 30505),
                      ("length", 30506), ("subs", 30507), ("source", 30508), ("file", 30509))
KODI_TAG_RE = re.compile(r"\[/?(?:B|I|CR|COLOR|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)[^\]]*\]")


def _plain(text):
    return KODI_TAG_RE.sub(" ", text or "").strip()


def _option_label(opt):
    """Popisek volby: číslo = id řetězce, jinak doslovný text (např. „Full HD", „4K")."""
    label = opt.get("label")
    return _plain(L(int(label), opt.text)) if label.isdigit() else label


def _group_fields(group):
    """Pole jedné skupiny `<group>` v `settings.xml`, ve tvaru pro formulář z mobilu."""
    fields = []
    if group.get("id") == "luna":
        fields.append({"type": "info", "label": L(30574, "Jak nastavit Lunu"),
                       "help": L(30575, "").replace("[CR]", "\n")})
    for node in group.findall("setting"):
        kind, control = node.get("type"), node.find("control")
        field = {"id": node.get("id")}
        if node.get("id") == "sync_code":
            # Skupina už je: kód se jen ukáže, aby se dal opsat na další Kodi —
            # je to zároveň šifrovací klíč a přepsat ho omylem by tohle Kodi
            # ze skupiny vyřadilo. Skupina ještě není: pole na opsání kódu
            # z prvního Kodi, služba se podle něj připojí do pěti minut.
            # Zakládání a opuštění zůstává na televizi (`sync_create`/`sync_leave`).
            kod = setting("sync_code").strip()
            if kod:
                fields.append({"type": "info", "label": _plain(L(30664, "Kód skupiny")), "help": kod})
                continue
            field["type"] = "text"
            field["default"] = ""
            field["label"] = _plain(L(30664, "Kód skupiny"))
            field["help"] = _plain(L(30707, "Kód z prvního Kodi, na kterém skupina vznikla. "
                                            "Zapni Synchronizaci, jako středisko zvol Dashboard "
                                            "Nokturna a ulož – toto Kodi se připojí do pěti minut."))
            field["enable"] = [("sync_enabled", "true"), ("sync_mode", "1")]
            fields.append(field)
            continue
        if node.get("id") in REMOTE_SETUP_ACTIONS:
            field["type"] = "action"
            field["action"], field["inputs"] = REMOTE_SETUP_ACTIONS[node.get("id")]
        elif node.get("id") == "stream_layout":
            field["type"] = "order"
            field["items"] = [(key, L(label, key)) for key, label in STREAM_PART_LABELS]
        elif kind == "boolean":
            field["type"] = "bool"
        elif kind == "string":
            field["type"] = ("password" if control is not None and control.find("hidden") is not None
                             else "text")
        elif kind == "integer" and node.find("constraints/options") is not None:
            field["type"] = "choice"
            field["options"] = [(opt.text, _option_label(opt) if opt.get("label")
                                 else opt.text) for opt in node.find("constraints/options")]
        elif kind == "integer" and node.find("constraints/maximum") is not None:
            low = int(node.findtext("constraints/minimum") or 0)
            step = int(node.findtext("constraints/step") or 1)
            high = int(node.findtext("constraints/maximum"))
            field["type"] = "choice"
            field["options"] = [(str(v), str(v)) for v in range(low, high + 1, step)]
        else:
            continue
        field["default"] = (node.findtext("default") or "").strip()
        field["label"] = (_plain(L(int(node.get("label")), node.get("id"))) if node.get("label")
                          else node.get("id"))
        if field["type"] == "order":   # nápověda z Kodi popisuje zápis `a,b|c`, tady jsou šipky
            field["help"] = L(30514, "Šipkami přesuň údaje mezi horním a dolním řádkem dialogu výběru "
                                     "streamu, do Nezobrazovat přesuň, co se nemá ukazovat. Kvalita je "
                                     "vždy obrázek vlevo.")
        elif node.get("help"):
            field["help"] = _plain(L(int(node.get("help"))))
        dep = node.find("dependencies/dependency[@type='enable']")
        if dep is not None and dep.get("setting"):
            field["enable"] = (dep.get("setting"), (dep.text or "").strip())
        elif dep is not None:   # <and> s víc podmínkami (sekce Synchronizace)
            podminky = [(c.get("setting"), (c.text or "").strip())
                        for c in dep.findall("and/condition") if c.get("setting")]
            if podminky:
                field["enable"] = podminky
        fields.append(field)
    return fields


# --- SyncWatch: společné sledování ------------------------------------------------------
#
# Plugin tu jen zakládá skupinu, připojuje se a ukazuje okna. Samotnou synchronizaci
# přehrávání dělá služba (`service.SyncWatchManager`) — běží celou dobu, co je zařízení
# ve skupině, i když plugin dávno skončil. Domlouvají se přes profil (`syncwatch.json`:
# kód a token) a vlastnost okna `SW_PROP` (stav skupiny, který služba zapisuje).

SW_PROP = "nokturno.sw"


def _syncwatch():
    import syncwatch
    return syncwatch


def sw_session():
    return STORE.load("syncwatch", {}) or {}


def sw_status():
    try:
        return json.loads(xbmcgui.Window(10000).getProperty(SW_PROP) or "{}")
    except ValueError:
        return {}


def sw_save(session):
    STORE.save("syncwatch", session)   # služba se sem dívá každou sekundu (`SyncWatchManager`)


def sw_device_name():
    return (xbmc.getInfoLabel("System.FriendlyName") or "Kodi").strip()[:40]


def _swf(sid, fallback, *args):
    """Lokalizovaný řetězec s `%` a zálohou v kódu (nové řetězce Kodi načte až po restartu)."""
    text = L(sid, fallback)
    try:
        return text % args
    except TypeError:
        return fallback % args


def sw_title():
    return L(30800, "SyncWatch")


def sw_entry():
    """Položka SyncWatch v menu: napoprvé (a dokud to uživatel nevypne) návod,
    pak složka skupiny."""
    if not STORE.load("sw_intro_hidden", False):
        if not sw_intro():
            return
    xbmc.executebuiltin("Container.Update(%s)" % build_url(action="sw_menu"))


def _sw_backdrop():
    path = os.path.join(PROFILE, "sw-bg.png")
    if not os.path.exists(path):
        xbmcvfs.mkdirs(PROFILE)
        with open(path, "wb") as f:
            f.write(_solid_rgba_png((13, 11, 20), 255))
    return path


def _sw_button_textures():
    paths = (os.path.join(PROFILE, "sw-btn.png"), os.path.join(PROFILE, "sw-btn-focus.png"))
    for path, rgba in zip(paths, (((92, 68, 150), 230), ((124, 92, 200), 255))):
        if not os.path.exists(path):
            with open(path, "wb") as f:
                f.write(_solid_rgba_png(*rgba))
    return paths


class SyncWatchIntroWindow(xbmcgui.WindowDialog):
    """Návod: jak SyncWatch funguje. Dvě tlačítka — „Rozumím" a „Rozumím,
    příště nezobrazovat"; Zpět okno zavře a do skupiny se nejde."""
    BACK = (9, 10, 13, 92)

    def __init__(self):
        super().__init__()
        self.choice = None
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, _sw_backdrop(), colorDiffuse="FF0D0B14"))
        self.addControl(xbmcgui.ControlLabel(90, 50, 1100, 50, "[B]%s[/B]" % sw_title(),
                                             font="font13", textColor="FFFFFFFF"))
        text = xbmcgui.ControlTextBox(90, 110, 1100, 470, font="font12", textColor="FFE6E1F0")
        self.addControl(text)
        text.setText(L(30801, SW_INTRO_TEXT))
        bg, bg_focus = _sw_button_textures()
        self.ok = xbmcgui.ControlButton(90, 610, 360, 56, L(30802, "Rozumím"), font="font13",
                                        textColor="FFE6E1F0", focusedColor="FFFFFFFF", alignment=6,
                                        noFocusTexture=bg, focusTexture=bg_focus)
        self.hide = xbmcgui.ControlButton(470, 610, 520, 56, L(30803, "Rozumím, příště nezobrazovat"),
                                          font="font13", textColor="FFE6E1F0", focusedColor="FFFFFFFF",
                                          alignment=6, noFocusTexture=bg, focusTexture=bg_focus)
        self.addControl(self.ok)
        self.addControl(self.hide)
        self.ok.controlRight(self.hide)
        self.hide.controlLeft(self.ok)
        self.setFocus(self.ok)

    def onControl(self, control):
        self.choice = "hide" if control.getId() == self.hide.getId() else "ok"
        self.close()

    def onAction(self, action):
        if action.getId() in self.BACK:
            self.close()


SW_INTRO_TEXT = (
    "Sledujte jeden film nebo díl společně na víc zařízeních – každý u sebe, ale ve stejnou chvíli.[CR][CR]"
    "[B]1.[/B] Jeden založí skupinu a stane se vedoucím. Dostane kód, například SW-7K2Q-9MFX.[CR]"
    "[B]2.[/B] Ostatní (nejvýš 4 další zařízení) zadají kód v SyncWatch → Připojit se kódem. Čekají, až vedoucí něco pustí.[CR]"
    "[B]3.[/B] Vedoucí pustí film normálně v Nokturnu. Stejný stream se sám spustí i u ostatních – "
    "začne se, až se načte všem.[CR]"
    "[B]4.[/B] Pauza, přehrávání a přetáčení od kohokoli platí pro všechny. Když se někomu načítá, ostatní počkají.[CR][CR]"
    "Všichni pustí přesně tentýž stream – stejnou kvalitu, zvuk i délku – každý přes svůj vlastní účet "
    "u zdroje. Kdo účet u zdroje vedoucího nemá, stream se mu nespustí.[CR]"
    "Skupina zanikne, když se k ní 5 minut nikdo nepřipojí, nebo když ji vedoucí ukončí. "
    "Co sledujete, server nevidí – je to zašifrované kódem skupiny."
)


def sw_intro():
    """Návod. Vrací True, když chce uživatel pokračovat do skupiny."""
    window = SyncWatchIntroWindow()
    try:
        window.doModal()
        choice = window.choice
    finally:
        del window
    if choice == "hide":
        STORE.save("sw_intro_hidden", True)
    return choice is not None


def sw_menu():
    """Složka SyncWatch: mimo skupinu Založit / Připojit, ve skupině stav a odchod."""
    session = sw_session()
    xbmcplugin.setPluginCategory(HANDLE, sw_title())
    if session.get("token"):
        status = sw_status()
        members = status.get("members") or []
        online = sum(1 for m in members if m.get("online")) or 1
        role = L(30804, "vedoucí") if session.get("leader") else L(30805, "člen")
        if not session.get("leader") and status.get("detached") and status.get("loaded"):
            # zastavil omylem nebo pustil něco jiného — skupina sleduje dál
            action_item(_swf(30835, "Vrátit se do filmu: %s", status.get("title") or ""),
                        build_url(action="sw_rejoin"), icon="DefaultVideo.png",
                        info=L(31103, "Skupina zatím sleduje dál. Kliknutím se k ní vrátíš."))
        action_item("%s · %s · %s" % (session.get("code", ""), role, _swf(30806, "připojeno: %d", online)),
                    build_url(action="sw_window"), icon="DefaultUser.png",
                    info=L(31104, "Kód skupiny, tvoje role a počet připojených zařízení."))
        if session.get("leader"):
            action_item(L(30807, "Zavřít skupinu pro další zařízení") if not status.get("locked")
                        else L(30808, "Otevřít skupinu pro další zařízení"),
                        build_url(action="sw_lock"), icon="DefaultAddonService.png",
                        info=L(31105, "Zavřená skupina nepřijme další zařízení. Otevřít ji můžeš kdykoli."))
            action_item(L(30809, "Ukončit sledování pro všechny"), build_url(action="sw_leave"),
                        icon="DefaultIconError.png", info=L(31106, "Zastaví přehrávání všem ve skupině a skupinu zruší."))
        else:
            action_item(L(30810, "Opustit skupinu"), build_url(action="sw_leave"), icon="DefaultIconError.png",
                    info=L(31107, "Odpojí tě od skupiny. Ostatní sledují dál."))
    else:
        action_item(L(30811, "Založit skupinu (budu vedoucí)"), build_url(action="sw_create"),
                    icon="DefaultAddSource.png",
                    info=L(31108, "Vytvoří skupinu a dá ti kód, který pošleš ostatním. Určuješ, co se přehrává."))
        action_item(L(30812, "Připojit se kódem"), build_url(action="sw_join"), icon="DefaultUser.png",
                    info=L(31109, "Zadej kód skupiny od vedoucího a budeš sledovat spolu s ostatními."))
    action_item(L(30813, "Jak SyncWatch funguje"), build_url(action="sw_intro"), icon="DefaultIconInfo.png",
                info=L(31110, "Krátký návod, jak společné sledování funguje."))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _sw_fail(err):
    xbmcgui.Dialog().ok(sw_title(), str(err) or L(30814, "Server SyncWatch neodpovídá, zkus to za chvíli."))


def sw_create():
    usage.mark_feature(STORE, "syncwatch")
    sw = _syncwatch()
    if sw_session().get("token"):
        return sw_window()
    code = sw.new_code()
    client = sw.Client(code)
    try:
        client.create({"name": sw_device_name(), "st": "ok"})
    except sw.SyncWatchError as e:
        return _sw_fail(e)
    sw_save({"code": code, "token": client.token, "mid": client.mid, "leader": True,
             "name": sw_device_name(), "since": int(time.time())})
    xbmc.log(f"[{ADDON_ID}] SyncWatch: založena skupina", xbmc.LOGINFO)
    sw_window()
    xbmc.executebuiltin("Container.Refresh")


def sw_join():
    usage.mark_feature(STORE, "syncwatch")
    sw = _syncwatch()
    if sw_session().get("token"):
        return sw_window()
    code = xbmcgui.Dialog().input(L(30815, "Kód skupiny (SW-XXXX-XXXX)"))
    if not code:
        return
    if not sw.valid_code(code):
        return _sw_fail(L(30816, "Kód nemá správný tvar. Má osm znaků, třeba SW-7K2Q-9MFX."))
    code = sw.pretty_code(code)
    client = sw.Client(code)
    try:
        client.join({"name": sw_device_name(), "st": "ok"})
    except sw.SyncWatchError as e:
        return _sw_fail(e)
    sw_save({"code": code, "token": client.token, "mid": client.mid, "leader": False,
             "name": sw_device_name(), "since": int(time.time())})
    xbmc.log(f"[{ADDON_ID}] SyncWatch: připojeno ke skupině", xbmc.LOGINFO)
    sw_window()
    xbmc.executebuiltin("Container.Refresh")


def sw_leave():
    sw = _syncwatch()
    session = sw_session()
    if not session.get("token"):
        return
    question = (L(30817, "Ukončit sledování? Skupina skončí i všem ostatním.") if session.get("leader")
                else L(30818, "Opustit skupinu? Ostatní budou sledovat dál."))
    if not xbmcgui.Dialog().yesno(sw_title(), question):
        return
    try:
        sw.Client(session["code"], token=session["token"]).leave()
    except sw.SyncWatchError as e:
        log_error(e)
    sw_save({})
    notify(L(30819, "SyncWatch ukončen"))
    xbmc.executebuiltin("Container.Refresh")


def sw_rejoin():
    """Služba (`SyncWatchManager`) pustí film skupiny znovu a naskočí na její pozici."""
    if sw_session().get("token"):
        xbmcgui.Window(10000).setProperty("nokturno.sw.rejoin", str(time.time()))


def sw_lock():
    sw = _syncwatch()
    session = sw_session()
    if not session.get("leader"):
        return
    locked = not sw_status().get("locked")
    try:
        sw.Client(session["code"], token=session["token"]).lock(locked)
    except sw.SyncWatchError as e:
        return _sw_fail(e)
    notify(L(30820, "Skupina je zavřená, nikdo další se nepřipojí") if locked
           else L(30821, "Skupina je otevřená pro další zařízení"))
    xbmc.executebuiltin("Container.Refresh")


class SyncWatchWindow(xbmcgui.WindowDialog):
    """Okno skupiny. U vedoucího kód velkým písmem a kdo se připojil, u člena
    „Čekám na vysílání…". Neblokuje: smyčka v `sw_window()` ho obnovuje ze stavu,
    který píše služba. Zpět okno zavře, ve skupině se zůstává."""
    BACK = (9, 10, 13, 92)

    def __init__(self, leader, code):
        super().__init__()
        self.closed_by_user = False
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, _sw_backdrop(), colorDiffuse="FF0D0B14"))
        self.addControl(xbmcgui.ControlLabel(90, 50, 1100, 50, "[B]%s[/B]" % sw_title(),
                                             font="font13", textColor="FFFFFFFF"))
        if leader:
            self.addControl(xbmcgui.ControlLabel(90, 120, 1100, 40, L(30822, "Kód skupiny"),
                                                 font="font13", textColor="FF9B95AD"))
            self.addControl(xbmcgui.ControlLabel(90, 160, 1100, 110, "[B]%s[/B]" % code,
                                                 font="font45", textColor="FFC4B5FD"))
            hint = L(30823, "Na dalším Kodi: Nokturno → SyncWatch → Připojit se kódem.")
        else:
            self.addControl(xbmcgui.ControlLabel(90, 140, 1100, 60, "[B]%s[/B]" % L(30824, "Čekám na vysílání…"),
                                                 font="font13", textColor="FFC4B5FD"))
            hint = _swf(30825, "Skupina %s – až vedoucí něco pustí, spustí se to i tady.", code)
        self.addControl(xbmcgui.ControlLabel(90, 280, 1100, 40, hint, font="font13", textColor="FFE6E1F0"))
        self.status = xbmcgui.ControlLabel(90, 330, 1100, 40, "", font="font13", textColor="FFFFB86C")
        self.addControl(self.status)
        self.members = xbmcgui.ControlTextBox(90, 390, 1100, 200, font="font13", textColor="FFE6E1F0")
        self.addControl(self.members)
        footer = (L(30826, "Zpět zavře okno. Pak pusť film v Nokturnu – spustí se všem.") if leader
                  else L(30827, "Zpět zavře okno, ve skupině zůstaneš. Odejít jde v menu SyncWatch."))
        self.addControl(xbmcgui.ControlLabel(90, 620, 1100, 40, footer, font="font13", textColor="FF9B95AD"))

    def update(self, status, leader):
        rows = []
        for m in status.get("members") or []:
            dot = "[COLOR FF50FA7B]●[/COLOR]" if m.get("online") else "[COLOR FF6D6A7C]○[/COLOR]"
            extra = []
            if m.get("leader"):
                extra.append(L(30804, "vedoucí"))
            if m.get("you"):
                extra.append(L(30828, "toto zařízení"))
            if not m.get("online"):
                extra.append(L(30829, "odpojené"))
            rows.append("%s %s%s" % (dot, m.get("name") or "?", (" (%s)" % ", ".join(extra)) if extra else ""))
        self.members.setText("[CR]".join(rows) or L(30830, "Připojuji…"))
        line = ""
        if status.get("expires") is not None and leader:
            left = max(0, int(status["expires_at"] - time.time())) if status.get("expires_at") else int(status["expires"])
            line = _swf(30831, "Zatím se nikdo nepřipojil – kód zanikne za %s", "%d:%02d" % divmod(left, 60))
        elif status.get("title") and status.get("loaded"):
            line = "%s: %s" % (L(30832, "Hraje se"), status["title"])
        self.status.setLabel(line)

    def onAction(self, action):
        if action.getId() in self.BACK:
            self.closed_by_user = True
            self.close()


def sw_window():
    """Okno skupiny, dokud ho uživatel nezavře, skupina neskončí, nebo (u člena)
    se nezačne přehrávat stream od vedoucího."""
    session = sw_session()
    if not session.get("token"):
        return
    leader = bool(session.get("leader"))
    window = SyncWatchWindow(leader, session.get("code", ""))
    window.show()
    try:
        while not window.closed_by_user and not should_stop():
            # jen volání API Kodi pustí `onAction` (Zpět) k oknu — viz `remote_setup()`
            MONITOR.waitForAbort(0.4)
            if not sw_session().get("token"):
                closed = sw_status().get("closed") or ""
                notify(_swf(30833, "SyncWatch skončil: %s", closed) if closed else L(30819, "SyncWatch ukončen"),
                       xbmcgui.NOTIFICATION_WARNING, 6000)
                break
            status = sw_status()
            window.update(status, leader)
            if not leader and (status.get("loading") or xbmc.Player().isPlayingVideo()):
                break   # stream od vedoucího se spouští — okno by překrylo video
    finally:
        window.close()
        del window


def sw_replay(**params):
    """Adresa, kterou ostatní ve skupině pustí totéž (`syncwatch.valid_replay`)."""
    return build_url(**params)


def remote_setup_schema(section=None):
    """Formulář pro mobil přímo ze `settings.xml` — nová položka nastavení se na stránce
    objeví sama. Popisky a nápověda jdou z `strings.po` v jazyce Kodi. `section` = jen jedna
    kategorie (tlačítko Nastavit z mobilu přímo v ní, např. Výběr streamu).

    `REMOTE_SETUP_SPLIT` kategorie (dnes jen „sources“, sloučené kvůli stropu 20 kategorií
    v settings.xml) rozpadne na jednu sekci stránky za skupinu, aby na mobilu zůstalo vidět
    deset rozbalovacích bloků zdrojů, ne jeden s 35 poli. Ostatní kategorie mají skupiny dál
    jako nadpisy uvnitř jedné sekce."""
    import xml.etree.ElementTree as ET
    root = ET.parse(os.path.join(ADDON_PATH, "resources", "settings.xml")).getroot()
    sections = []
    for category in root.iter("category"):
        cat_id = category.get("id")
        if cat_id not in REMOTE_SETUP_CATEGORIES or section and cat_id != section:
            continue
        groups = category.findall("group")
        if cat_id in REMOTE_SETUP_SPLIT:
            for group in groups:
                fields = _group_fields(group)
                if not fields:
                    continue
                label = (_plain(L(int(group.get("label")), group.get("id"))) if group.get("label")
                         else group.get("id"))
                sections.append({"id": group.get("id"), "label": label, "fields": fields,
                                 "open": not sections})
            continue
        fields = []
        for group in groups:
            group_fields = _group_fields(group)
            if not group_fields:
                continue
            if group.get("label") and len(groups) > 1:
                fallback = f"Úložiště {group.get('id')}"
                fields.append({"type": "heading", "label": _plain(L(int(group.get("label")), fallback))})
            fields.extend(group_fields)
        if fields:
            sections.append({"id": cat_id, "label": _plain(L(int(category.get("label")))),
                             "fields": fields, "open": not sections})
    return sections


def _solid_rgba_png(rgb, alpha):
    """PNG 1×1 RGBA jedné barvy — Kodi ji roztáhne na velikost kontroly.

    Podklad tlačítka s adresou v `RemoteSetupWindow`. Výchozí textura skinu (bez vlastní)
    se na telefonu kreslila užší než tlačítko a posunutá doprava, text přes ni přetékal
    (5.2.21~beta4/5). Jednobarevná pilulka je stejná v každém skinu."""
    r, g, b = rgb
    header = struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0)

    def chunk(kind, body):
        return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body) & 0xFFFFFFFF)
    raw = bytes([0, r, g, b, alpha])
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header)
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


class RemoteSetupWindow(xbmcgui.WindowDialog):
    """Okno s QR kódem. Neblokuje — `remote_setup()` mezitím čeká na mobil; Zpět zruší.

    Na Androidu je adresa klikatelná — OK/klik ji otevře v systémovém prohlížeči přímo na
    tomhle zařízení (`StartAndroidActivity`, nahlásil uživatel 2026-09-18: díval se na QR
    z mobilu a chtěl adresu rovnou otevřít, ne ji přepisovat ručně). Jinde (CoreELEC/Linux,
    Windows…) ten builtin nic nedělá, takže tam adresa zůstává jen čitelný text jako dřív.

    Klik na adresu (5.2.21~beta1–4, telefon uživatele): ťuknutí prstem měnilo jen fokusový
    vzhled tlačítka, `onControl` nikdy nepřišel — s prázdnou, poloprůhlednou i neprůhlednou
    vlastní texturou stejně. Kodi na ťuknutí pošle nejdřív `ACTION_MOUSE_MOVE` (ten tlačítko
    zaostří, proto ta barva) a pak akci z touch keymapy; kde se cestou k `GUI_MSG_CLICKED`
    ztrácí, se z logu nezjistilo. Proto se klik bere ze dvou míst: z `onControl` (řádná
    cesta, srovnání přes `getId()`, ne `==` — Kodi může do callbacku dát jiný Python obal
    téhož ovládacího prvku) a z `onAction` pro každou klikací akci (OK, levé tlačítko myši,
    ťuknutí) ve chvíli, kdy má adresa fokus — `Window.onAction` dostává i akce myši/dotyku,
    jakmile je nějaký prvek zaostřený. `open_link()` obě cesty sloučí (jeden klik = jedno
    otevření). Podklad tlačítka je vlastní jednobarevná pilulka (`_solid_rgba_png`) — ani
    prázdná textura, ani výchozí tlačítko skinu nevypadaly na telefonu dobře."""
    CANCEL_ACTIONS = (9, 10, 13, 92)   # PARENT_DIR, PREVIOUS_MENU, STOP, NAV_BACK
    # SELECT_ITEM, MOUSE_LEFT_CLICK, MOUSE_DOUBLE_CLICK, MOUSE_LONG_CLICK, TOUCH_TAP
    CLICK_ACTIONS = (7, 100, 103, 108, 401)
    MOUSE_MOVE = 107

    def __init__(self, qr_path, backdrop_path, url, link_bg_path, link_bg_focus_path):
        super().__init__()
        self.cancelled = False
        self.url = url
        self.link = None
        self._opened_at = 0.0
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, backdrop_path, colorDiffuse="F20D0B14"))
        self.addControl(xbmcgui.ControlLabel(90, 70, 1100, 50, "[B]%s[/B]" % L(30447, "Nastavit z mobilu"),
                                             font="font13", textColor="FFFFFFFF"))
        self.addControl(xbmcgui.ControlImage(90, 150, 400, 400, qr_path, aspectRatio=2))
        steps = xbmcgui.ControlTextBox(540, 160, 660, 220, font="font13", textColor="FFE6E1F0")
        self.addControl(steps)
        steps.setText(L(30452, "1. Připoj mobil ke stejné Wi-Fi jako toto zařízení.[CR]"
                               "2. Naskenuj QR kód fotoaparátem, nebo otevři v prohlížeči adresu:"))
        footer = L(30453, "Zpět zruší · adresa platí 30 minut a pro jedno uložení")
        if xbmc.getCondVisibility("System.Platform.Android"):
            self.link = xbmcgui.ControlButton(540, 400, 700, 60, "[B]%s[/B]" % url, font="font13",
                                              textColor="FFC4B5FD", focusedColor="FFFFFFFF",
                                              noFocusTexture=link_bg_path, focusTexture=link_bg_focus_path)
            self.addControl(self.link)
            self.setFocus(self.link)
            footer += " · " + L(30517, "OK adresu otevře v prohlížeči")
        else:
            self.addControl(xbmcgui.ControlLabel(540, 400, 700, 60, "[B]%s[/B]" % url, font="font13",
                                                 textColor="FFC4B5FD"))
        self.addControl(xbmcgui.ControlLabel(90, 610, 1100, 40, footer, font="font13", textColor="FF9B95AD"))

    def onAction(self, action):
        aid = action.getId()
        if aid in self.CANCEL_ACTIONS:
            self.cancelled = True
            self.close()
            return
        if self.link is None or aid == self.MOUSE_MOVE:
            return
        focus = self._focus_id()
        xbmc.log(f"[{ADDON_ID}] Nastavit z mobilu: akce {aid}, fokus {focus}, adresa {self.link.getId()}",
                 xbmc.LOGINFO)
        if aid in self.CLICK_ACTIONS and focus == self.link.getId():
            self.open_link("onAction %d" % aid)

    def onControl(self, control):
        if self.link is not None and control.getId() == self.link.getId():
            self.open_link("onControl")

    def _focus_id(self):
        try:
            return self.getFocusId()
        except (RuntimeError, SystemError):
            return -1

    def open_link(self, via):
        now = time.time()
        if now - self._opened_at < 1.5:
            xbmc.log(f"[{ADDON_ID}] Nastavit z mobilu: {via} — tentýž klik, už otevřeno", xbmc.LOGINFO)
            return
        self._opened_at = now
        xbmc.log(f"[{ADDON_ID}] Nastavit z mobilu: {via} — otevírám {self.url}", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(L(30447, "Nastavit z mobilu"), L(30518, "Otvírám v prohlížeči…"),
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('StartAndroidActivity("", "android.intent.action.VIEW", "", "%s")' % self.url)


def _remote_form(schema, values, actions, texts_extra=None):
    """Společná část „z mobilu“: QR s místní adresou, mobil ve stejné Wi-Fi vyplní formulář podle `schema`
    (`lib/remote_setup.py`), server běží jen po dobu dialogu. Vrací změněné hodnoty `{id: str}`, nebo None při
    zrušení, chybě i vypršení (nic se neukládá, to je na volajícím).

    Otevřený dialog nastavení doplňku se nejdřív zavře: drží vlastní kopii hodnot a při
    zavření by změny z mobilu přepsal."""
    if xbmc.getCondVisibility("Window.IsVisible(addonsettings)"):
        xbmc.executebuiltin("Dialog.Close(addonsettings,true)")
        for _ in range(30):
            if not xbmc.getCondVisibility("Window.IsVisible(addonsettings)") or MONITOR.waitForAbort(0.1):
                break
    ip = xbmc.getIPAddress()
    if not ip or ip.startswith("127.") or ip == "0.0.0.0":
        xbmcgui.Dialog().ok(L(30447, "Nastavit z mobilu"),
                            L(30454, "Toto zařízení nemá adresu v místní síti. Připoj ho k Wi-Fi nebo kabelem "
                                     "a zkus to znovu."))
        return None
    texts = {
        "title": "Nokturno – " + L(30447, "Nastavit z mobilu"),
        "intro": L(30458, "Vyplň, co chceš změnit, a ulož. Nastavení se hned propíše do Kodi."),
        "save": L(30459, "Uložit do Kodi"),
        "saved": L(30460, "Uloženo. Nastavení je v Kodi, stránku můžeš zavřít."),
        "password_set": L(30461, "vyplněno – prázdné pole ponechá původní hodnotu"),
        "expired": L(30462, "Tato adresa už neplatí. Na TV spusť Nastavit z mobilu znovu."),
        "invalid": L(30463, "Neplatná hodnota: %s").replace("%s", "{}"),
        "order_rows": L(30499, "Horní řádek|Dolní řádek"),
        "order_hidden": L(30500, "Nezobrazovat"),
        "order_up": L(30510, "Nahoru"),
        "order_down": L(30511, "Dolů"),
        "action_failed": L(30580, "Spojení s televizí se přerušilo – na TV spusť Nastavit z mobilu znovu."),
        "action_running": L(30942, "Pracuji…"),
    }
    texts.update(texts_extra or {})
    server = _remote_setup().SetupServer(schema, values, texts, actions=actions)
    try:
        server.start()
    except OSError as e:
        xbmcgui.Dialog().ok(L(30447, "Nastavit z mobilu"), Lf(30455, e) if L(30455) else str(e))
        return None
    url = server.url(ip)
    qr_path = os.path.join(PROFILE, "remote-setup-%s.png" % server.token[:8])
    backdrop = os.path.join(PROFILE, "remote-setup-bg.png")
    link_bg = os.path.join(PROFILE, "remote-setup-link-bg.png")
    link_bg_focus = os.path.join(PROFILE, "remote-setup-link-bg-focus.png")
    changes, window = None, None
    try:
        xbmcvfs.mkdirs(PROFILE)
        with open(qr_path, "wb") as f:
            f.write(_qr().to_png(_qr().encode(url), scale=12, border=2))
        with open(backdrop, "wb") as f:
            f.write(_qr().to_png([[False]], scale=1, border=0))
        with open(link_bg, "wb") as f:
            f.write(_solid_rgba_png((92, 68, 150), 230))
        with open(link_bg_focus, "wb") as f:
            f.write(_solid_rgba_png((124, 92, 200), 255))
        xbmc.log(f"[{ADDON_ID}] nastavení z mobilu: server na portu {server.port}", xbmc.LOGINFO)
        window = RemoteSetupWindow(qr_path, backdrop, url, link_bg, link_bg_focus)
        window.show()
        deadline = time.time() + REMOTE_SETUP_TIMEOUT
        while time.time() < deadline and not window.cancelled and not should_stop():
            # Kodi doručí `onAction` (Zpět) oknu skriptu jen během volání svého API — čekání
            # čistě v Pythonu (`Event.wait`) ho nepustí a Zpět nic nezavřelo (Office, beta 3).
            # Návratovou hodnotu hlídá `should_stop()` v podmínce smyčky.
            MONITOR.waitForAbort(0.2)
            changes = server.wait_result(0.05)
            if changes is not None or server.finished:
                break
    finally:
        if window is not None:
            window.close()
            del window
        server.stop()
        try:
            os.remove(qr_path)
        except OSError:
            pass
    return changes


def remote_setup(section=None):
    """„Nastavit z mobilu“ (Nastavení → Pokročilé, průvodce): QR s místní adresou, mobil ve
    stejné Wi-Fi vyplní formulář, Kodi uloží změny. Vrací počet uložených položek, nebo None při zrušení/chybě."""
    schema = remote_setup_schema(section)
    # neuložená položka: výchozí hodnota ze settings.xml — jinak by prohlížeč u výběru poslal
    # první volbu a u přepínače „vypnuto“ a uložilo by se, co uživatel neměnil
    values = {f["id"]: ADDON.getSetting(f["id"]) or f["default"] for section in schema for f in section["fields"]
              if f.get("type") not in ("heading", "info", "action")}
    changes = _remote_form(schema, values, {"luna_find": luna_find_remote, "luna_check": luna_check_remote,
                                            "terms_show": terms_show_remote})
    if changes is None:
        return None
    for key, value in changes.items():
        ADDON.setSetting(key, value)
    if any(k.startswith("ws_") for k in changes):
        xbmcgui.Window(10000).clearProperty("nokturno.ws_token")   # nový účet = nový login
    xbmc.log(f"[{ADDON_ID}] nastavení z mobilu uloženo: {', '.join(sorted(changes))}", xbmc.LOGINFO)
    if changes:
        notify(Lf(30456, len(changes)) if L(30456) else "Nastavení z mobilu uloženo (%d)" % len(changes))
    else:
        notify(L(30457, "Z mobilu nepřišla žádná změna"))
    return len(changes)


def remote_setup_action(section=None):
    """Tlačítko v nastavení (RunPlugin, bez výpisu) — po uložení otevře nastavení znovu.
    `section` = stránka jen s jednou kategorií (`remote_setup_schema`)."""
    saved = remote_setup(section if section in REMOTE_SETUP_CATEGORIES else None)
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
    if saved:
        ADDON.openSettings()


# Kam se uloží kopie nastavení před tím, než ho přepíše přenos z jiného zařízení.
TRANSFER_BACKUP = "settings-pred-prenosem.xml"
TRANSFER_EXT = ".nokturno"


def _close_settings():
    """Zavře otevřený dialog nastavení. Drží vlastní kopii hodnot, takže by při
    zavření přepsal, co mezitím zapsal přenos — a při čtení by vydal starý stav."""
    if not xbmc.getCondVisibility("Window.IsVisible(addonsettings)"):
        return
    xbmc.executebuiltin("Dialog.Close(addonsettings,true)")
    for _ in range(30):
        if not xbmc.getCondVisibility("Window.IsVisible(addonsettings)") or MONITOR.waitForAbort(0.1):
            break


def transfer_values(schema):
    """`{id: hodnota}` pro přenos. Neuložená položka jde s výchozí hodnotou ze
    `settings.xml` — stejně jako u stránky z mobilu."""
    return {f["id"]: ADDON.getSetting(f["id"]) or f["default"]
            for section in schema for f in section["fields"]
            if f.get("type") not in ("heading", "info", "action")}


def transfer_payload():
    """Obsah přenosu z aktuálního nastavení.

    CZtor a Trakt ve schématu formuláře nejsou (párují se na místě, ne vyplněním
    pole), takže se jejich stav přidá zvlášť — a jen jako příznak, nikdy token."""
    schema = remote_setup_schema()
    extras = {"cztor": ADDON.getSetting("cz_enabled") == "true", "trakt": bool(STORE.trakt())}
    return _transfer_core().pack(schema, transfer_values(schema),
                              source="Kodi %s" % ADDON.getAddonInfo("version"), extras=extras)


def transfer_send():
    """Odeslat nastavení do jiného Kodi: kód na obrazovce, obsah zašifrovaný.

    Dialog s kódem zůstane otevřený, dokud ho uživatel nezavře — má čas dojít
    k druhé televizi a kód opsat. Na server jde jen neprůhledná binárka."""
    usage.mark_feature(STORE, "transfer")
    _close_settings()
    try:
        code, ttl = _transfer_core().send_payload(transfer_payload())
    except _transfer_core().TransferError as e:
        xbmcgui.Dialog().ok(L(30587, "Přenos nastavení"), Lf(30595, e))
        return
    xbmc.log(f"[{ADDON_ID}] přenos nastavení odeslán, platí {ttl} s", xbmc.LOGINFO)
    xbmcgui.Dialog().ok(L(30587, "Přenos nastavení"), Lf(30593, code, max(1, ttl // 60)))


def transfer_receive(code=None):
    """Načíst nastavení z jiného Kodi podle opsaného kódu."""
    usage.mark_feature(STORE, "transfer")
    _close_settings()
    dialog = xbmcgui.Dialog()
    if not code:
        code = dialog.input(L(30594, "Kód z druhého Kodi"), defaultt="NKT-")
        if not code:
            return
    try:
        payload = _transfer_core().receive(code)
    except _transfer_core().TransferError as e:
        dialog.ok(L(30587, "Přenos nastavení"), Lf(30595, e))
        return
    transfer_apply(payload)


def transfer_file_save():
    """Týž přenos, jen místo serveru soubor — na USB nebo síťový disk. Kód je
    potřeba pořád: bez něj soubor nikdo nepřečte."""
    usage.mark_feature(STORE, "transfer")
    _close_settings()
    dialog = xbmcgui.Dialog()
    folder = dialog.browseSingle(3, L(30591, "Uložit do souboru"), "files")
    if not folder:
        return
    code = _transfer_core().new_code()
    name = "nokturno-%s%s" % (time.strftime("%Y-%m-%d"), TRANSFER_EXT)
    path = os.path.join(folder, name) if "://" not in folder else folder.rstrip("/") + "/" + name
    try:
        blob = _transfer_core().export_bytes(code, transfer_payload())
        handle = xbmcvfs.File(path, "w")
        try:
            if not handle.write(bytearray(blob)):
                raise OSError("zápis se nepovedl")
        finally:
            handle.close()
    except (_transfer_core().TransferError, OSError) as e:
        dialog.ok(L(30587, "Přenos nastavení"), Lf(30603, e))
        return
    dialog.ok(L(30587, "Přenos nastavení"), Lf(30599, path, code))


def transfer_file_load():
    usage.mark_feature(STORE, "transfer")
    _close_settings()
    dialog = xbmcgui.Dialog()
    path = dialog.browseSingle(1, L(30592, "Načíst ze souboru"), "files", TRANSFER_EXT)
    if not path or path.endswith("/"):
        return
    code = dialog.input(L(30594, "Kód z druhého Kodi"), defaultt="NKT-")
    if not code:
        return
    try:
        handle = xbmcvfs.File(path)
        try:
            blob = bytes(handle.readBytes())
        finally:
            handle.close()
    except OSError as e:
        dialog.ok(L(30587, "Přenos nastavení"), Lf(30604, e))
        return
    try:
        payload = _transfer_core().import_bytes(code, blob)
    except _transfer_core().TransferError as e:
        dialog.ok(L(30587, "Přenos nastavení"), Lf(30595, e))
        return
    transfer_apply(payload)


def transfer_backup_settings():
    """Kopie `settings.xml` vedle něj. Import je přepis — bez zálohy by se nešlo
    vrátit k tomu, co na zařízení bylo."""
    source = os.path.join(PROFILE, "settings.xml")
    target = os.path.join(PROFILE, TRANSFER_BACKUP)
    if not xbmcvfs.exists(source):
        return ""
    xbmcvfs.delete(target)
    return target if xbmcvfs.copy(source, target) else ""


def transfer_apply(payload):
    """Náhled, potvrzení, zápis. Uživatel vidí, co se změní, ještě než se to stane."""
    schema = remote_setup_schema()
    plan = _transfer_core().plan(payload, transfer_values(schema), _transfer_core().exportable(schema))
    dialog = xbmcgui.Dialog()
    if plan.empty():
        dialog.ok(L(30587, "Přenos nastavení"), L(30598, "Z přenosu nepřišla žádná změna."))
        return
    if not dialog.yesno(L(30587, "Přenos nastavení"),
                        Lf(30596, len(plan), plan.source or "Kodi", len(plan.same),
                           len(plan.unknown) + len(plan.blocked), TRANSFER_BACKUP)):
        return

    backup = transfer_backup_settings()
    for key, value in plan.changes.items():
        ADDON.setSetting(key, value)
    if any(k.startswith("ws_") for k in plan.changes):
        xbmcgui.Window(10000).clearProperty("nokturno.ws_token")   # nový účet = nový login
    STORE.clear_cache()     # cache patří k účtům, které tu byly do teď
    xbmc.log(f"[{ADDON_ID}] přenos nastavení: zapsáno {len(plan)} položek "
             f"({', '.join(sorted(plan.changes))}), záloha {backup or 'žádná'}", xbmc.LOGINFO)
    notify(Lf(30597, len(plan)))

    # Tokeny se nepřenášejí schválně: obnovovací token CZtoru se použitím mění, takže by
    # kopie odhlásila původní zařízení, a token Traktu je vázaný na zařízení. Přenos nese
    # jen příznak „tady to bylo zapnuté“ — přihlásit se musí každé zařízení samo.
    if "cztor" in plan.flags and not cztor_client().paired() \
            and dialog.yesno(L(30560, "CZtor"), L(30600, "Účet CZtoru se nepřenáší. Spárovat teď?")):
        cztor_pair()
    if "trakt" in plan.flags and not STORE.trakt() \
            and dialog.yesno(L(30090, "Trakt.tv"), L(30601, "Účet Traktu se nepřenáší. Přihlásit teď?")):
        trakt_auth()


def _wizard_accounts(dialog):
    """Průvodce ovladačem: nejdřív vlastní úložiště, pak volitelné zdroje třetích stran otázku po otázce."""
    if dialog.yesno(L(30374, "Vlastní úložiště"),
                    L(31045, "Máš vlastní úložiště (WebDAV, SMB, NAS)? Nokturno z něj přehrává filmy, seriály i koncerty.")):
        url = dialog.input(L(30379, "Adresa složky"))
        if url:
            ADDON.setSetting("dav1_url", url)
            ADDON.setSetting("dav1_enabled", "true")
            user = dialog.input(L(30381, "Uživatelské jméno"))
            if user:
                ADDON.setSetting("dav1_username", user)
                pwd = dialog.input(L(30383, "Heslo"), option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if pwd:
                    ADDON.setSetting("dav1_password", pwd)

    dialog.ok(L(31047, "Volitelná úložiště třetích stran"),
              L(31046, "Úložiště třetích stran jsou volitelná. V dalších krocích zapneš jen ta, která chceš používat."))

    if dialog.yesno(L(30340, "WebShare"), L(30341, "Máš účet WebShare?")):
        user = dialog.input(L(30342, "WebShare – e-mail"))
        if user:
            pwd = dialog.input(L(30343, "WebShare – heslo"), option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if pwd:
                ADDON.setSetting("ws_username", user)
                ADDON.setSetting("ws_password", pwd)
                ADDON.setSetting("ws_enabled", "true")

    if dialog.yesno(L(30344, "Sosáč"),
                     L(30345, "Máš účet Streamuj.tv (přehrávač Sosáče)?[CR]"
                              "Katalogy Sosáče fungují i bez účtu, jen pro přehrávání je potřeba.")):
        user = dialog.input(L(30346, "Streamuj.tv – uživatel"))
        if user:
            pwd = dialog.input(L(30347, "Streamuj.tv – heslo"), option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if pwd:
                ADDON.setSetting("streamuj_username", user)
                ADDON.setSetting("streamuj_password", pwd)
        ADDON.setSetting("sosac_enabled", "true")

    if dialog.yesno(L(30348, "Luna: Absolute Cinema"),
                     L(30349, "Máš v síti spuštěný server Luna: Absolute Cinema?")):
        # adresu Luny uživatel při prvním spuštění zpravidla nezná — najdeme ji za něj
        # (sken podsítě trvá vteřiny) a rovnou mu řekneme, kam si má jít pro token
        try:
            found = luna_discover(should_stop=should_stop)
        except Exception:  # noqa: BLE001 – bez sítě, bez IPv4 adresy
            found = []
        if found:
            ADDON.setSetting("luna_url", found[0]["url"])
            heading = Lf(30542, found[0]["url"])
        else:
            heading = L(30350, "Adresa doplňku nebo token ze stránky /setup Luny")
        addr = dialog.input(heading)
        if addr:
            ADDON.setSetting("token", addr)
        if addr or found:
            ADDON.setSetting("luna_enabled", "true")

    if dialog.yesno(L(30351, "HellSpy"), L(30352, "Zapnout HellSpy? Je zdarma a nepotřebuje žádný účet.")):
        ADDON.setSetting("hs_enabled", "true")

    if dialog.yesno(L(30367, "Sledujteto"),
                     L(30388, "Máš účet Sledujteto?[CR]"
                              "Hledá se přes tvůj účet, přehrávat jde jen s Premium.")):
        email = dialog.input(L(30389, "Sledujteto – e-mail"))
        if email:
            pwd = dialog.input(L(30390, "Sledujteto – heslo"), option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if pwd:
                ADDON.setSetting("st_email", email)
                ADDON.setSetting("st_password", pwd)
                ADDON.setSetting("st_enabled", "true")

    if dialog.yesno(L(30417, "FastShare"),
                     L(30424, "Máš účet FastShare nebo Sdilej.cz?[CR]"
                              "Hledá se i bez něj, přehrání jde z tvého kreditu nebo neomezeného tarifu.")):
        # Sdilej.cz = týž katalog, jen vlastní účty
        web = dialog.select(L(30926, "Účet z"), [L(30417, "FastShare"), L(30928, "Sdilej.cz")])
        user = dialog.input(L(30420, "FastShare – uživatel")) if web >= 0 else ""
        if user:
            pwd = dialog.input(L(30422, "FastShare – heslo"), option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if pwd:
                ADDON.setSetting("fs_username", user)
                ADDON.setSetting("fs_password", pwd)
                ADDON.setSetting("fs_enabled", "true")
                ADDON.setSetting("fs_provider", str(web))

    if dialog.yesno(L(30560, "CZtor"), L(30573, "Máš předplatné CZtor (cztor.com)?[CR]"
                                                "Zařízení se spáruje PINem, heslo není potřeba.")):
        ADDON.setSetting("cz_enabled", "true")
        cztor_pair()

    if dialog.yesno(L(30353, "Vlastní databáze filmů a seriálů"),
                     L(30354, "Chceš zadat bezplatný klíč TMDB, aby popisy a obsazení filmů byly česky? (nepovinné)")):
        dialog.ok(L(30353, "Vlastní databáze filmů a seriálů"),
                  L(30355, "Klíč se zakládá zdarma na themoviedb.org → ikona profilu → Nastavení → API → Request an "
                           "API Key → Developer → zkopírovat „API Key (v3 auth)“.[CR]Podrobný návod je v nápovědě u "
                           "tohoto nastavení."))
        key = dialog.input(L(30356, "API klíč TMDB"))
        if key:
            ADDON.setSetting("tmdb_api_key", key)


def setup_wizard(force=False):
    """Průvodce prvním nastavením — na čisté instalaci se ukáže jako první položka
    kořenového menu (`main_menu()`), ať uživatel nemusí sám hledat, co a kde
    v nastavení vyplnit. Samo od sebe (bez kliknutí) se nespouští — modální dialog
    v cestě, kterou otevírají widgety a JSON-RPC, by blokoval i vypínání Kodi
    (audit 2026-09-14, viz `CLAUDE.md`). Jde přeskočit, nebo si ho kdykoli znovu
    pustit ručně z Nastavení → Pokročilé (`force=True`, běží bez ohledu na to,
    že už proběhl).
    """
    if not force:
        if STORE.load("wizard_done", False):
            return
        # už existující instalace (aktualizace z verze bez průvodce) — má-li
        # uživatel vyplněný účet, není to nová instalace a nemá se ho co ptát.
        # Přepínače zdrojů se hlídat nesmí: sosac/luna/hs mají v settings.xml
        # výchozí true a Kodi ho vrací i bez uloženého nastavení, takže průvodce
        # se na čisté instalaci nikdy nespustil (audit 2026-09-14)
        if accounts_set():
            STORE.save("wizard_done", True)
            return
    dialog = xbmcgui.Dialog()
    if not terms_accepted():
        # dnes už negde jinam projít — router (`main()`) žádnou akci mimo `TERMS_FREE`
        # nepustí bez `ensure_terms()`, takže se sem dostane jen s odsouhlaseným textem.
        # Vlastní krok tu zůstává jako pojistka, kdyby se to spuštění průvodce jednou
        # obešlo (přání uživatele 2026-09-22: souhlas patří i do samotného průvodce).
        dialog.textviewer(L(30728, "Legal notice"), terms_text())
        if not dialog.yesno(L(30728, "Legal notice"),
                            L(30749, "Do you agree to the terms of use above?"),
                            yeslabel=L(30748, "I agree"), nolabel=L(30732, "I don't agree")):
            return
        ADDON.setSetting("terms_ok", "true")
        if not terms_accepted():   # zápis se nepovedl (souběžná změna nastavení) — nepokračovat naslepo
            return
    while True:
        # úvodní volba (přání uživatele 2026-09-16): z mobilu, průvodce ovladačem, nebo přeskočit
        choice = dialog.yesnocustom(
            L(30336, "Vítej v Nokturnu"),
            L(30449, "Vlastní úložiště a volitelně i účty třetích stran můžeš vyplnit v mobilu – na TV se "
                     "ukáže QR kód, stačí mobil ve stejné Wi-Fi a hesla nepíšeš ovladačem. Nebo projdi krátkého průvodce ovladačem.[CR]"
                     "Kdykoli to můžeš přeskočit a doplnit později v Nastavení doplňku."),
            customlabel=L(30450, "Z mobilu"), nolabel=L(30339, "Přeskočit"), yeslabel=L(30451, "Průvodce ovladačem"),
        )
        if choice == 2:
            if remote_setup() is None:
                continue   # zrušeno nebo bez sítě → zpátky na volbu
            break
        if choice == 1:
            _wizard_accounts(dialog)
            break
        STORE.save("wizard_done", True)
        return

    if dialog.yesno(L(30361, "Rychlost internetu"),
                     L(30362, "Chceš teď změřit rychlost internetu a podle ní nastavit nejvyšší dovolený "
                              "datový tok streamů? Zabrání to sekání při přehrávání příliš velkého souboru.[CR]"
                              "Zabere necelou minutu, jde udělat i později v Nastavení → Přehrávání.")):
        speedtest()

    # jen když TMDb Helper je — jinak by otázka nedávala smysl (bez něj Přehrát v detailu
    # filmu z widgetů Nokturna funguje samo, player je jen pro detail z TMDb Helperu)
    if tmdbhelper_installed() and dialog.yesno(
            L(30415, "Přehrát z detailu filmu"),
            L(30416, "Máš doplněk TMDb Helper (detail filmu v Arctic Fuse a dalších skinech).[CR]"
                     "Nastavit Nokturno jako jeho přehrávač? Tlačítko Přehrát v detailu pak hledá "
                     "streamy v Nokturnu.")):
        if not install_tmdbhelper_player(set_default=True):
            notify(L(30413, "Přidání do TMDb Helperu selhalo"), xbmcgui.NOTIFICATION_ERROR)

    lang = tmdbhelper_language()
    if lang and dialog.yesno(
            L(30929, "Jazyk TMDb Helperu"),
            L(30930, "TMDb Helper má vlastní nastavení jazyka a nepřebírá ho z Kodi, takže detail "
                     "filmu a jeho widgety jsou anglicky.[CR]Přepnout TMDb Helper do jazyka Kodi?")):
        xbmcaddon.Addon(TMDBH_ID).setSetting(TMDBH_LANGUAGE_KEY, lang)

    dialog.ok(L(30357, "Nastavení uloženo"),
              L(30358, "Hotovo. Vše se dá kdykoli změnit v nastavení doplňku.[CR]Bez klíče TMDB fungují "
                       "katalogy i hledání dál, jen popisy budou anglicky."))
    STORE.save("wizard_done", True)


def test_sources():
    """Tlačítko v nastavení: během pár vteřin řekne, který zdroj nefunguje a proč.

    Dřív se to poznalo až z prázdného seznamu streamů. Volá se mimo cache, aby
    zelená nebyla jen ozvěna včerejší odpovědi.
    """
    luna, sosac, ws, hs, st = get_luna(), get_sosac(), get_webshare(), get_hellspy(), get_sledujteto()
    fs = get_fastshare()
    pt = get_prehrajto()
    cz = get_cztor()
    storages = get_storages()
    tmdb = get_tmdb()

    def check_sledujteto():
        # přihlášení samo nestačí — bez Premium Sledujteto odkaz na přehrání nevydá
        user = st.me()
        return "Premium" if user.get("is_premium") else L(30406, "bez Premium – přehrávání nepůjde")

    def check_fastshare():
        # přihlášení a kolik zbývá — soubor se odečítá z kreditu, pokud účet nemá neomezený tarif
        account = fs.login()
        if account.get("unlimited"):
            return L(30425, "neomezené stahování")
        return f"{L(30426, 'kredit')} {account.get('credit_mb', 0) / 1024:.1f} GB"

    def check_prehrajto():
        # bez účtu zdroj funguje taky, jen s méně výsledky — ověří se tedy hledáním,
        # a s účtem navíc Premium (bez něj se hraje jen překódovaný soubor)
        found, _total = pt.search("matrix", limit=5)
        if not (pt.email and pt.password):
            return L(30721, "bez účtu, nalezeno %s") % len(found)
        user = pt.me()
        if not user.get("premium"):
            return L(30722, "bez Premium – méně výsledků a jen 1080p")
        return L(30723, "Premium, zbývá dní: %s") % user.get("days", 0)

    def check_cztor():
        # párování se ověří dotazem na účet; bez aktivního předplatného se katalog neotevře
        account = cz.profile()
        if not account.get("active"):
            raise CztorError(L(30572, "Předplatné CZtor není aktivní."))
        return f"{account.get('plan')} → {account.get('valid_until')}"

    def check_luna():
        # manifest Luna vydá i pro neplatný token (jen s výchozím nastavením), takže
        # „přišel manifest" nic neznamená — viz `luna_api.diagnose`
        result = luna_diagnose(setting("luna_url"), setting("token"))
        if result["level"] == "ok":
            return result["version"]
        sid, fallback = LUNA_DIAG_SHORT.get(result["code"], LUNA_DIAG_SHORT["unreachable"])
        raise LunaError(L(sid, fallback))

    checks = {
        # vlastní úložiště první – jen kořen složky, ověří adresu i heslo, strom se prochází až při hledání
        **{api.name: (lambda api=api: api.check()) for api in storages},
        "Luna": check_luna if luna else None,
        "Sosáč": (lambda: len(sosac._get(SOSAC_EXPORT + "souboryzanry.json", ttl=0) or {}))
        if isinstance(sosac, SosacDirect) else None,
        "WebShare": (lambda: bool(ws.login())) if ws else None,
        # mimo cache jako ostatní — HellspyApi bez úložiště se ptá vždy znovu
        "HellSpy": (lambda: len(HellspyApi().search("matrix", limit=5)[0])) if hs else None,
        "Sledujteto": check_sledujteto if st else None,
        ("Sdilej.cz" if fs_provider() == "sdilej" else "FastShare"): check_fastshare if fs else None,
        "Přehraj.to": check_prehrajto if pt else None,
        "CZtor": check_cztor if cz else None,
        # jen ověření klíče, mimo cache — 401 se překládá na "neplatný TMDB API klíč" v tmdb_api._get
        "TMDB": (lambda: tmdb._get("/configuration") and None) if tmdb else None,
    }
    lines = []
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = {name: pool.submit(fn) for name, fn in checks.items() if fn}
        for name in checks:
            if name not in futures:
                lines.append(f"{name}: {L(30169)}")
                continue
            try:
                result = futures[name].result(timeout=20)
                lines.append(f"{name}: {L(30168)}" + (f" ({result})" if isinstance(result, (int, str)) else ""))
            except Exception as e:  # noqa: BLE001 – přesně tohle chceme uživateli ukázat
                # „<zdroj> neodpovídá" místo technického výpisu (TLS, spojení odmítnuto…)
                lines.append(describe_failure(name, e))
    if ws:
        remember_ws_token(ws)
    refresh_accounts_after_test()
    xbmcgui.Dialog().ok(L(30170), "\n".join(lines))


ACCOUNTS_RETRY_AGE = 120   # s; „neodpovídá" mladší než tohle se ještě nezkouší znovu


def request_accounts_retry(engine, rows):
    """Otevřené menu = Kodi v popředí = síť je. Když uložený stav říká „neodpovídá",
    nebo poslední obnova skončila úplně bez sítě, požádat službu o obnovu hned.

    Na mobilu (Samsung, Android 16) Android utne Kodi na pozadí síť: obnova po
    startu (`ACCOUNTS_DELAY`) i další po 20 minutách běží přesně ve chvíli, kdy
    uživatel telefon odložil, a všechny skončí `unreachable` — ověřeno z logu
    2026-09-21 (DNS `Errno 7` pokaždé 3–4 min po startu služby, v popředí ani
    jednou). Jediná chvíle, kdy se dá spolehnout na síť, je tahle.
    """
    try:
        opakovat = any(r.get("code") == "unreachable"
                       and (r.get("age") is None or r["age"] > ACCOUNTS_RETRY_AGE) for r in rows)
        if not opakovat and engine.offline_recently():
            stari = [r["age"] for r in rows if r.get("age") is not None]
            opakovat = not stari or min(stari) > ACCOUNTS_RETRY_AGE
        if opakovat:
            xbmcgui.Window(10000).setProperty(ACCOUNTS_TRIGGER_PROP, "1")
    except Exception as e:  # noqa: BLE001 – menu nesmí spadnout kvůli stavu zdrojů
        log_error(e)


def refresh_accounts_after_test():
    """Po „Ověřit zdroje" požádat službu, ať přepíše i uložený stav pro položku
    Stav zdrojů v menu.

    Jsou to dvě různé cesty: test se ptá zdrojů živě, kdežto menu čte záznam
    z `accounts.json`, který platí dvanáct hodin. Když obnova na pozadí padla
    na vypnutou síť (na mobilu hned po startu Kodi), ukazovalo menu půl dne
    chyby, zatímco test hned vedle hlásil všechno v pořádku.

    Obnova **nesmí běžet tady**: nedostupný zdroj se v ní odbaví až timeoutem
    (Luna 20 s, úložiště taky), takže plugin po testu půl minuty jen točil
    kolečkem — nahlásil uživatel na `6.6.0~beta10`. Stejný vzor jako u
    přepočtu jazykových katalogů: plugin zapíše vlastnost okna, službu to
    probudí do několika sekund a čeká se na pozadí."""
    try:
        xbmcgui.Window(10000).setProperty(ACCOUNTS_TRIGGER_PROP, "1")
    except Exception as e:  # noqa: BLE001 – výsledek testu se musí ukázat i tak
        log_error(e)


# --- Luna: najít v síti a ověřit -------------------------------------------
#
# Luna je ze všech zdrojů jediná, která se instaluje mimo doplněk (server někde
# v síti), a „nefunguje mi to" o ní chodí nejčastěji. Test zdrojů výš na ni
# nestačí: manifest Luna vrátí i pro naprosto neplatný token, takže se tvářila
# zeleně i ve chvíli, kdy z ní nikdy nemohl přijít jediný stream.

# kód z `luna_api.diagnose` → (id řetězce, český fallback); %s je verze Luny a její adresa
LUNA_DIAG_TEXTS = {
    "ok": (30520, "Luna %s odpovídá a vrací streamy. Nastavení je v pořádku."),
    "no_url": (30521, "Není vyplněná adresa Luny ani token.[CR]Použij „Najít Lunu v síti“, nebo vlož "
                      "do pole Token celou adresu doplňku ze stránky /setup Luny."),
    "bad_url": (30522, "Adresa %s nemá očekávaný tvar.[CR]Očekává se například 192.168.1.10:7126."),
    "unreachable": (30523, "Na adrese %s se nikdo neozval.[CR][CR]Běží počítač, kde je Luna spuštěná? Je ve stejné "
                           "síti jako toto zařízení? Zkus „Najít Lunu v síti“."),
    "not_luna": (30524, "Na adrese %s něco odpovídá, ale není to Luna.[CR]Zkontroluj port – Luna má "
                        "výchozí 7126."),
    "no_token": (30525, "Luna %s běží, ale chybí token.[CR][CR]Otevři v prohlížeči %s/setup, zkopíruj "
                        "adresu doplňku a vlož ji celou do pole Token – adresu i token z ní doplněk "
                        "vytáhne sám."),
    "bad_token_format": (30526, "V poli Token není token.[CR][CR]Token začíná „e1.“ a je dlouhý. Otevři "
                                "%s/setup a zkopíruj celou adresu doplňku."),
    "bad_token": (30527, "Luna %s běží, ale tento token nepřijala.[CR][CR]Vygeneruj si adresu doplňku "
                         "znovu na %s/setup a vlož ji celou do pole Token."),
    "main_empty": (30528, "Luna %s odpovídá a hledání na WebShare funguje, ale její hlavní zdroj nic "
                          "nevrací.[CR][CR]Zkontroluj na %s/setup účet WebShare a jestli je token opravdu z této "
                          "Luny."),
    "no_streams": (30529, "Luna %s běží, ale nenašla streamy ani u známých filmů.[CR][CR]Nejčastěji "
                          "chybí účet WebShare v samotné Luně – otevři %s/setup a doplň ho."),
}


# totéž na jeden řádek — „Ověřit zdroje" má pro každý zdroj jen řádek, ne odstavec
LUNA_DIAG_SHORT = {
    "no_url": (30543, "chybí adresa i token"),
    "bad_url": (30544, "adresa nedává smysl"),
    "unreachable": (30545, "server neodpovídá"),
    "not_luna": (30546, "na té adrese neběží Luna"),
    "no_token": (30547, "běží, ale chybí token"),
    "bad_token_format": (30548, "v poli Token není token"),
    "bad_token": (30549, "token Luna nepřijala"),
    "main_empty": (30550, "hlavní zdroj nic nevrací – účet WebShare v Luně?"),
    "no_streams": (30551, "nenašla žádné streamy – účet WebShare v Luně?"),
}

# co se v které hlášce dosazuje za %s (pořadí podle textu)
LUNA_DIAG_ARGS = {
    "ok": ("version",),
    "bad_url": ("base",),
    "unreachable": ("base",),
    "not_luna": ("base",),
    "no_token": ("version", "base"),
    "bad_token_format": ("base",),
    "bad_token": ("version", "base"),
    "main_empty": ("version", "base"),
    "no_streams": ("version", "base"),
}


def luna_diag_text(result, base=""):
    """Věta a rada k výsledku `luna_diagnose` (Kodi značky `[CR]` zůstávají)."""
    sid, fallback = LUNA_DIAG_TEXTS.get(result["code"], LUNA_DIAG_TEXTS["unreachable"])
    hodnoty = {"version": result.get("version") or "?", "base": result.get("base") or base}
    try:
        return L(sid, fallback) % tuple(hodnoty[k] for k in LUNA_DIAG_ARGS.get(result["code"], ()))
    except TypeError:   # překlad se zástupnými symboly nesouhlasí — radši holý text než pád
        return L(sid, fallback)


# --- stav zdrojů ------------------------------------------------------------
#
# „Prostě mi to nejde" má několik různých příčin, které od sebe uživatel u televize
# nerozezná: vypršené předplatné, účet bez VIP, pauza HellSpy po 429, Luna, která
# neběží. Do teď to šlo poznat jen z prázdného seznamu streamů, nebo tlačítkem
# „Ověřit zdroje" schovaným v nastavení. Teď je stav první položkou menu — ale jen
# když je co hlásit, ať se menu nezaplevelí.
#
# Data přicházejí z `accounts.py` v jádru jako kód příčiny a čísla; věta se skládá
# až tady, protože HA jich potřebuje jinou podobu. Stav se **čte z uloženého
# záznamu**, po síti ho obnovuje služba na pozadí (`AccountsChecker` v service.py) —
# otevření menu se tím nesmí zdržet ani o milisekundu.

# Stav slovem v barvě zadané hexem. Emoji a ✔/✘ kreslí fonty skinů jako prázdný
# proužek a pojmenované barvy (`green`) závisí na skinu — viz `5.2.30~beta2`.
ACCOUNT_COLORS = {ACC_FAIL: "FFFF6B6B", ACC_WARN: "FFFFC14E", ACC_OK: "FF6FD18A", ACC_OFF: "FF9A9A9A"}

# Jméno zdroje tak, jak ho uživatel zná ze seznamu streamů (obarvené stejně).
ACCOUNT_TAGS = {"luna": LUNA_TAG, "sosac": SOSAC_TAG, "webshare": WS_TAG, "cztor": CZ_TAG,
                "fastshare": FS_TAG, "sledujteto": ST_TAG, "prehrajto": PT_TAG, "hellspy": HS_TAG,
                "storage": DAV_TAG}

# (zdroj, kód) → (id řetězce, český fallback). `%s` se dosazuje z `detail`, viz
# `ACCOUNT_ARGS`. Luna má vlastní sadu už od 5.2.30 (`LUNA_DIAG_SHORT`), tady se
# jen použije. Kódy `off`/`unknown` se nehlásí vůbec — zdroj je vypnutý, nebo se
# ho doplněk ještě nestihl zeptat.
ACCOUNT_TEXTS = {
    ("webshare", "vip"): (30631, "předplatné do %s"),
    ("webshare", "expires_soon"): (30632, "do konce předplatného zbývá dní: %s"),
    ("webshare", "expired"): (30633, "předplatné vypršelo"),
    ("webshare", "free"): (30634, "účet bez VIP – stahování pár kB/s"),
    ("fastshare", "unlimited"): (30635, "neomezené stahování"),
    ("fastshare", "credit"): (30636, "zbývá %s GB kreditu"),
    ("fastshare", "no_credit"): (30637, "došel kredit"),
    ("cztor", "ok"): (30638, "%s do %s"),
    ("cztor", "expires_soon"): (30639, "do konce předplatného zbývá dní: %s"),
    ("cztor", "expired"): (30640, "předplatné vypršelo"),
    ("cztor", "not_paired"): (30641, "zařízení není spárované"),
    ("cztor", "unknown"): (30642, "stav účtu neznámý"),
    ("sledujteto", "premium"): (30643, "Premium"),
    ("sledujteto", "no_premium"): (30644, "účet bez Premium – přehrávání nepůjde"),
    ("prehrajto", "premium"): (30715, "Premium, zbývá dní: %s"),
    ("prehrajto", "expires_soon"): (30716, "do konce předplatného zbývá dní: %s"),
    ("prehrajto", "no_premium"): (30717, "účet bez Premium – méně výsledků a jen 1080p"),
    ("prehrajto", "anonymous"): (30718, "bez účtu – jen první strana výsledků"),
    ("prehrajto", "paused"): (30719, "pozastaveno na %s min (HTTP 429)"),
    # Sosáč se na nic neptá, řádek je tu kvůli uspání zdroje — text sdílí s HellSpy
    ("sosac", "ok"): (30645, "v pořádku"),
    ("hellspy", "ok"): (30645, "v pořádku"),
    # 429 od HellSpy = blokace sítě uživatele, ne limit dotazů (viz `source_errors`)
    ("hellspy", "paused"): (30646, "odmítá tuto síť (HTTP 429) – VPN nebo mobilní data? Zkusí se za %s min"),
    ("storage", "ok"): (30647, "odpovídá"),
}

# Totéž zkrácené pro štítek položky v menu. Skin má na řádek zhruba čtyřicet znaků
# a delší text si roluje pod rukama — na Office bylo z „Stav zdrojů: Luna: server
# neodpovídá · WebShare: předplatné vypršelo · +2" vidět jen prostředek věty a
# uživatel nepoznal, co čte. Ve výpisu pod tím má každý zdroj vlastní řádek, takže
# tam zůstává plný text z `ACCOUNT_TEXTS`.
ACCOUNT_SHORT = {
    ("webshare", "expires_soon"): (30651, "zbývá dní: %s"),
    ("webshare", "free"): (30652, "účet bez VIP"),
    ("fastshare", "credit"): (30653, "zbývá %s GB"),
    ("cztor", "expires_soon"): (30651, "zbývá dní: %s"),
    ("cztor", "not_paired"): (30654, "není spárováno"),
    ("sledujteto", "no_premium"): (30655, "účet bez Premium"),
    ("prehrajto", "expires_soon"): (30651, "zbývá dní: %s"),
    ("prehrajto", "no_premium"): (30720, "účet bez Premium"),
    ("prehrajto", "paused"): (30656, "pozastaveno %s min"),
    ("hellspy", "paused"): (30725, "odmítá síť"),
}

ACCOUNT_COMMON_SHORT = {
    "bad_login": (30657, "nesedí přihlášení"),
    "error": (30658, "stav neznámý"),
}

# co platí pro každý zdroj stejně (selhání kontroly, viz `engine._account_fail_code`)
ACCOUNT_COMMON = {
    "bad_login": (30648, "nesedí jméno nebo heslo"),
    "unreachable": (30649, "neodpovídá"),
    "error": (30650, "nepodařilo se zjistit stav"),
}

# co se v které hlášce dosazuje za %s (pořadí podle textu)
ACCOUNT_ARGS = {
    ("webshare", "vip"): ("until",),
    ("webshare", "expires_soon"): ("days",),
    ("fastshare", "credit"): ("gb",),
    ("cztor", "ok"): ("plan", "until"),
    ("cztor", "expires_soon"): ("days",),
    ("hellspy", "paused"): ("minutes",),
    ("prehrajto", "premium"): ("days",),
    ("prehrajto", "expires_soon"): ("days",),
    ("prehrajto", "paused"): ("minutes",),
}


def account_text(row, short=False):
    """Stav jednoho zdroje jednou větou, bez jeho jména — to dodává volající.
    `short` vrátí variantu do štítku menu, kde je místo jen na pár slov."""
    source, code = row["source"], row["code"]
    if source == "luna":
        sid, fallback = LUNA_DIAG_SHORT.get(code, (30168, "v pořádku") if code == "ok" else
                                            LUNA_DIAG_SHORT["unreachable"])
    elif short:
        sid, fallback = (ACCOUNT_SHORT.get((source, code)) or ACCOUNT_COMMON_SHORT.get(code)
                         or ACCOUNT_TEXTS.get((source, code)) or ACCOUNT_COMMON.get(code)
                         or ACCOUNT_COMMON_SHORT["error"])
    else:
        sid, fallback = ACCOUNT_TEXTS.get((source, code)) or ACCOUNT_COMMON.get(code) or ACCOUNT_COMMON["error"]
    detail = row.get("detail") or {}
    args = tuple(str(detail.get(k, "?")) for k in ACCOUNT_ARGS.get((source, code), ()))
    try:
        return L(sid, fallback) % args if args else L(sid, fallback)
    except TypeError:   # překlad se zástupnými symboly nesouhlasí — radši holý text než pád
        return L(sid, fallback)


def account_line(row, color=True, short=False):
    """„WebShare: předplatné končí za 3 dny" — jméno zdroje a stav, stav v barvě."""
    tag = source_tag(row["source"]) or ACCOUNT_TAGS.get(row["source"]) or row["source"]
    text = account_text(row, short=short)
    if color:
        text = f"[COLOR {ACCOUNT_COLORS.get(row['level'], ACCOUNT_COLORS[ACC_OK])}]{text}[/COLOR]"
    return f"{tag}: {text}"


# kam vede klik na řádek — rovnou tam, kde se to opravuje
ACCOUNT_ACTIONS = {
    "luna": {"": "luna_check"},
    "cztor": {"not_paired": "cztor_pair", "": "cztor_status"},
    "webshare": {"expires_soon": "sub_status", "expired": "sub_status", "": "settings"},
}


def account_action(row):
    podle_zdroje = ACCOUNT_ACTIONS.get(row["source"]) or {}
    return podle_zdroje.get(row["code"]) or podle_zdroje.get("") or "settings"


# Kolik zdrojů se vejde do štítku v menu. Jeden, a ještě zkráceně: skin má na řádek
# zhruba čtyřicet znaků a delší text si sám roluje, takže z něj uživatel vidí
# v každém okamžiku jen výsek. Ověřeno na Office se dvěma zdroji a „+2" — ze štítku
# bylo vidět „server neodpovídá · WebShare: předplatné" bez začátku i konce.
# Zbytek patří do výpisu pod položkou, kde má každý zdroj vlastní řádek.
SUMMARY_LIMIT = 1


def account_summary(rows, limit=SUMMARY_LIMIT):
    """Štítek položky v menu: „WebShare: končí za 3 dní · +2"."""
    bad = accounts_problems(rows)
    if not bad:
        return ""
    texty = [account_line(r, short=True) for r in bad[:limit]]
    if len(bad) > limit:
        texty.append(f"[COLOR {GREY}]+{len(bad) - limit}[/COLOR]")
    return " · ".join(texty)


def accounts_refresh(apis):
    """Obnova stavu účtů po síti — volá ji služba na pozadí přes JSON-RPC, stejnou
    cestou jako zahřívání katalogů (služba vlastní jádro nemá).

    Jeden dotaz na zdroj; HellSpy se neptá vůbec, jen si přečte svou pauzu po 429 —
    právě opakovanými dotazy si doplněk blokaci dvakrát přivodil (6.0.2, 6.0.4).
    """
    try:
        warn_days = int(setting("sub_warn_days") or 5)
    except ValueError:
        warn_days = 5
    try:
        engine_of(apis).refresh_accounts(warn_days=warn_days)
    except Exception as e:  # noqa: BLE001 – obnova na pozadí nesmí nikdy nic shodit
        log_error(f"obnova stavu zdrojů: {e}")
    # jako u `prefetch()`: prázdný, ale úspěšně zavřený adresář, ať služba nedělá
    # v každém kole řádek `error <general>: GetDirectory` v kodi.log
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)


def list_accounts(apis):
    """Výpis stavu všech nastavených zdrojů — žádný modál, ten by z widgetu nebo
    JSON-RPC neměl kdo zavřít a zablokoval by i vypínání Kodi."""
    engine = engine_of(apis)
    rows = engine.accounts()
    # nadpis obrazovky — 30630 se uvolnilo ze štítku položky v menu (viz main_menu)
    xbmcplugin.setPluginCategory(HANDLE, L(30630, "Stav zdrojů"))
    paused = accounts_paused(STORE)
    for row in rows:
        if row["level"] == ACC_OFF and row["code"] == "off":
            continue    # zdroj je vypnutý schválně, není co hlásit
        label = account_line(row)
        zbyva = paused.get(row["source"])
        if zbyva:
            label += f" [COLOR {GREY}]({int(zbyva // 60) + 1}m)[/COLOR]"
        ctx = [(L(30742, "Uspat zdroj"), runplugin(action="source_pause", source=row["source"]))]
        action_item(label, build_url(action=account_action(row)),
                    icon="DefaultAddonService.png", context=ctx)
    # ne-složka jako Nastavení pod ní: jako složka by Kodi po kliknutí čekal na
    # výpis adresáře, který `test_sources` nikdy nezavře — po OK v dialogu se
    # točilo kolečko navěky (nahlášeno z mobilu na `6.6.0~beta11`)
    action_item(L(30167, "Ověřit zdroje"), build_url(action="test_sources"), icon="DefaultAddonProgram.png",
                info=L(31102, "Zkusí se přihlásit ke každému zdroji a ukáže, který nefunguje."))
    action_item(L(30392, "Nastavení"), build_url(action="settings"), icon="DefaultAddonProgram.png",
                info=L(31083, "Zdroje, účty, přehrávání, synchronizace a vzhled doplňku."))
    # bez cache na disk — stav se mění, zpět do menu by jinak ukázalo starý výpis
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def luna_find_remote(values):
    """Najít Lunu ze stránky „Nastavit z mobilu“: běží ve vlákně serveru, jen vrátí adresu
    stránce — do nastavení se uloží až tlačítkem Uložit."""
    found = luna_discover()
    if not found:
        return {"level": "fail", "text": _stranka(L(30531, "V této síti se Luna nenašla."))}
    return {"level": "ok", "text": _stranka(L(30576, "Luna nalezena: %s") % ", ".join(f["url"] for f in found)),
            "set": {"luna_url": found[0]["url"]}, "link": _luna_setup_link(found[0]["url"])}


def luna_check_remote(values):
    """Ověřit Lunu ze stránky „Nastavit z mobilu“ s tím, co je právě ve formuláři."""
    base = values.get("luna_url", "")
    # token je teď skryté pole (heslo se na stránku nikdy neposílá, viz remote_setup.py) —
    # prázdné odeslání neznamená „smaž token“, ale „nikdo ho nepřepsal“
    token = values.get("token") or setting("token")
    try:
        result = luna_diagnose(base, token)
    except Exception as e:  # noqa: BLE001 – ať akce nikdy nespadne bez vysvětlení
        result = {"level": "fail", "code": "unreachable", "base": base, "token": "", "version": "",
                  "detail": str(e)}
    out = {"level": result["level"], "text": _stranka(luna_diag_text(result, base)), "set": {}}
    if result.get("base") and result["base"] != base:
        out["set"]["luna_url"] = result["base"]
    if result.get("token") and result["token"] != token:   # celá adresa ze /setup se rozdělí
        out["set"]["token"] = result["token"]
    if result["code"] in ("no_token", "bad_token", "bad_token_format", "main_empty", "no_streams"):
        out["link"] = _luna_setup_link(result.get("base") or base)   # token se bere právě tam
    return out


def _luna_setup_link(base):
    """Odkaz na stránku /setup Luny — tam se vezme adresa doplňku s tokenem."""
    return {"url": base.rstrip("/") + "/setup", "label": L(30581, "Otevřít nastavení Luny (/setup)")}


def _stranka(text):
    """Text z `strings.po` pro webovou stránku: `[CR]` na nový řádek, ostatní Kodi značky pryč."""
    return _plain(text.replace("[CR]", "\n"))


def terms_show_remote(values):
    """Tlačítko „Přečíst podmínky“ ve Stavu zdrojů z mobilu — stejný text jako `info_terms()`
    na TV, jen na stránce místo v modálu."""
    return {"level": "ok", "text": _stranka(terms_text())}


def os_check():
    """Tlačítko „Vyzkoušet OpenSubtitles“ v nastavení.

    Odpovídá na tři různé otázky, které z hlášky „nefunguje mi to“ nejdou rozeznat:
    jestli je zdroj vůbec zapnutý, jestli doplněk dostal ze serveru klíč, a jestli
    se (u vyplněného účtu) podařilo přihlásit. Hledá se zkušební titul, ne stahuje —
    stažení by ukrojilo z denní kvóty právě toho, kdo si jen ověřuje nastavení.
    """
    from opensubtitles_api import OpenSubtitlesError   # líný import, viz reuse invoker
    if not on("os_enabled"):
        xbmcgui.Dialog().ok(L(30611, "OpenSubtitles"), L(30622, "OpenSubtitles jsou v nastavení vypnuté."))
        return
    api = get_opensubtitles()
    if api is None:
        xbmcgui.Dialog().ok(L(30611, "OpenSubtitles"),
                    L(30623, "Klíč se nepodařilo získat ze serveru – zkus to později."))
        return
    radky = []
    try:
        ucet = api.ucet()
    except OpenSubtitlesError as err:
        xbmc.log(f"[{ADDON_ID}] OpenSubtitles účet: {err}", xbmc.LOGINFO)
        xbmcgui.Dialog().ok(L(30611, "OpenSubtitles"),
                    L(30624, "Přihlášení se nepodařilo – zkontroluj jméno a heslo."))
        return
    if ucet:
        radky.append(L(30627, "Přihlášen jako %s") % ucet["user"])
        radky.append(L(30626, "Zbývá dnes stažení: %s") % ucet["zbyva"])
    else:
        radky.append(L(30628, "Bez přihlášení – 5 stažení denně pro tuto IP adresu."))
    nalez = api.hledej(OS_PROBE_ID, ("CZ", "SK"))
    radky.insert(0, L(30621, "OpenSubtitles funguje.") if nalez
                 else L(30623, "Klíč se nepodařilo získat ze serveru – zkus to později."))
    radky.append(L(30625, "Titulků ke zkušebnímu titulu: %s") % len(nalez))
    xbmcgui.Dialog().ok(L(30611, "OpenSubtitles"), "\n".join(radky))


def luna_find():
    """Tlačítko v nastavení: projde vlastní podsíť a najde server Luny.

    Adresa je první, co lidem nesedí — opisují ji z návodu, ne ze své sítě.
    Sken je levný (TCP klepnutí na 7126, celá podsíť do pár vteřin) a za Lunu
    se prohlásí jen to, co se k ní přizná v manifestu.
    """
    dialog = xbmcgui.DialogProgress()
    dialog.create(L(30000, "Nokturno"), L(30530, "Hledám Lunu v místní síti…"))
    try:
        found = luna_discover(
            on_progress=lambda done, total: dialog.update(int(done * 100 / max(total, 1))),
            should_stop=lambda: dialog.iscanceled() or should_stop())
    except Exception as e:  # noqa: BLE001 – bez sítě, bez IPv4 adresy
        found = []
        xbmc.log(f"[Nokturno] hledání Luny selhalo: {e}", xbmc.LOGWARNING)
    finally:
        dialog.close()

    if not found:
        xbmcgui.Dialog().ok(L(30000, "Nokturno"),
                            L(30531, "V této síti se Luna nenašla.[CR][CR]Běží na některém počítači "
                                     "v domácnosti? Má výchozí port 7126? Pokud běží jinde nebo na jiném "
                                     "portu, vyplň adresu ručně."))
        return
    pick = 0 if len(found) == 1 else xbmcgui.Dialog().select(
        L(30532, "Nalezené servery Luny"), [f"{f['url']}   ({f['name']} {f['version']})" for f in found])
    if pick < 0:
        return
    ADDON.setSetting("luna_url", found[pick]["url"])
    ADDON.setSetting("luna_enabled", "true")
    # rovnou navážeme ověřením — samotná adresa bez tokenu ještě nic nepřehraje.
    # Adresu předáme přímo: `getSetting` by při otevřeném dialogu nastavení vrátil
    # ještě tu starou (prázdnou) a ověření by hlásilo „adrese nerozumím“
    luna_check(found[pick]["url"])


def luna_check(base=None, token=None, kolo=0, ask=False):
    """Tlačítko v nastavení: řekne, na kterém článku řetězu to stojí.

    Vrací jednu větu a k ní radu, co s tím — ne technický výpis. Když to
    nevyjde, nabídne zadat adresu rovnou tady a poslat log, aby nebylo nutné
    popisovat problém slovy („nejde mi to“ se nedá opravit).

    `base`/`token` se předávají **přímo**, ne přes nastavení: dokud je otevřený
    dialog nastavení, Kodi v něm rozepsanou hodnotu drží zvlášť — `getSetting()`
    vrátí ještě tu uloženou, i když `setSetting()` už novou do políčka zapsal
    (`luna_find` → `luna_check` na to doplatilo hláškou „adrese nerozumím“ nad
    adresou, kterou právě samo našlo a vyplnilo).
    """
    base = setting("luna_url") if base is None else base
    token = setting("token") if token is None else token
    if ask:
        # Kodi nedá akci to, co má uživatel rozepsané v políčku (uloží se až na OK),
        # takže se na adresu ptáme rovnou tady — nastavení se kvůli ověření nemusí
        # ukládat vůbec. Předvyplněná je ta uložená, takže „OK" stačí beze změny.
        zadano = xbmcgui.Dialog().input(L(30556, "Adresa Luny (nebo celá adresa doplňku ze /setup)"),
                                        defaultt=base)
        if not zadano:
            return
        base, token = zadano, parse_token(token) or token
    dialog = xbmcgui.DialogProgress()
    dialog.create(L(30000, "Nokturno"), L(30533, "Ověřuji Lunu…"))
    try:
        result = luna_diagnose(base, token)
    except Exception as e:  # noqa: BLE001 – ať tlačítko nikdy nespadne bez vysvětlení
        result = {"level": "fail", "code": "unreachable", "base": base, "token": "",
                  "version": "", "detail": str(e)}
    finally:
        dialog.close()

    # co jde spravit za uživatele, spravíme rovnou: celá adresa vložená do pole
    # tokenu (nejčastější vložení ze /setup) se rozdělí na adresu a token
    if result.get("base") and result["base"] != setting("luna_url"):
        ADDON.setSetting("luna_url", result["base"])
    if result.get("token") and result["token"] != setting("token"):
        ADDON.setSetting("token", result["token"])

    sid, fallback = LUNA_DIAG_TEXTS.get(result["code"], LUNA_DIAG_TEXTS["unreachable"])
    text = luna_diag_text(result, setting("luna_url"))
    # stav slovem, ne symbolem: fonty skinů Kodi znaky jako ✔/✘ většinou nemají a
    # nakreslí místo nich prázdný proužek (totéž řeší EMOJI_MAP v jádru u popisků Luny).
    # Barvy hexem jako ostatní štítky — pojmenované („green“) závisí na skinu.
    mark = {"ok": f"[COLOR FF7BC96F]{L(30552, 'V pořádku')}[/COLOR][CR]",
            "warn": f"[COLOR FFF2C14E]{L(30553, 'Pozor')}[/COLOR][CR]"}.get(
        result["level"], f"[COLOR FFFF8A6B]{L(30554, 'Nepovedlo se')}[/COLOR][CR]")
    if result.get("detail") and result["level"] != "ok":
        xbmc.log(f"[Nokturno] diagnostika Luny: {result['code']} – {result['detail']}", xbmc.LOGINFO)

    if result["level"] == "ok":
        xbmcgui.Dialog().ok(L(30534, "Ověření Luny"), f"{mark}{text}")
        return
    # Zadat adresu je první volba schválně: ověřuje se uložené nastavení, takže
    # hodnota právě přepsaná v políčku (bez OK) se sem jinak nedostane
    volba = xbmcgui.Dialog().yesnocustom(
        L(30534, "Ověření Luny"), f"{mark}{text}[CR][CR]" + L(30557, "Ověřuje se uložené nastavení – hodnota "
                                                                    "rozepsaná v políčku se započítá až po OK. "
                                                                    "Jinou adresu lze zadat rovnou zde."),
        customlabel=L(30536, "Poslat log"), nolabel=L(30537, "Zavřít"), yeslabel=L(30555, "Zadat adresu"))
    if volba == 1 and kolo < 3:      # Zadat adresu → zkusit znovu s ní
        nova = xbmcgui.Dialog().input(L(30556, "Adresa Luny (nebo celá adresa doplňku ze /setup)"),
                                      defaultt=result.get("base") or base)
        if nova:
            # token nechat čistý: kdyby v něm zůstala stará celá adresa, přebila by
            # tuhle zadanou (`diagnose` bere adresu přednostně z tokenu)
            luna_check(nova, parse_token(token) or token, kolo + 1)
    elif volba == 2:                 # Poslat log
        log_send(ask=False)


SPEEDTEST_URL = "https://speed.cloudflare.com/__down?bytes=52428800"  # 50 MB, i na rychlém připojení stačí pár vteřin
SPEEDTEST_SECONDS = 8       # déle nemá smysl čekat, průměr se stejně ustálí dřív
SPEEDTEST_RESERVE = 0.25    # rezerva, aby přehrávání nezasekávalo při kolísání rychlosti


def speedtest():
    """Tlačítko v nastavení: změří rychlost stahování a uloží ji jako
    dovolený datový tok s 25% rezervou — viz `Engine._effective_max_gb`, kde
    se teprve pro konkrétní titul a jeho stopáž mění na GB.
    """
    dialog = xbmcgui.DialogProgress()
    dialog.create(L(30000), L(30402, "Měřím rychlost stahování…"))
    got, t0 = 0, time.time()
    try:
        req = urllib.request.Request(SPEEDTEST_URL, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            while True:
                if dialog.iscanceled():
                    dialog.close()
                    return
                chunk = resp.read(262144)
                if not chunk:
                    break
                got += len(chunk)
                elapsed = time.time() - t0
                dialog.update(min(99, int(elapsed / SPEEDTEST_SECONDS * 100)), f"{got / 2**20:.0f} MB")
                if elapsed >= SPEEDTEST_SECONDS:
                    break
    except Exception as e:  # noqa: BLE001 – síť, DNS, vypršelý čas
        dialog.close()
        notify(f"{L(30221, 'Měření rychlosti selhalo')}: {str(e)[:80]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        return
    dialog.close()
    elapsed = max(time.time() - t0, 0.5)
    if got < 512 * 1024:
        # míň než půl megabajtu je jen šum (pomalé DNS, krátké přerušení) — s tím se nepočítá
        notify(L(30222, "Stáhlo se příliš málo dat, zkus to znovu"), xbmcgui.NOTIFICATION_WARNING, 5000)
        return
    mbps = got * 8 / elapsed / 1_000_000
    allowed_mbps = round(mbps * (1 - SPEEDTEST_RESERVE), 1)
    ADDON.setSetting("max_bitrate_mbps", str(allowed_mbps))
    example_gb = allowed_mbps * 1_000_000 * DEFAULT_RUNTIME_S / 8 / 2 ** 30
    notify(Lf(30223, f"{mbps:.0f}", f"{allowed_mbps:g}", f"{example_gb:.1f}"), xbmcgui.NOTIFICATION_INFO, 7000)


def update_repos():
    """Tlačítko v nastavení: kontrola repozitářů hned, ne až podle plánu Kodi — po
    vydání (hlavně bety) se jinak čeká klidně den, než Kodi aktualizaci nabídne."""
    xbmc.executebuiltin("UpdateAddonRepos")
    notify(L(30408, "Kontroluji aktualizace doplňků…"))


TMDBH_ID = "plugin.video.themoviedb.helper"
# složka vlastních playerů TMDb Helperu (`PLAYERS_BASEDIR_USER` v jeho lib/addon/consts.py)
TMDBH_PLAYER = f"special://profile/addon_data/{TMDBH_ID}/players/nokturno.json"
TMDBH_PLAYER_SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "players", "nokturno.json")


def tmdbhelper_installed():
    return bool(xbmc.getCondVisibility(f"System.HasAddon({TMDBH_ID})"))


def install_tmdbhelper_player(set_default=True):
    """Uloží player Nokturna do TMDb Helperu a volitelně ho nastaví jako výchozí přehrávač
    filmů i dílů. False, když TMDb Helper chybí nebo se soubor nepodařilo zapsat.
    Sdílí ho tlačítko v nastavení (`tmdbhelper_player`) i průvodce prvním nastavením."""
    if not tmdbhelper_installed():
        return False
    dest = xbmcvfs.translatePath(TMDBH_PLAYER)
    xbmcvfs.mkdirs(os.path.dirname(dest))
    if not xbmcvfs.copy(TMDBH_PLAYER_SRC, dest):
        return False
    if set_default:
        # hodnota ve tvaru, jaký ukládá TMDb Helper sám (`<soubor> <režim>`, config/default.py).
        # `System.HasAddon` výš hlásí i vypnutý doplněk, ale `xbmcaddon.Addon()` na vypnutý
        # doplněk spadne — RuntimeError bereme stejně jako "TMDb Helper tu není".
        try:
            tmdbh = xbmcaddon.Addon(TMDBH_ID)
        except RuntimeError:
            return False
        tmdbh.setSetting("default_player_movies", "nokturno.json play_movie")
        tmdbh.setSetting("default_player_episodes", "nokturno.json play_episode")
    return True


# TMDb Helper má jazyk TMDB jako vlastní volbu (index do `LANGUAGES` v jeho
# lib/addon/consts.py), jazyk Kodi nepřebírá a výchozí je en-US (18) — detail filmu
# a widgety jsou pak anglicky i v českém Kodi. Nové jazyky přidává na konec seznamu.
TMDBH_LANGUAGES = {"cs": "7", "sk": "53", "hu": "31"}
TMDBH_LANGUAGE_KEY = "language"   # nastavení TMDb Helperu, ne Nokturna


def tmdbhelper_language():
    """Index jazyka pro TMDb Helper podle jazyka Kodi, nebo None, když ho TMDb Helper
    už má (nebo jazyk Kodi neznáme, nebo je doplněk vypnutý)."""
    want = TMDBH_LANGUAGES.get(xbmc.getLanguage(xbmc.ISO_639_1))
    if not want or not tmdbhelper_installed():
        return None
    try:
        current = xbmcaddon.Addon(TMDBH_ID).getSetting(TMDBH_LANGUAGE_KEY)
    except RuntimeError:  # vypnutý doplněk, viz install_tmdbhelper_player
        return None
    return None if current == want else want


def tmdbhelper_player():
    """Tlačítko v nastavení: „Přehrát“ v detailu filmu nebo dílu z TMDb Helperu (Arctic Fuse
    a další skiny ho používají pro info stránky) pustí hledání streamů v Nokturnu.

    TMDb Helper přehrává přes JSON „playery“ ve své složce — bez nich Přehrát v detailu nic
    z Nokturna nevyvolá. Player jde podle IMDb id (u dílu id seriálu + sezóna a díl), takže
    nehledá podle názvu. Nainstalovaný soubor pak po aktualizacích drží aktuální služba."""
    if not tmdbhelper_installed():
        notify(L(30410, "TMDb Helper není nainstalovaný"), xbmcgui.NOTIFICATION_WARNING)
        return
    set_default = xbmcgui.Dialog().yesno(L(30000, "Nokturno"), L(30411, "Nastavit Nokturno jako výchozí přehrávač v "
                                                                        "TMDb Helperu? Přehrát v detailu filmu nebo "
                                                                        "dílu pak rovnou hledá streamy v Nokturnu."))
    if not install_tmdbhelper_player(set_default):
        notify(L(30413, "Přidání do TMDb Helperu selhalo"), xbmcgui.NOTIFICATION_ERROR)
        return
    notify(L(30412, "Nokturno je v TMDb Helperu"))


# Zahřívání streamů dalšího dílu: jen seriály sledované za posledních PREFETCH_DAYS dní,
# nejvýš PREFETCH_SERIES z nich (každý = hledání napříč všemi zdroji + čtení hlaviček).
# Do 6.1.4 se braly poslední 15 zhlédnuté položky bez ohledu na stáří — u instalace,
# která seriály dva měsíce neotevřela, se tak po každém startu Kodi hledaly díly
# dávno opuštěných seriálů.
PREFETCH_DAYS = 14
PREFETCH_SERIES = 5
PREFETCH_SCAN = 30


def prefetch(apis, kind):
    """Zahřátí cache — volá služba na pozadí, nic se nevypisuje ani nepočítá.

    Katalogy zahřívá služba přes běžný výpis (Files.GetDirectory), protože ten
    projde i doplněním popisů; tohle je jen pro streamy dalších dílů, kde by
    běžná cesta (`pick_title`) započítala zobrazení do statistik.
    """
    if kind == "next":
        prune_mylist(apis=apis)
        seen = set()
        fresh_since = time.time() - PREFETCH_DAYS * 86400
        for key, entry in STORE.recently_watched(PREFETCH_SCAN):
            if should_stop():
                break   # Kodi končí — každý titul je vlastní hledání napříč zdroji, tady se nic necachuje napůl
            if (entry.get("ts") or 0) < fresh_since or len(seen) >= PREFETCH_SERIES:
                break   # seřazené od nejnovějšího: starší zhlédnutí už nikoho nezajímá
            snap = STORE.item(key)
            if not snap or snap.get("season") is None or snap.get("series") in seen:
                continue
            seen.add(snap.get("series"))
            found = next_episode(apis, snap)
            if not found:
                continue
            video, meta = found
            ep_id = video.get("id") or f"{snap['series']}:{video.get('season')}:{video.get('episode')}"
            if STORE.playcount(ep_id):
                continue
            try:
                with engine_of(apis).background():
                    collect_streams(apis, "series", ep_id, meta, snap.get("alt"), track=False)
            except Errors as e:
                log_error(f"prefetch {ep_id}: {e}")
    # Služba sem chodí přes Files.GetDirectory (JSON-RPC), a `succeeded=False` Kodi hlásí
    # jako `GetDirectory - Error getting plugin://…?action=prefetch` — v každém kole
    # zahřívání jeden řádek `error` v kodi.log, který uživatelé posílají na dashboard.
    # Prázdný, ale úspěšně zavřený adresář je totéž bez té hlášky (nic se nekreslí,
    # `cacheToDisc=False` drží Kodi od zapamatování prázdného výpisu).
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)


def stats_sources():
    """Které zdroje jsou v nastavení aktivní — do statistik, bez účtů a adres.
    Výčet je v `kodi_sources`, protože ho stejně potřebuje i služba."""
    return kodi_sources.stats_sources(ADDON.getSetting)


def stats_send():
    """Ruční odeslání statistik z nastavení – jinak je posílá služba na pozadí."""
    from stats import COLLECT_URL, Stats
    import update_info
    # stejné údaje navíc jako hlášení ze služby (service.stats_tick), jinak by ruční
    # odeslání přepsalo jen základ a kvalita služby by z něj nikdy nepřišla
    taken = usage.take(STORE)
    extra = {**update_info.quality(ADDON, STORE), **usage.payload(taken)}
    try:
        extra.update(update_info.info(xbmc.executeJSONRPC, xbmcvfs.translatePath("special://database/")))
    except Exception:  # noqa: BLE001 – statistiky nesmí nic shodit
        pass
    ok, why = Stats(PROFILE).send(COLLECT_URL, version=ADDON.getAddonInfo("version"),
                                  sources=stats_sources(), product="kodi", extra=extra)
    if not ok:
        usage.restore(STORE, taken)
    notify(L(30165) if ok else f"{L(30166)}: {why}",
           xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR, 5000)


LOG_TAIL_BYTES = 500 * 1024   # celý xbmc.log bývá desítky MB, server bere jen ~500 KB


def scrub_log(raw):
    """Konec `kodi.log` bez tajemství — každý řádek projde `crash.scrub()` (tokeny, hesla,
    e-maily, IP, jména v cestách, celé adresy). Kodi samo do logu píše i adresy streamů
    s podpisem účtu a hlášky jiných doplňků s klíči API; hlášení o pádu se čistí stejně,
    ruční log do 6.1.4 odcházel syrový."""
    from crash import scrub
    text = raw.decode("utf-8", errors="replace")
    return "\n".join(scrub(line) for line in text.split("\n")).encode("utf-8")


def log_send(ask=True):
    """Ruční odeslání Kodi logu z nastavení – poslední ~500 KB `kodi.log`, gzip, bez tajemství
    (`scrub_log`).

    Instance id bere ze stejného `stats.json` jako statistiky, ať jde log
    v dashboardu spárovat s instalací. Vlastní endpoint (`/logs`, ne `/collect`)
    bere syrová gzip data v těle, ne JSON — soubor je řádově větší.
    """
    if ask and not xbmcgui.Dialog().yesno(L(30000, "Nokturno"), L(30431, "Opravdu odeslat log?")):
        return

    import gzip
    from stats import COLLECT_URL, Stats

    log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
    try:
        size = os.path.getsize(log_path)
        with open(log_path, "rb") as f:
            if size > LOG_TAIL_BYTES:
                f.seek(size - LOG_TAIL_BYTES)
            raw = f.read()
    except OSError as e:
        notify(f"{L(30430)}: {e}", xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    body = gzip.compress(scrub_log(raw))
    instalace = install_id()
    version = ADDON.getAddonInfo("version")
    logs_url = COLLECT_URL.rsplit("/", 1)[0] + "/logs"
    req = urllib.request.Request(
        f"{logs_url}?id={instalace}&version={urllib.parse.quote(version)}",
        data=body, method="POST",
        headers={"Content-Type": "application/gzip", "User-Agent": f"Kodi plugin.video.nokturno/{version}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            resp.read(1024)
        notify(L(30429), xbmcgui.NOTIFICATION_INFO, 5000)
    except Exception as e:  # noqa: BLE001 – HTTPError, URLError, timeout… vše skončí stejně
        notify(f"{L(30430)}: {e}", xbmcgui.NOTIFICATION_ERROR, 5000)


CRASH_PROP = "nokturno.crash"     # plugin → služba: ve frontě je nové hlášení o pádu, poslat hned
CRASH_LOG_TAIL = 256 * 1024          # kolik z konce kodi.log projít kvůli řádkům Nokturna


def crash_reports_on(addon=None):
    """Hlášení o pádech jen se zapnutými statistikami a nevypnutým přepínačem (výchozí zapnuto)."""
    addon = addon or ADDON
    return addon.getSetting("stats_enabled") == "true" and addon.getSetting("crash_reports") != "false"


def kodi_platform():
    return next((name for name, cond in (
        ("Android", "System.Platform.Android"), ("Linux", "System.Platform.Linux"),
        ("Windows", "System.Platform.Windows"), ("macOS", "System.Platform.OSX"),
        ("iOS", "System.Platform.IOS"), ("tvOS", "System.Platform.TVOS"),
    ) if xbmc.getCondVisibility(cond)), "?")


def addon_log_lines():
    """Poslední řádky kodi.log od Nokturna — kontext k pádu. Cizí doplňky do hlášení nepatří."""
    try:
        path = xbmcvfs.translatePath("special://logpath/kodi.log")
        size = os.path.getsize(path)
        with open(path, "rb") as f:
            if size > CRASH_LOG_TAIL:
                f.seek(size - CRASH_LOG_TAIL)
            raw = f.read().decode("utf-8", "replace")
    except (OSError, ValueError):
        return []
    return [line for line in raw.splitlines() if ADDON_ID in line]


def report_crash(action, exc):
    """Neočekávaná výjimka z routeru → fronta hlášení (`crash.py`); odešle ji služba.
    Nikdy nevyhodí výjimku a nečeká na síť — plugin už handle zavřel."""
    try:
        if not crash_reports_on():
            return
        from stats import Stats
        queued = CrashReporter(PROFILE).capture(
            exc, Stats(PROFILE).data["id"], "kodi", ADDON.getAddonInfo("version"),
            platform=kodi_platform(), kodi=xbmc.getInfoLabel("System.BuildVersionShort"),
            action=action or "", log_lines=addon_log_lines())
        if queued:
            xbmcgui.Window(10000).setProperty(CRASH_PROP, "1")
    except Exception as e:  # noqa: BLE001 – hlášení o pádu nesmí shodit úklid po pádu
        xbmc.log(f"[{ADDON_ID}] hlášení o pádu nezařazeno: {e}", xbmc.LOGWARNING)


# --- novinky ve verzi -------------------------------------------------------------

SEEN = "seen"   # seen.json v profilu: {"version": naposledy odbavená verze}


def _vkey(text):
    """Pořadí verzí jako v Kodi (`CAddonVersion`) a v `tools/build_repo.version_key`:
    část za „~“ řadí před stejnou verzi bez ní — „3.2.0~beta1“ < „3.2.0“."""
    main, _, tag = str(text or "").partition("~")
    nums = tuple(int(x) if x.isdigit() else -1 for x in re.split(r"[.\-+]", main))
    tag_key = tuple(int(p) if p.isdigit() else p for p in re.findall(r"\d+|\D+", tag))
    return nums, (0, tag_key) if tag else (1, ())


def parse_news(text, since=None):
    """Řádky „verze – text“ z <news>, od nejnovější; se `since` jen novější než ta verze.
    Beta verze (`3.2.0~beta1 – …`) se počítají taky — dřív je regex vynechal a beta
    uživatelé Novinky neviděli."""
    out = []
    for line in (text or "").splitlines():
        line = line.strip()
        m = re.match(r"^(\d+(?:\.\d+)*(?:~[a-z]+\d*)?)\s*[–-]\s*(.+)$", line)
        if not m:
            continue
        if since and _vkey(m.group(1)) <= _vkey(since):
            continue
        out.append((m.group(1), m.group(2)))
    return out


def changelog_lines(since=None):
    """Řádky <news> z addon.xml novější než `since`, od nejnovější.

    Changelog se nedrží zvlášť — <news> v addon.xml je ten, který Kodi ukazuje
    v informacích o doplňku, takže druhý seznam by se rozešel. Každý řádek
    začíná verzí, podle ní se i filtruje.
    """
    try:
        import xml.etree.ElementTree as ET
        news = ET.parse(os.path.join(ADDON_PATH, "addon.xml")).getroot().find(".//news")
        text = (news.text or "") if news is not None else ""
    except Exception:  # noqa: BLE001 – bez changelogu se nic neděje
        return []
    return parse_news(text, since)


def current_version():
    """Verze z addon.xml na disku — ze stejného souboru, ze kterého se čte changelog.

    `ADDON.getAddonInfo("version")` vrací verzi, kterou si Kodi načetlo při startu.
    Když se addon.xml změní bez restartu (ruční nahrání na box), obě čísla se
    rozejdou: „přečteno" se uložilo jako starší verze a řádek novější verze
    v changelogu pořád prošel filtrem — položka „Novinky ve verzi" po zavření
    nezmizela, dokud se Kodi nerestartovalo.
    """
    try:
        import xml.etree.ElementTree as ET
        version = ET.parse(os.path.join(ADDON_PATH, "addon.xml")).getroot().get("version")
        if version:
            return version
    except Exception:  # noqa: BLE001 – bez addon.xml aspoň to, co ví Kodi
        pass
    return ADDON.getAddonInfo("version")


def unseen_changelog():
    """Co uživatel po aktualizaci ještě neviděl. Při první instalaci nic —
    jinak by novinky vyskočily hned každému novému uživateli."""
    version = current_version()
    seen = (STORE.load(SEEN, {}) or {}).get("version")
    if not seen:
        STORE.save(SEEN, {"version": version})
        return []
    return changelog_lines(seen)


def whats_new():
    """Stručný changelog po aktualizaci. Modální okno je tu v pořádku — jde
    o reakci na kliknutí, ne o něco, co se otevře samo (to by při volání
    z widgetu nebo JSON-RPC čekalo na OK a zablokovalo i vypínání Kodi)."""
    lines = unseen_changelog() or changelog_lines()[:5]
    groups = []
    for v, text in lines:
        if groups and groups[-1][0] == v:
            groups[-1][1].append(text)
        else:
            groups.append((v, [text]))
    body = "\n\n".join(f"[B]{v}[/B]\n" + "\n".join(f"• {t}" for t in texts) for v, texts in groups) \
        or L(30193, "Žádné novinky")
    STORE.save(SEEN, {"version": current_version()})
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
    xbmcgui.Dialog().textviewer(L(30191, "Novinky"), body)
    xbmc.executebuiltin("Container.Refresh")


# --- obrazovky --------------------------------------------------------------------

# Kořen menu: pořadí a skrytí položek si volí uživatel (Discord, spacik78 2026-10-04).
# Uloženo v profilu (`menu.json`), ne v nastavení – rozvržení patří zařízení, nepřenáší se.
ROOT_ITEMS = ("search", "continue", "watchlist", "movies", "series", "concerts", "tv",
              "favourites", "syncwatch", "storage", "downloads")
ROOT_FIXED = ("search",)   # skrýt nejde, bez hledání by doplněk nešel ovládat


def root_layout():
    """(pořadí, skryté). Položka přidaná novou verzí se zařadí za svého výchozího předchůdce."""
    data = STORE.load("menu", {}) or {}
    order = list(dict.fromkeys(k for k in data.get("order") or [] if k in ROOT_ITEMS))
    for i, k in enumerate(ROOT_ITEMS):
        if k not in order:
            prev = ROOT_ITEMS[i - 1] if i else None
            order.insert(order.index(prev) + 1 if prev in order else 0, k)
    hidden = {k for k in data.get("hidden") or [] if k in ROOT_ITEMS and k not in ROOT_FIXED}
    return order, hidden


def root_save(order, hidden):
    STORE.save("menu", {"order": list(order), "hidden": sorted(hidden)})
    xbmc.executebuiltin("Container.Refresh")


def root_shown(apis):
    """Které položky mají co ukázat (bez sítě – čte profil a nastavení)."""
    return {"search": True, "movies": True, "series": True, "concerts": True, "tv": True,
            "syncwatch": True,
            "continue": bool(STORE.in_progress() or STORE.recently_watched(1)),
            "watchlist": bool(watch_lib.series(STORE) or watch_lib.wanted(STORE) or watch_lib.results(STORE)),
            # obojí, co je uvnitř: Můj seznam i Naposledy zhlédnuté
            "favourites": bool(STORE.favourites() or STORE.recently_watched(1)),
            "storage": bool(apis.get("dav")),
            "downloads": bool(setting("download_dir") or sync_targets())}


def root_label(key):
    if key == "syncwatch":
        return sw_title()
    return L(*{"search": (30150, "Hledat"), "continue": (30063, "Pokračovat ve sledování"),
               "watchlist": (30900, "Hlídané"), "movies": (30012, "Filmy"), "series": (30013, "Seriály"),
               "concerts": (30922, "Koncerty"), "tv": (30483, "TV program"),
               "favourites": (30060, "Můj seznam"), "storage": (30387, "Moje úložiště"),
               "downloads": (30391, "Stažené")}[key])


# popisy položek hlavního menu (vlevo pod ikonou); funkce kvůli překladu až za běhu
ROOT_INFO = {
    "search": lambda: L(31071, "Hledá filmy, seriály i soubory najednou ve všech tvých zdrojích."),
    "continue": lambda: L(31072, "Rozkoukané filmy a seriály. Navážeš přesně od místa, kde přehrávání skončilo."),
    "watchlist": lambda: L(31073, "Seriály a filmy, které hlídáš. Doplněk ukáže nové díly a titul, jakmile pro něj najde stream."),
    "movies": lambda: L(31074, "Filmy z katalogů, doporučení a vlastních výběrů. Po výběru titulu uvidíš streamy ze všech zdrojů."),
    "series": lambda: L(31075, "Seriály z katalogů, doporučení a vlastních výběrů. Vybereš sezónu a epizodu, doplněk najde stream."),
    "concerts": lambda: L(31076, "Koncerty z tvého úložiště. Procházej je podle interpreta, žánru nebo data přidání."),
    "tv": lambda: L(31077, "Filmy a seriály, které dnes dávají v české a slovenské televizi. Vybereš den, stanici i typ."),
    "syncwatch": lambda: L(31078, "Společné sledování: víc lidí na různých zařízeních přehrává totéž ve stejném okamžiku."),
    "favourites": lambda: L(31079, "Tvoje uložené tituly a to, co jsi naposledy přehrával."),
    "storage": lambda: L(31080, "Videa z tvého vlastního úložiště, procházej je po složkách."),
    "downloads": lambda: L(31081, "Soubory stažené do zařízení nebo do Home Assistantu."),
}


def root_context(key):
    ctx = [(L(31050, "Posunout nahoru"), runplugin(action="menu_move", key=key, step="-1")),
           (L(31051, "Posunout dolů"), runplugin(action="menu_move", key=key, step="1"))]
    if key not in ROOT_FIXED:
        ctx.append((L(31052, "Skrýt z menu"), runplugin(action="menu_hide", key=key)))
    ctx.append((L(31053, "Upravit hlavní menu"), runplugin(action="menu_edit")))
    return ctx


def root_item(key):
    ctx = root_context(key)
    info = ROOT_INFO[key]()
    if key == "search":
        folder_item(root_label(key), build_url(action="search", type="any"), icon="DefaultAddonsSearch.png",
                    context=[(L(30106), runplugin(action="clear_cache"))] + ctx, info=info)
    elif key == "watchlist":
        new = watch_lib.new_count(STORE)
        label = root_label(key)
        if new:
            label = f"{label}  [COLOR {WATCH_NEW}]· {new} {L(30908, 'nový díl')}[/COLOR]"
        # jen ikony standardní sady skinu (vlastní ikony uživatel nechce); s novým dílem
        # „nově přidané díly“, jinak seznam videí
        icon = "DefaultRecentlyAddedEpisodes.png" if new else "DefaultVideoPlaylists.png"
        folder_item(label, build_url(action="watchlist"), icon=icon, context=ctx, info=info)
    elif key == "syncwatch":
        # společné sledování; ve skupině ukazuje i kód, ať je vidět, že běží
        sw_code = sw_session().get("code")
        action_item("%s · %s" % (sw_title(), sw_code) if sw_code else sw_title(),
                    build_url(action="syncwatch"), icon="DefaultUser.png", context=ctx, info=info)
    else:
        url, icon = {"continue": (build_url(action="continue"), "DefaultInProgressShows.png"),
                     "movies": (build_url(action="browse", type="movie"), "DefaultMovies.png"),
                     "series": (build_url(action="browse", type="series"), "DefaultTVShows.png"),
                     "concerts": (build_url(action="concerts"), CONCERT_ICON),
                     "tv": (build_url(action="tv"), "DefaultAddonPVRClient.png"),
                     "favourites": (build_url(action="favourites"), "DefaultFavourites.png"),
                     "storage": (build_url(action="dav_browse"), "DefaultHardDisk.png"),
                     "downloads": (build_url(action="downloads"), "DefaultHardDisk.png")}[key]
        folder_item(root_label(key), url, icon=icon, context=ctx, info=info)


def menu_move(apis, key, step):
    """Posune položku o jedno místo mezi položkami, které jsou v menu právě vidět."""
    order, hidden = root_layout()
    shown = root_shown(apis)
    seen = [k for k in order if k not in hidden and shown[k]]
    if key not in seen:
        return
    j = seen.index(key) + step
    if not 0 <= j < len(seen):
        return
    # přesun (ne prohození), ať neviditelné položky mezi nimi zůstanou na svém místě
    order.remove(key)
    order.insert(order.index(seen[j]) + (step > 0), key)
    root_save(order, hidden)


def menu_hide(key):
    order, hidden = root_layout()
    if key in ROOT_ITEMS and key not in ROOT_FIXED:
        root_save(order, hidden | {key})
        notify(L(31054, "Skryté položky vrátíš v Nastavení → Pokročilé → Upravit hlavní menu."))


def menu_edit():
    order, hidden = root_layout()
    keys = [k for k in order if k not in ROOT_FIXED]
    sel = xbmcgui.Dialog().multiselect(L(31055, "Položky v hlavním menu"), [root_label(k) for k in keys],
                                       preselect=[i for i, k in enumerate(keys) if k not in hidden])
    if sel is not None:
        root_save(order, {k for i, k in enumerate(keys) if i not in sel})


def menu_reset():
    root_save(ROOT_ITEMS, set())
    notify(L(31056, "Hlavní menu vráceno na výchozí."))


def main_menu(apis, home=False):
    """`home` = dlaždice na domovské obrazovce skinu Estuary Nokturno: bez položky Novinky."""
    mark_used()
    if not any(apis.values()):
        # bez modálního dialogu: ten by při volání z widgetu/JSON-RPC čekal na OK a zablokoval i vypínání Kodi
        notify(L(30104), xbmcgui.NOTIFICATION_WARNING, 6000)
        # bez zdroje je průvodce jediné, co dává smysl — dřív tu byla jen položka Nastavení
        # a kdo průvodce jednou přeskočil, neměl jak zjistit, že existuje
        action_item(L(30359, "Průvodce nastavením"), build_url(action="setup_wizard"),
                    icon="DefaultAddonProgram.png",
                    info=L(31082, "Krok za krokem nastaví zdroje a účty, ať můžeš hned sledovat."))
        action_item(L(30107), build_url(action="settings"), icon="DefaultAddonProgram.png")
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    # Stav zdrojů úplně nahoře, ale jen když je co hlásit — jinak by tu u všech
    # bez problému jen zabíral místo. Čte se z uloženého záznamu (obnovu dělá
    # služba na pozadí), takže menu nezdrží. Souhrn je dlouhý, proto jde i do
    # popisku položky, kde ho skin ukáže celý.
    engine = engine_of(apis)
    rows = engine.accounts()
    request_accounts_retry(engine, rows)
    souhrn = account_summary(rows)
    if souhrn:
        # bez prefixu „Stav zdrojů: “ (13 znaků) — Arctic Fuse má na řádek zhruba
        # čtyřicet znaků a delší text si roluje pod rukama, takže z věty je vidět
        # vždycky jen výsek; popis složky ten skin nekreslí vůbec, takže záloha
        # neexistuje. Význam „něco je špatně“ nese ikona. Stejná bitva jako v 6.3.7.
        li = xbmcgui.ListItem(label=souhrn)
        li.setArt({"icon": "DefaultIconWarning.png"})
        tag = li.getVideoInfoTag()
        # v popisu všechno a na vlastních řádcích — do štítku se vejdou jen dva zdroje
        tag.setPlot("\n".join(account_line(r) for r in accounts_problems(rows)))
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="accounts"), li, isFolder=True)
    # čistá instalace: průvodce nahoře jako položka. Spouštět ho z kořene sám od sebe
    # nejde — modální dialog v cestě, kterou otevírají widgety a JSON-RPC, blokuje
    # i vypínání Kodi (viz pravidlo v CLAUDE.md)
    if not accounts_set():   # i po přeskočení: bez účtu nemá doplněk co ukázat
        action_item(L(30359, "Průvodce nastavením"), build_url(action="setup_wizard"),
                    icon="DefaultAddonProgram.png",
                    info=L(31082, "Krok za krokem nastaví zdroje a účty, ať můžeš hned sledovat."))
    fresh = None if home else unseen_changelog()
    if fresh:
        action_item(f"{L(30192, 'Novinky ve verzi')} {fresh[0][0]}",
                    build_url(action="whats_new"), icon="DefaultAddonRepository.png")
    # vlastní ikony místo jedné a té samé ikony doplňku u každé položky — jména
    # standardní sady Kodi (dodává je aktivní skin, žádný soubor navíc v doplňku)
    # Jedno hledání, jedny Filmy a jedny Seriály — dřív tu byly Filmy/Seriály zvlášť za
    # každý zdroj katalogu (Luna, Sosáč, databáze), každé s vlastními podkategoriemi.
    # Který zdroj stojí za kterým seznamem, rozhoduje až `browse_menu`.
    # Pořadí a skrytí položek si volí uživatel (místní nabídka, Nastavení → Pokročilé),
    # položky bez obsahu (Pokračovat, Hlídané…) se dál schovávají samy
    order, hidden = root_layout()
    shown = root_shown(apis)
    mylist_menu_item(MYLIST_POS_TOP)
    for key in order:
        if key not in hidden and shown[key]:
            root_item(key)
        # kotvy pro vlastní seznamy a katalogy z dashboardu platí i u skryté položky
        if key == "watchlist":
            mylist_menu_item(MYLIST_POS_WATCH)
        elif key == "series":
            # sezónní a tematické katalogy zapnuté na dashboardu (bez vydání nové verze)
            dash_catalog_items(apis, "root")
            mylist_menu_item()
    mylist_menu_item(MYLIST_POS_BOTTOM)
    action_item(L(30392, "Nastavení"), build_url(action="settings"), icon="DefaultAddonProgram.png",
                info=L(31083, "Zdroje, účty, přehrávání, synchronizace a vzhled doplňku."))
    # bez cache na disk — položky se mění podle stavu (Novinky, Pokračovat), zpět do
    # menu z podsložky by jinak Kodi ukázalo starý výpis i s už přečtenými Novinkami
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def browse_menu(apis, ctype):
    """Filmy / Seriály: katalogy z dashboardu, Pro Tebe, Nejsledovanější tento týden, Vlastní katalogy
    a Náhodný film/seriál. Vlastní katalogy (i ze šablon na mobilu) jsou jen pod „Vlastní katalogy“.
    „Nejsledovanější tento týden“ (dashboard) je přímý `action="catalog"`."""
    kind = "series" if ctype == "series" else "movie"
    # sezónní a tematické katalogy z dashboardu nahoře, pořadí mezi nimi řídí `position`
    dash_catalog_items(apis, "browse", kind)

    # „Pro tebe" jen když je z čeho doporučovat — prázdný seznam by jen mátl. Seznam
    # vzorů se čte z profilu (`watched`), žádná síť, takže kreslení menu to nezdrží.
    if foryou_seeds(apis, ctype, limit=1):
        folder_item(L(30605, "Pro Tebe"), build_url(action="foryou", type=ctype),
                    icon="DefaultAddonsRecentlyUpdated.png",
                    info=L(31084, "Tipy podle toho, co jsi už zhlédl."))
    folder_item(L(30393, "Nejsledovanější tento týden"),
                build_url(action="catalog", type=ctype, catalog=TREND_CATALOG_ID, src="trend"),
                icon="DefaultFavourites.png",
                info=L(31085, "Co tento týden sledují ostatní uživatelé Nokturna."))
    for cat in mycats(kind):
        if cat.get("menu"):   # katalog, který si uživatel dal do hlavního menu
            mycat_folder(cat, ctype)
    folder_item(L(30944, "Vlastní katalogy"), build_url(action="mycats", type=ctype),
                icon="DefaultVideoPlaylists.png",
                info=L(31086, "Vlastní výběry titulů podle žánru, roku nebo hodnocení, které si skládáš sám."))
    # „Náhodný film/seriál" je ne-složka: klik ji Kodi spustí jako skript s handle −1
    # a `random_title()` rovnou otevře dialog výběru streamu — ve výpisu se tedy žádný
    # modál neotevře a widget ani JSON-RPC se sem nedostanou (vzor `tv_pick`).
    nahodny = xbmcgui.ListItem(label=L(30609, "Náhodný seriál") if ctype == "series"
                               else L(30608, "Náhodný film"))
    nahodny.setArt({"icon": "DefaultAddonsUpdates.png"})
    nahodny.getVideoInfoTag().setPlot(L(31087, "Vybere náhodný titul a rovnou nabídne přehrání."))
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action="random", type=ctype), nahodny, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


# u „Trendy" nejsou v roli žánru žánry, ale časové okno TMDB — hodnota musí zůstat anglicky
GENRE_LABELS = {"Day": L(30403, "Za den"), "Week": L(30404, "Za týden")}
# žánry česky jen pro češtinu a slovenštinu — anglické Kodi dřív dostávalo české názvy natvrdo
GENRES_LOCAL = xbmc.getLanguage(xbmc.ISO_639_1) in ("cs", "sk")


def genre_label(g):
    return GENRES_CS.get(str(g), str(g)) if GENRES_LOCAL else str(g)


def list_genres(apis, ctype, cid, src, show_all=True):
    api = apis[src]
    cat = next((c for c in api.catalogs(ctype) if c["id"] == cid), None) if api else None
    if not cat:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    if show_all and not cat["genre_required"]:
        folder_item(L(30020), build_url(action="catalog", type=ctype, catalog=cid, src=src),
                   icon="DefaultVideoPlaylists.png", info=L(31101, "Všechny tituly katalogu bez filtru podle žánru."))
    for g in cat["genres"]:
        folder_item(GENRE_LABELS.get(g, genre_label(g)),
                    build_url(action="catalog", type=ctype, catalog=cid, genre=g, src=src),
                    icon="DefaultGenre.png")
    xbmcplugin.endOfDirectory(HANDLE)


def list_catalog(apis, ctype, cid, src, genre=None, search=None, skip=0):
    api = apis[src]
    if api is None:
        raise LunaError(L(30104))
    set_content("tvshows" if ctype == "series" else "movies")
    metas = api.catalog(ctype, cid, genre=genre, search=search, skip=skip)
    if src in ("sosac", "sosac_db", "cinemeta"):
        # exporty Sosáče a holé výpisy Cinemety nemají popis → dotáhnout podle IMDb id
        # (Luna, jinak Cinemeta sama — viz `_fetch()` v enrich.py — cache)
        enrich(metas, apis["luna"], STORE, ctype, tmdb=get_tmdb())
    rate(metas, ctype)
    for m in metas:
        add_meta_item(m, ctype)
    # Luna vrací stránky po ~20, ale některé katalogy o pár položek méně; žebříček a katalogy
    # z dashboardu přijdou celé najednou, „Další“ by vedlo do prázdné složky
    if len(metas) >= PAGE // 2 and src not in ("trend", "dash"):
        next_page_item(build_url(action="catalog", type=ctype, catalog=cid, src=src, genre=genre,
                                        search=search, skip=skip + len(metas)))
    # widget a výpis v Nokturnu mívají stejnou adresu, položky se ale liší podle okna (add_playable)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False, updateListing=UPDATE_LISTING)


# --- vlastní katalogy ------------------------------------------------------------
# Uživatel si katalog poskládá z žánrů, původního jazyka, let a řazení; tituly skládá
# dashboard (`GET /discover`) přes TMDB svým klíčem, takže vlastní klíč TMDB netřeba.
# Uložené jsou jen volby formuláře (`mycatalogs.json`), dotaz se z nich staví až při výpisu.

MYCAT_GENRES = {   # id žánrů TMDB → anglický název (česky přes `genre_label`)
    "movie": ((28, "Action"), (12, "Adventure"), (16, "Animation"), (35, "Comedy"), (80, "Crime"),
              (99, "Documentary"), (18, "Drama"), (10751, "Family"), (14, "Fantasy"), (36, "History"),
              (27, "Horror"), (10402, "Music"), (9648, "Mystery"), (10749, "Romance"), (878, "Sci-Fi"),
              (53, "Thriller"), (10752, "War"), (37, "Western")),
    "series": ((10759, "Action & Adventure"), (16, "Animation"), (35, "Comedy"), (80, "Crime"),
               (99, "Documentary"), (18, "Drama"), (10751, "Family"), (10762, "Kids"), (9648, "Mystery"),
               (10764, "Reality"), (10765, "Sci-Fi & Fantasy"), (10768, "War & Politics"), (37, "Western")),
}
# Klíčová slova TMDB, která TMDB jako žánr nemá (pohádka je u něj jen klíčové slovo).
# Ve formuláři jsou pod žánry; ukládá se klíč, ne id, ať jde seznam id později doplnit.
# témata (klíčová slova TMDB, `mycat.KEYWORDS`) – samostatné pole pod žánry; stačí jedno z vybraných
MYCAT_KEYWORD_LABELS = {
    "fairy": (30976, "Pohádky"),
    "christmas": (31002, "Vánoce"),
    "halloween": (31003, "Halloween"),
    "newyear": (31004, "Silvestr"),
    "truestory": (31005, "Podle skutečné události"),
    "book": (31006, "Podle knihy"),
    "biography": (31007, "Životopisný"),
    "superhero": (31008, "Superhrdinové"),
    "serialkiller": (31009, "Sériový vrah"),
    "ww2": (31010, "2. světová válka"),
    "martialarts": (31011, "Bojová umění"),
    "sport": (31012, "Sport"),
    "alien": (31013, "Mimozemšťané"),
    "timetravel": (31014, "Cestování časem"),
    "zombie": (31015, "Zombie"),
    "ghost": (31016, "Duchové"),
    "vampire": (31017, "Upíři"),
    "postapo": (31018, "Postapokalypsa"),
    "heist": (31019, "Loupež"),
    "spy": (31020, "Špionáž"),
    "survival": (31021, "Přežití"),
    "dog": (31022, "Psi"),
    "dinosaur": (31023, "Dinosauři"),
}
MYCAT_KEYWORDS = tuple((key, ids) + MYCAT_KEYWORD_LABELS[key] for key, ids in mycat.KEYWORDS.items())
MYCAT_SORTS = (("popularity.desc", 30954, "Oblíbenosti – co se teď na TMDB nejvíc sleduje"),
               ("vote_average.desc", 30955, "Hodnocení na TMDB – jen tituly s dost hlasy (obvykle aspoň 100)"),
               ("primary_release_date.desc", 30956, "Data vydání – nejnovější první"),
               ("primary_release_date.asc", 31063, "Data vydání – nejstarší první"),
               (mycat.ALPHA, 30288, "Abecedy – oblíbené tituly podle názvu"))
MYCAT_QUALITY_LABELS = ((0, 30885, "Libovolná"), (3, 0, "Full HD"), (3.5, 0, "2K"), (4, 0, "4K"))   # 0 = bez překladu
MYCAT_TRACK_LABELS = (("", 30762, "Libovolné"), ("CZ", 30112, "Čeština"), ("SK", 30113, "Slovenština"),
                      ("CZ|SK", 30763, "Čeština nebo slovenština"), ("EN", 30114, "Angličtina"),
                      ("HU", 30559, "Maďarština"))
MYCAT_SHOW_LABELS = (("found", 30765, "Nově nalezené"), ("pool", 30764, "Stejně jako výběr"),
                     ("released", 30766, "Nejnovější vydání"))
# vysvětlení řazení u výběru (dialog na TV, nápověda ve formuláři v prohlížeči)
MYCAT_SHOW_HELP = {"pool": (31113, "Tituly v pořadí, v jakém je vrátil výběr katalogu."),
                   "found": (31114, "Nejnovější nálezy nahoře – podle toho, kdy titul našla kontrola dostupnosti."),
                   "released": (31115, "Nejnovější vydání nahoře – podle data vydání titulu.")}
# země původu (`mycat.COUNTRIES`, filtr TMDB `with_origin_country`) – jiná věc než jazyk dabingu
MYCAT_COUNTRIES = (("CZ", 30262, "Česko"), ("SK", 30263, "Slovensko"), ("XC", 31048, "Československo"),
                   ("US", 30264, "USA"),
                   ("GB", 30265, "Velká Británie"), ("FR", 30266, "Francie"), ("DE", 30267, "Německo"),
                   ("IT", 30268, "Itálie"), ("ES", 30269, "Španělsko"), ("PL", 30270, "Polsko"),
                   ("HU", 30271, "Maďarsko"), ("KR", 30272, "Jižní Korea"), ("JP", 30273, "Japonsko"),
                   ("DK", 30274, "Dánsko"), ("SE", 30275, "Švédsko"), ("NO", 30276, "Norsko"))
# ikony katalogu: jen standardní sada skinu (`mycat.ICONS`, stejné pořadí), nikdy vlastní PNG
MYCAT_ICONS = (("DefaultMovies.png", 30012, "Filmy"), ("DefaultTVShows.png", 30013, "Seriály"),
               ("DefaultVideoPlaylists.png", 30249, "Seznam"), ("DefaultFavourites.png", 30206, "Hvězda"),
               ("DefaultMusicTop100.png", 30250, "Žebříček"), ("DefaultGenre.png", 30251, "Žánr"),
               ("DefaultYear.png", 30252, "Rok"), ("DefaultCountry.png", 30253, "Země"),
               ("DefaultSets.png", 30254, "Sbírka"), ("DefaultRecentlyAddedMovies.png", 30217, "Novinky"),
               ("DefaultActor.png", 30218, "Herci"), ("DefaultStudios.png", 30255, "Studia"))
# názvy šablon (`mycat.TEMPLATES`) v jazyce Kodi
MYCAT_TEMPLATE_NAMES = {"movie-popular": 30277, "series-popular": 30278, "movie-top": 30279, "series-top": 30280,
                        "movie-new-cz-dub": 30281, "series-new-cz-dub": 30282, "movie-4k-cz-dub": 30283,
                        "movie-czech": 30284, "series-czech": 30285, "movie-fairy-cz-dub": 30286}
MYCAT_MODE_TEXTS = (
    (30242, "Katalog z TMDB", 30200, "Ukáže hned všechny tituly podle filtrů. U titulu bez streamu si můžeš zapnout "
                                     "hlídání – Hlídané dají vědět, až stream bude."),
    (30243, "Jen tituly se streamem", 30202, "Na pozadí se u každého titulu hledá stream podle tvých požadavků "
                                             "(dabing, titulky, kvalita, 5.1). Katalog se plní postupně a ukáže "
                                             "jen to, co jde přehrát."))


def mycats(ctype=None):
    return mycat.catalogs(STORE, ctype)


mycat_params = mycat.params   # parametry `DashApi.discover`; sestavení je v jádru (`mycat.py`), sdílí ho HA a Stremio


def mycat_template_name(t):
    return L(MYCAT_TEMPLATE_NAMES.get(t["key"], 0), t["name"]) if t["key"] in MYCAT_TEMPLATE_NAMES else t["name"]


def mycat_labels(kind):
    """Popisky pro `mycat.auto_name` v jazyce Kodi."""
    kind = "series" if kind == "series" else "movie"
    return {"genres": {str(g): genre_label(n) for g, n in MYCAT_GENRES[kind]},
            "keywords": {key: L(sid, fb) for key, _, sid, fb in MYCAT_KEYWORDS},
            "countries": {code: L(sid, fb) for code, sid, fb in MYCAT_COUNTRIES},
            "dub": L(30291, "{} dabing"), "subs": L(30292, "titulky {}"), "surround": L(30293, "5.1"),
            "years": L(30294, "posledních {} let"), "year_from": L(30295, "od {}"), "year_to": L(30296, "do {}"),
            "year_range": L(30297, "{}–{}"), "without": L(31119, "bez {}")}


def mycat_auto_name(cat):
    return mycat.auto_name(cat, mycat_labels(cat.get("kind")), L(30972, "Vlastní katalog"))


def mycat_record(cid, kind, fields, name=None, name_auto=True):
    """Pole formuláře (TV i mobil) → uložitelný záznam. `name` None = název z parametrů (`auto_name`)."""
    kind = "series" if kind == "series" else "movie"
    genres_ok = {g for g, _ in MYCAT_GENRES[kind]}
    rec = {"id": cid, "kind": kind,
           "genres": [g for g in fields.get("genres") or [] if g in genres_ok],
           "keywords": [k for k in fields.get("keywords") or [] if k in mycat.KEYWORDS],
           "join": "or" if fields.get("join") == "or" else "and",
           "countries": mycat.countries_of(fields),
           "countries_exclude": mycat.countries_exclude_of(dict(fields, countries=mycat.countries_of(fields))),
           "year_from": fields.get("year_from"), "year_to": fields.get("year_to"), "years": fields.get("years"),
           "sort": fields.get("sort") if fields.get("sort") in [s for s, _, _ in MYCAT_SORTS] else "popularity.desc",
           "verify": bool(fields.get("verify")),
           "icon": fields.get("icon") if fields.get("icon") in mycat.ICONS else mycat.DEFAULT_ICONS[kind]}
    verify = rec["verify"]
    rec.update({"q": mycat.norm_quality(fields.get("q")) if verify else 0,
                "audio": (fields.get("audio") or "") if verify and fields.get("audio") in mycat.TRACKS else "",
                "subs": (fields.get("subs") or "") if verify and fields.get("subs") in mycat.TRACKS else "",
                "surround": bool(fields.get("surround")) if verify else False,
                "show": fields.get("show") if fields.get("show") in mycat.SHOWS else "found"})
    auto = mycat_auto_name(rec)
    rec["name"] = (name or "").strip()[:60] or auto
    rec["name_auto"] = bool(name_auto) or rec["name"] == auto
    return rec


def _mycat_year(heading, current):
    value = xbmcgui.Dialog().numeric(0, heading, str(current or ""))
    return int(value) if value and value.isdigit() and 1900 <= int(value) <= 2099 else None


def _mycat_pick(heading, labels, current, values):
    """Výběr z `labels` (dvojice text/id řetězce), vrací hodnotu z `values`, nebo None při zrušení."""
    idx = xbmcgui.Dialog().select(heading, labels, preselect=values.index(current) if current in values else 0)
    return None if idx < 0 else values[idx]


def mycat_verify_full(cid):
    """Je už ověřovaných katalogů `mycat.MAX_VERIFIED` (bez katalogu `cid`)?"""
    return sum(1 for c in mycats() if c.get("verify") and c.get("id") != cid) >= mycat.MAX_VERIFIED


def mycat_form(ctype, cat=None):
    """Dialogy formuláře na TV (režim, žánry, země, roky, řazení, požadavky na stream, ikona, název) → uložitelný
    záznam, nebo None po zrušení. Běží jen z ne-složky (handle −1), z widgetu ani z JSON-RPC se sem nejde."""
    cat = cat or {}
    kind = "series" if ctype == "series" else "movie"
    dlg = xbmcgui.Dialog()
    cid = cat.get("id") or f"k{int(time.time() * 1000):x}"
    modes = []
    for sid, fb, hid, hfb in MYCAT_MODE_TEXTS:
        li = xbmcgui.ListItem(label=L(sid, fb), label2=L(hid, hfb))
        modes.append(li)
    mode = dlg.select(L(30241, "Režim katalogu"), modes, preselect=1 if cat.get("verify") else 0, useDetails=True)
    if mode < 0:
        return None
    verify = mode == 1
    if verify and mycat_verify_full(cid):
        notify(L(30780, "Ověřovat jde nejvýš 20 katalogů."), xbmcgui.NOTIFICATION_WARNING)
        verify = False
    genres = MYCAT_GENRES[kind]
    chosen = dlg.multiselect(L(30948, "Žánry (nic = všechny)"), [genre_label(n) for _, n in genres],
                             preselect=[i for i, (g, _) in enumerate(genres) if g in (cat.get("genres") or [])])
    if chosen is None:
        return None
    picked = [genres[i][0] for i in chosen]
    kw_keys = [key for key, _, _, _ in MYCAT_KEYWORDS]
    chosen = dlg.multiselect(L(31024, "Témata (stačí jedno, nejvýš 3)"), [L(sid, fb) for _, _, sid, fb in MYCAT_KEYWORDS],
                             preselect=[i for i, k in enumerate(kw_keys) if k in (cat.get("keywords") or [])])
    if chosen is None:
        return None
    if len(chosen) > mycat.MAX_KEYWORDS:
        notify(L(31024, "Témata (stačí jedno, nejvýš 3)"), xbmcgui.NOTIFICATION_WARNING)
    keywords = [kw_keys[i] for i in chosen][:mycat.MAX_KEYWORDS]
    join = cat.get("join") or "and"
    if len(picked) > 1:
        idx = dlg.select(L(30973, "Tituly musí mít"),
                         [L(30974, "všechny vybrané žánry"), L(30975, "aspoň jeden vybraný žánr")],
                         preselect=1 if join == "or" else 0)
        if idx < 0:
            return None
        join = "or" if idx == 1 else "and"
    codes = [code for code, _, _ in MYCAT_COUNTRIES]
    have = mycat.migrate_lang(cat)   # starý katalog s „původním jazykem“ dostane jeho země
    chosen = dlg.multiselect(L(30244, "Země původu (nejvýš 5)"), [L(sid, fb) for _, sid, fb in MYCAT_COUNTRIES],
                             preselect=[i for i, c in enumerate(codes) if c in have])
    if chosen is None:
        return None
    if len(chosen) > mycat.MAX_COUNTRIES:
        notify(L(30244, "Země původu (nejvýš 5)"), xbmcgui.NOTIFICATION_WARNING)
    countries = [codes[i] for i in chosen][:mycat.MAX_COUNTRIES]
    exclude = []
    if not countries:   # vybrané země mají přednost, vyloučení se pak neptá
        chosen = dlg.multiselect(L(31118, "Vyloučit země (nic = žádné)"), [L(sid, fb) for _, sid, fb in MYCAT_COUNTRIES],
                                 preselect=[i for i, c in enumerate(codes) if c in (cat.get("countries_exclude") or [])])
        if chosen is None:
            return None
        exclude = [codes[i] for i in chosen]
    years = year_from = year_to = None
    mode = dlg.select(L(30767, "Roky"), [L(30768, "Bez omezení"), L(30769, "Od–do"), L(30770, "Posledních X let")],
                      preselect=2 if cat.get("years") else 1 if cat.get("year_from") or cat.get("year_to") else 0)
    if mode < 0:
        return None
    if mode == 1:
        year_from = _mycat_year(L(30951, "Od roku (prázdné = bez omezení)"), cat.get("year_from"))
        year_to = _mycat_year(L(30952, "Do roku (prázdné = bez omezení)"), cat.get("year_to"))
    elif mode == 2:
        value = dlg.numeric(0, L(30771, "Kolik posledních let"), str(cat.get("years") or 5))
        if not (value and value.isdigit() and 1 <= int(value) <= 50):
            return None
        years = int(value)
    sorts = [code for code, _, _ in MYCAT_SORTS]
    sort = _mycat_pick(L(30953, "Řadit podle"), [L(sid, fb) for _, sid, fb in MYCAT_SORTS], cat.get("sort"), sorts)
    if sort is None:
        return None
    fields = {"genres": picked, "keywords": keywords, "join": join, "countries": countries,
              "countries_exclude": exclude, "years": years,
              "year_from": year_from, "year_to": year_to, "sort": sort, "verify": verify}
    if verify:
        tracks = [v for v, _, _ in MYCAT_TRACK_LABELS]
        track_labels = [L(sid, fb) for _, sid, fb in MYCAT_TRACK_LABELS]
        audio = _mycat_pick(L(30287, "Jazyk zvuku"), track_labels, cat.get("audio") or "", tracks)
        subs = None if audio is None else _mycat_pick(L(30884, "Titulky"), track_labels, cat.get("subs") or "", tracks)
        qs = [v for v, _, _ in MYCAT_QUALITY_LABELS]
        q = None if subs is None else _mycat_pick(
            L(30994, "Minimální kvalita"), [L(sid, fb) if sid else fb for _, sid, fb in MYCAT_QUALITY_LABELS],
            mycat.norm_quality(cat.get("q")), qs)
        surround = None if q is None else _mycat_pick(
            L(30883, "Kanály zvuku"), [L(30886, "Libovolné"), L(30888, "5.1 a víc")], bool(cat.get("surround")),
            [False, True])
        shows = [v for v, _, _ in MYCAT_SHOW_LABELS]
        show = None
        if surround is not None:
            current = cat.get("show") or "found"
            items = [xbmcgui.ListItem(label=L(sid, fb), label2=L(*MYCAT_SHOW_HELP[v])) for v, sid, fb in MYCAT_SHOW_LABELS]
            idx = dlg.select(L(30774, "Zobrazit seřazené podle"), items,
                             preselect=shows.index(current) if current in shows else 0, useDetails=True)
            show = None if idx < 0 else shows[idx]
        if show is None:
            return None
        fields.update(audio=audio, subs=subs, q=q, surround=surround, show=show)
    icons = [icon for icon, _, _ in MYCAT_ICONS]
    icon = _mycat_pick(L(30245, "Ikona katalogu"), [L(sid, fb) for _, sid, fb in MYCAT_ICONS],
                       mycat.icon_for(dict(cat, kind=kind)), icons)
    if icon is None:
        return None
    fields["icon"] = icon
    rec = mycat_record(cid, kind, fields)
    # název, který uživatel dřív sám přepsal, zůstává; jinak se přepočítá z nových parametrů
    default_name = cat.get("name") if cat.get("name") and not cat.get("name_auto", True) else rec["name"]
    name = dlg.input(L(30957, "Název katalogu"), default_name).strip()[:60] or default_name
    return mycat_record(cid, kind, fields, name=name, name_auto=name == rec["name"])


def mycat_first_batch(cat, ask=True):
    """Po uložení ověřovaného katalogu nabídne hned první větší dávku (služba ji udělá na pozadí)."""
    if not cat.get("verify"):
        return
    if not ask or xbmcgui.Dialog().yesno(
            L(30737, "Spustit ověření streamů nyní?"),
            L(30739, "První dávka prověří víc titulů najednou, ať je v katalogu hned co ukázat. Běží na pozadí.")):
        xbmcgui.Window(10000).setProperty(VERIFY_MANUAL_PROP, "%s:%s" % (cat["id"], FIRST_BATCH_SIZE))


def mycat_new(ctype):
    """Nový katalog: na televizi (dialogy), nebo na mobilu (QR)."""
    idx = xbmcgui.Dialog().select(L(30945, "Nový katalog"), [L(30204, "Nastavit přes mobil (doporučujeme)"),
                                                              L(30203, "Pokračovat v nastavení v Kodi")])
    if idx == 0:
        mycat_remote(None, ctype)
        return
    if idx < 0:
        return
    cat = mycat_form(ctype)
    if not cat:
        return
    mycat.save(STORE, cat)
    usage.mark_feature(STORE, "mycatalog")
    xbmc.executebuiltin("Container.Refresh")
    mycat_first_batch(cat)


def mycat_edit(cat_id):
    cat = next((c for c in mycats() if c.get("id") == cat_id), None)
    new = mycat_form(cat.get("kind"), cat) if cat else None
    if not new:
        return
    mycat.save(STORE, new)
    xbmc.executebuiltin("Container.Refresh")
    mycat_first_batch(new)


def mycat_delete(cat_id):
    cat = next((c for c in mycats() if c.get("id") == cat_id), None)
    if not cat or not xbmcgui.Dialog().yesno(L(30947, "Smazat katalog"),
                                             L(30958, "Smazat katalog %s?") % cat.get("name", "")):
        return
    mycat.delete(STORE, cat_id)
    xbmc.executebuiltin("Container.Refresh")


def mycat_menu(cat_id, on):
    """Zobrazí katalog přímo v menu Filmy/Seriály, nebo ho odtamtud odebere."""
    cat = next((c for c in mycats() if c.get("id") == cat_id), None)
    if cat:
        mycat.save(STORE, dict(cat, menu=on))
        xbmc.executebuiltin("Container.Refresh")


def mycat_batch(cat_id):
    """Ruční „Načíst teď“ ověřovaného katalogu nebo koncertů: úkol dostane služba."""
    xbmcgui.Window(10000).setProperty(VERIFY_MANUAL_PROP, "%s:%s" % (cat_id, MANUAL_BATCH_SIZE))


# --- editor katalogu z mobilu -------------------------------------------------------

MYCAT_FORM_INPUTS = ("kind", "verify", "genres_movie", "genres_series", "keywords", "join", "countries",
                     "countries_exclude", "years_mode", "year_from", "year_to", "years", "audio", "subs", "q", "surround")


def _mycat_form_values(cat, kind):
    """Záznam katalogu → hodnoty formuláře z mobilu (řetězce)."""
    def num(v):
        return str(v) if v else ""
    genres = "|".join(str(g) for g in cat.get("genres") or [])
    years_mode = "last" if cat.get("years") else "range" if cat.get("year_from") or cat.get("year_to") else "none"
    return {"kind": kind, "verify": "1" if cat.get("verify") else "0",
            "genres_movie": genres if kind == "movie" else "", "genres_series": genres if kind == "series" else "",
            "join": cat.get("join") or "and", "keywords": "|".join(cat.get("keywords") or []),
            "countries": "|".join(mycat.migrate_lang(cat)),
            "countries_exclude": "|".join(cat.get("countries_exclude") or []), "years_mode": years_mode,
            "year_from": num(cat.get("year_from")), "year_to": num(cat.get("year_to")), "years": num(cat.get("years")),
            "sort": cat.get("sort") or "popularity.desc", "audio": cat.get("audio") or "", "subs": cat.get("subs") or "",
            "q": str(mycat.norm_quality(cat.get("q"))), "surround": "true" if cat.get("surround") else "false",
            "show": cat.get("show") or "found", "icon": mycat.icon_for(dict(cat, kind=kind))}


def _mycat_fields_from_form(values):
    """Hodnoty z mobilu → (druh, pole pro `mycat_record`). Neplatné roky se zahodí (= bez omezení)."""
    kind = "series" if values.get("kind") == "series" else "movie"

    def year(key, lo=1900, hi=2099):
        v = str(values.get(key) or "").strip()
        return int(v) if v.isdigit() and lo <= int(v) <= hi else None

    def multi(key):
        return [v for v in str(values.get(key) or "").split("|") if v]
    mode = values.get("years_mode")
    genres = [int(g) for g in multi("genres_" + kind) if g.isdigit()]
    # starší stránka z mobilu posílala témata mezi žánry
    keywords = [k for k in multi("genres_" + kind) + multi("keywords") if k in mycat.KEYWORDS][:mycat.MAX_KEYWORDS]
    q = values.get("q")
    return kind, {"genres": genres, "keywords": list(dict.fromkeys(keywords)), "join": values.get("join"),
                  "countries": multi("countries"), "countries_exclude": multi("countries_exclude"),
                  "verify": values.get("verify") == "1",
                  "years": year("years", 1, 50) if mode == "last" else None,
                  "year_from": year("year_from") if mode == "range" else None,
                  "year_to": year("year_to") if mode == "range" else None,
                  "sort": values.get("sort"), "audio": values.get("audio") or "", "subs": values.get("subs") or "",
                  "q": float(q) if q in ("3", "3.5", "4") else 0, "surround": values.get("surround") == "true",
                  "show": values.get("show"), "icon": values.get("icon")}


def mycat_remote_schema(kind, new, name_auto=True):
    """Jedna sekce formuláře z mobilu pro vlastní katalog (`lib/remote_setup.py`)."""
    tracks = [(v, L(sid, fb)) for v, sid, fb in MYCAT_TRACK_LABELS]
    stream = ("verify", "1")
    fields = [{"id": "template", "type": "choice", "label": L(30246, "Šablona"),
               # šablonu katalog neukládá, pole jen vybírá, co do formuláře načíst – u úpravy „Bez šablony“
               # vypadalo jako ztracená šablona (Discord 2026-10-10)
               "options": [("", L(30248, "Bez šablony") if new else L(31068, "Ponechat současné nastavení"))]
                          + [(t["key"], mycat_template_name(t))
                                                           for t in mycat.templates(None if new else kind)]},
              {"type": "action", "action": "template", "label": L(30247, "Načíst šablonu"), "inputs": ["template"]}]
    if new:
        fields.append({"id": "kind", "type": "choice", "label": L(30228, "Druh katalogu"),
                       "options": [("movie", L(30012, "Filmy")), ("series", L(30013, "Seriály"))]})
    fields += [
        {"id": "name", "type": "text", "label": L(30957, "Název katalogu"),
         "auto": {"action": "autoname", "inputs": list(MYCAT_FORM_INPUTS), "off": not name_auto}},
        {"id": "icon", "type": "choice", "label": L(30245, "Ikona katalogu"),
         "options": [(icon, L(sid, fb)) for icon, sid, fb in MYCAT_ICONS]},
        {"type": "info", "label": L(30241, "Režim katalogu"),
         "help": "\n".join("%s: %s" % (L(sid, fb), L(hid, hfb)) for sid, fb, hid, hfb in MYCAT_MODE_TEXTS)},
        {"id": "verify", "type": "choice", "label": L(30241, "Režim katalogu"),
         "options": [("0", L(30242, "Katalog z TMDB")), ("1", L(30243, "Jen tituly se streamem"))]}]
    for k in ("movie", "series"):
        if new or k == kind:
            field = {"id": "genres_" + k, "type": "multi", "label": L(30948, "Žánry (nic = všechny)"),
                     "options": [(str(g), genre_label(n)) for g, n in MYCAT_GENRES[k]]}
            if new:
                field["enable"] = ("kind", k)
            fields.append(field)
    fields.append({"id": "keywords", "type": "multi", "label": L(31024, "Témata (stačí jedno, nejvýš 3)"),
                   "options": [(key, L(sid, fb)) for key, _, sid, fb in MYCAT_KEYWORDS]})
    fields += [
        {"id": "join", "type": "choice", "label": L(30973, "Tituly musí mít"),
         "options": [("and", L(30974, "všechny vybrané žánry")), ("or", L(30975, "aspoň jeden vybraný žánr"))]},
        {"id": "countries", "type": "multi", "label": L(30244, "Země původu (nejvýš 5)"), "max": mycat.MAX_COUNTRIES,
         "options": [(code, L(sid, fb)) for code, sid, fb in MYCAT_COUNTRIES]},
        {"id": "countries_exclude", "type": "multi", "label": L(31118, "Vyloučit země (nic = žádné)"),
         "options": [(code, L(sid, fb)) for code, sid, fb in MYCAT_COUNTRIES]},
        {"id": "years_mode", "type": "choice", "label": L(30767, "Roky"),
         "options": [("none", L(30768, "Bez omezení")), ("range", L(30769, "Od–do")),
                     ("last", L(30770, "Posledních X let"))]},
        {"id": "year_from", "type": "text", "label": L(30951, "Od roku (prázdné = bez omezení)"),
         "enable": ("years_mode", "range")},
        {"id": "year_to", "type": "text", "label": L(30952, "Do roku (prázdné = bez omezení)"),
         "enable": ("years_mode", "range")},
        {"id": "years", "type": "text", "label": L(30771, "Kolik posledních let"), "enable": ("years_mode", "last")},
        {"id": "sort", "type": "choice", "label": L(30953, "Řadit podle"),
         "options": [(v, L(sid, fb)) for v, sid, fb in MYCAT_SORTS]},
        {"id": "audio", "type": "choice", "label": L(30287, "Jazyk zvuku"), "options": tracks, "enable": stream},
        {"id": "subs", "type": "choice", "label": L(30884, "Titulky"), "options": tracks, "enable": stream},
        {"id": "q", "type": "choice", "label": L(30994, "Minimální kvalita"), "enable": stream,
         "options": [(str(v), L(sid, fb) if sid else fb) for v, sid, fb in MYCAT_QUALITY_LABELS]},
        {"id": "surround", "type": "bool", "label": L(30888, "5.1 a víc"), "enable": stream},
        {"id": "show", "type": "choice", "label": L(30774, "Zobrazit seřazené podle"), "enable": stream,
         "help": " ".join("%s: %s" % (L(sid, fb), L(*MYCAT_SHOW_HELP[v])) for v, sid, fb in MYCAT_SHOW_LABELS),
         "options": [(v, L(sid, fb)) for v, sid, fb in MYCAT_SHOW_LABELS]},
        {"id": "first_batch", "type": "bool", "label": L(30227, "Hned spustit první dávku"), "enable": stream}]
    return [{"id": "catalog", "label": L(30944, "Vlastní katalogy"), "fields": fields}]


def _mycat_remote_template(kind_fixed):
    """Akce „Načíst šablonu“ (vlákno serveru, bez UI Kodi): vyplní formulář polí šablony."""
    def run(values):
        key = values.get("template") or ""
        t = next((t for t in mycat.templates() if t["key"] == key), None)
        fields = mycat.template_fields(key)
        if t is None or fields is None or (kind_fixed and t["kind"] != kind_fixed):
            return {"level": "warn", "text": L(30248, "Bez šablony"), "set": {}}
        form = _mycat_form_values(fields, t["kind"])
        form.pop("icon", None)
        form["name"] = mycat_template_name(t)
        form["first_batch"] = "true"
        if kind_fixed:
            form.pop("kind", None)
        return {"level": "ok", "text": L(30260, "Šablona načtena – uprav a ulož."), "set": form}
    return run


def _mycat_remote_autoname(kind_fixed):
    """Akce pro automatický název (vlákno serveru, bez UI Kodi)."""
    def run(values):
        kind, fields = _mycat_fields_from_form(dict(values, kind=kind_fixed or values.get("kind")))
        return {"level": "ok", "text": "", "set": {"name": mycat_record("", kind, fields)["name"]}}
    return run


def mycat_remote(cat_id, ctype):
    """Nový nebo upravený katalog z mobilu (QR, stejný server jako Nastavit z mobilu)."""
    cat = next((c for c in mycats() if c.get("id") == cat_id), None) if cat_id else None
    kind = (cat or {}).get("kind") or ("series" if ctype == "series" else "movie")
    new = cat is None
    values = _mycat_form_values(cat or {}, kind)
    values.update(template="", first_batch="true", name=(cat or {}).get("name") or "")
    schema = mycat_remote_schema(kind, new, (cat or {}).get("name_auto", True))
    actions = {"template": _mycat_remote_template(None if new else kind),
               "autoname": _mycat_remote_autoname(None if new else kind)}
    changes = _remote_form(schema, values, actions, {
        "title": "Nokturno – " + L(30944, "Vlastní katalogy"),
        "intro": L(30290, "Vyber šablonu, nebo vyplň katalog ručně, a ulož ho."),
        "expired": L(30462, "Tato adresa už neplatí. Na TV spusť Nastavit z mobilu znovu.")})
    if changes is None:
        return
    merged = dict(values, **changes)
    if not new:
        merged["kind"] = kind
    kind, fields = _mycat_fields_from_form(merged)
    cid = (cat or {}).get("id") or f"k{int(time.time() * 1000):x}"
    if fields["verify"] and mycat_verify_full(cid):
        notify(L(30780, "Ověřovat jde nejvýš 20 katalogů."), xbmcgui.NOTIFICATION_WARNING)
        fields["verify"] = False
    auto = mycat_record(cid, kind, fields)["name"]
    name = (merged.get("name") or "").strip()
    rec = mycat_record(cid, kind, fields, name=name, name_auto=not name or name == auto)
    mycat.save(STORE, rec)
    if new:
        usage.mark_feature(STORE, "mycatalog")
    notify(L(30235, "Katalog uložen."))
    xbmc.executebuiltin("Container.Refresh")
    if merged.get("first_batch") == "true":
        mycat_first_batch(rec, ask=False)


def mycat_trigger_due(index):
    """Mobil má síť jen v popředí: je-li v indexu co ověřit, služba dostane malou dávku hned teď."""
    try:
        if catindex.next_batch(index, int(time.time()), size=1):
            return True
    except Exception:  # noqa: BLE001 – rozbitý index nesmí shodit menu
        pass
    return False


def mycat_folder(cat, ctype):
    context = [(L(30946, "Upravit katalog"), runplugin(action="mycat_edit", id=cat["id"])),
               (L(30205, "Upravit na mobilu"), runplugin(action="mycat_remote", id=cat["id"], type=ctype)),
               (L(30947, "Smazat katalog"), runplugin(action="mycat_delete", id=cat["id"])),
               (L(31032, "Odebrat z hlavního menu"), runplugin(action="mycat_menu", id=cat["id"], on="0"))
               if cat.get("menu") else
               (L(31031, "Zobrazit v hlavním menu"), runplugin(action="mycat_menu", id=cat["id"], on="1"))]
    folder_item(cat.get("name") or L(30972, "Vlastní katalog"),
                build_url(action="mycat", type=ctype, id=cat["id"]), icon=mycat.icon_for(cat), context=context)


def list_mycats(ctype):
    due = None
    for cat in mycats(ctype):
        mycat_folder(cat, ctype)
        if due is None and cat.get("verify") and mycat_trigger_due(mycat.load_index(STORE, cat)):
            due = cat["id"]
    if due:
        xbmcgui.Window(10000).setProperty(VERIFY_TRIGGER_PROP, due)
    action_item(L(30945, "Nový katalog"), build_url(action="mycat_new", type=ctype), icon="DefaultAddSource.png")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_mycat_verified(apis, cat, ctype, page, widget=False):
    """Ověřovaný katalog: jen tituly, které index (`mycat_index_<id>`) označil za vyhovující; první řádek
    je akce „načíst teď“, prázdný index nebo tituly po termínu popoženou službu. `widget` = řada na
    domovské obrazovce skinu: bez akce a bez upozornění, jen tituly."""
    index = mycat.load_index(STORE, cat)
    if not index.get("items") and apis.get("dash") is not None:
        # Kandidáty stahuje služba, jenže na Androidu bývá na pozadí bez sítě (a pak hodinu čeká, viz
        # `accounts_offline`). V popředí síť je – bez kandidátů by se neukázaly ani nálezy z jiných zařízení.
        try:
            mycat.refresh(engine_of(apis), STORE, apis.get("dash"), cat["id"], 0, verify=False)
        except Errors as e:
            log_error(f"mycat pool {cat['id']}: {e}")
        index = mycat.load_index(STORE, cat)
    checked, matched, total = mycat.counts(index)
    if page == 1 and not widget:
        action_item(_swf(30777, "Ověřeno %s z %s – spustit dávku nyní", checked, total),
                    build_url(action="mycat_batch", id=cat["id"]), icon="DefaultAddonsUpdates.png", thumb=True)
    metas = mycat.shown(index, sort=cat.get("show") or "found")
    if not metas or mycat_trigger_due(index):
        xbmcgui.Window(10000).setProperty(VERIFY_TRIGGER_PROP, cat["id"])
    if not metas and not widget:
        notify(L(30778, "Katalog se připravuje – tituly se ověřují na pozadí."), xbmcgui.NOTIFICATION_INFO, 4000)
    rate(metas, ctype)
    for m in metas:
        add_meta_item(m, ctype)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_mycat(apis, ctype, cat_id, page=1, widget=False):
    cat = next((c for c in mycats(ctype) if c.get("id") == cat_id), None)
    dash = apis.get("dash")
    if not cat or (dash is None and not cat.get("verify")):
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    set_content("tvshows" if ctype == "series" else "movies")
    if cat.get("verify"):
        list_mycat_verified(apis, cat, ctype, page, widget)
        return
    if cat.get("sort") == mycat.ALPHA:   # nejoblíbenější tituly podle filtrů, seřazené podle abecedy (pool má cache)
        pool = mycat.pool(dash, dict(cat, kind=ctype))
        metas, pages = (None, 1) if pool is None else (pool[(page - 1) * 20:page * 20], max(1, -(-len(pool) // 20)))
    else:
        metas, pages = dash.discover(ctype, mycat_params(cat), page=page)
        metas = None if metas is None else mycat.released(metas)
    if metas is None:
        if not widget:
            notify(L(30959, "Katalog se nepodařilo načíst. Zkus to později."), xbmcgui.NOTIFICATION_WARNING)
        metas = []
    rate(metas, ctype)
    for m in metas:
        add_meta_item(m, ctype)
    if metas and page < pages and not widget:
        next_page_item(build_url(action="mycat", type=ctype, id=cat_id, page=page + 1))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False, updateListing=UPDATE_LISTING)


# --- koncerty ------------------------------------------------------------------------
# Samostatný modul v hlavním menu: uživatel vybere hudební žánry (štítky Last.fm), interprety
# z nich prohledává služba na pozadí (`concertcat.refresh`) ve vlastním úložišti a volitelně ve WebShare,
# HellSpy a FastShare, pokud je má uživatel zapnuté.
# Výpisy čtou jen index (`concerts_index`), žádná síť.

# štítky Last.fm (`concertcat.TAGS`): tag → (id řetězce, český fallback)
CONCERT_TAG_LABELS = {"czech": (30793, "Česká scéna"), "slovak": (30794, "Slovenská scéna"),
                      "czech rock": (30795, "Český rock"), "classic rock": (30796, "Classic rock"),
                      "hard rock": (30797, "Hard rock"), "metal": (30798, "Metal"), "rock": (30799, "Rock"),
                      "pop": (30836, "Pop"), "punk": (30837, "Punk"), "hip-hop": (30838, "Hip-hop"),
                      "jazz": (30839, "Jazz"), "electronic": (30854, "Elektronika"), "folk": (30855, "Folk"),
                      "classical": (30856, "Klasika"), "reggae": (30857, "Reggae"), "world": (30858, "World")}
CONCERT_ICON = "DefaultMusicSongs.png"   # nota ze standardní sady skinu
CONCERTS = "concerts"                      # cíl ověřování ve službě (stejný literál jako v service.py)


def concert_tag_label(tag):
    return L(*CONCERT_TAG_LABELS[tag]) if tag in CONCERT_TAG_LABELS else tag


def _concert_item(g, label):
    """Koncert = přehratelná položka; přehraje první soubor, který jde, ostatní kopie jsou záložní (`play_ref`)."""
    refs = [f["ref"] for f in g["files"]]
    li = xbmcgui.ListItem(label=label)
    li.setLabel2(human_size(g["files"][0].get("size") or 0))
    li.setProperty("IsPlayable", "true")
    img = concertcat.image(g["files"])
    li.setArt(dict({"icon": CONCERT_ICON}, **({"thumb": img, "poster": img} if img else {})))
    tag = li.getVideoInfoTag()
    tag.setTitle(label)
    duration = max((int(f.get("duration") or 0) for f in g["files"]), default=0)
    if duration:
        tag.setDuration(duration)
    xbmcplugin.addDirectoryItem(
        HANDLE, build_url(action="play_ref", ref=refs[0], alts=",".join(refs[1:]), name=label), li, isFolder=False)


def _concert_label(g):
    return "%s (%s)" % (g["title"], g["year"]) if g["year"] else g["title"]


def _concert_artists(artists):
    for a in artists:
        li = xbmcgui.ListItem(label="%s (%d)" % (a["name"], len(concertcat.group(a["files"], a["name"]))))
        img = concertcat.image(a["files"])
        li.setArt(dict({"icon": CONCERT_ICON}, **({"thumb": img, "poster": img} if img else {})))
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="concerts_artist", a=a["id"]), li, isFolder=True)


def list_concerts():
    """Koncerty: bez nastavení jen „Nastavit koncerty“, jinak Nově přidané, Podle žánru, Podle abecedy a stav."""
    set_content("files")
    setup = build_url(action="concerts_setup")
    if not concertcat.configured(STORE) or not setting("lastfm_key").strip():
        li = xbmcgui.ListItem(label=L(30256, "Nastavit koncerty"))
        li.setArt({"icon": "DefaultAddonProgram.png"})
        li.getVideoInfoTag().setPlot(L(30289, "Hledá koncerty ve tvém vlastním úložišti a skládá z nich katalog, "
                                              "volitelně i v úložištích třetích stran, která máš povolená a "
                                              "nastavená. Vyber hudební žánry a zadej klíč Last.fm."))
        xbmcplugin.addDirectoryItem(HANDLE, setup, li, isFolder=False)
        action_item(L(31035, "Hledat interpreta"), build_url(action="concerts_search"), icon="DefaultAddonsSearch.png")
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    index = concertcat.load_index(STORE)
    checked, _matched, total = catindex.counts(index)
    if not index.get("items") or mycat_trigger_due(index):
        xbmcgui.Window(10000).setProperty(VERIFY_TRIGGER_PROP, CONCERTS)
    folder_item(L(30877, "Nově přidané"), build_url(action="concerts_recent"), icon="DefaultRecentlyAddedMusicVideos.png",
                info=L(31088, "Koncerty, které se do katalogu dostaly naposledy."))
    folder_item(L(30257, "Podle žánru"), build_url(action="concerts_tags"), icon="DefaultMusicGenres.png",
                info=L(31089, "Koncerty seskupené podle hudebního žánru."))
    folder_item(L(30258, "Podle abecedy"), build_url(action="concerts_letters"), icon="DefaultMusicArtists.png",
                info=L(31090, "Interpreti seřazení podle prvního písmene jména."))
    action_item(L(31035, "Hledat interpreta"), build_url(action="concerts_search"), icon="DefaultAddonsSearch.png",
                info=L(31091, "Zadej jméno interpreta a doplněk dohledá jeho koncerty ve tvých zdrojích."))
    progress = (_swf(30219, "Prohledáno %s z %s – načíst teď", checked, total) if index.get("pool_end") else
                _swf(31025, "Prohledáno %s interpretů, další přibývají – načíst teď", checked))
    action_item(progress,
                build_url(action="mycat_batch", id=CONCERTS), icon="DefaultAddonsUpdates.png", thumb=True,
                info=L(31092, "Koncerty se prohledávají postupně na pozadí. Kliknutím načteš další dávku hned."))
    action_item(L(30256, "Nastavit koncerty"), setup, icon="DefaultAddonProgram.png",
                info=L(31093, "Změníš hudební žánry a klíč Last.fm, ze kterých se skládá katalog koncertů."))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _concerts_empty_hint(rows):
    if not rows:
        notify(L(30779, "Katalog se připravuje – interpreti se prohledávají na pozadí."),
               xbmcgui.NOTIFICATION_INFO, 4000)


def list_concerts_recent():
    set_content("videos")
    rows = concertcat.recent(concertcat.load_index(STORE))
    _concerts_empty_hint(rows)
    for g in rows:
        _concert_item(g, "%s – %s" % (g["artist"], _concert_label(g)))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_concerts_tags():
    set_content("files")
    index = concertcat.load_index(STORE)
    tags = concertcat.tags_available(index)
    _concerts_empty_hint(tags)
    for t in tags:
        folder_item(concert_tag_label(t), build_url(action="concerts_tag", tag=t), icon="DefaultMusicGenres.png")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_concerts_tag(tag):
    set_content("files")
    _concert_artists(concertcat.by_tag(concertcat.load_index(STORE), tag))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_concerts_letters():
    set_content("files")
    letters = concertcat.letters(concertcat.load_index(STORE))
    _concerts_empty_hint(letters)
    for letter, n in letters.items():
        folder_item("%s (%d)" % (letter, n), build_url(action="concerts_letter", l=letter),
                    icon="DefaultMusicArtists.png")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_concerts_letter(letter):
    set_content("files")
    _concert_artists(concertcat.by_letter(concertcat.load_index(STORE), letter))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _concert_searched(ts):
    """„Naposledy prohledáno 3. 10. 2026“ / „Zatím neprohledáno“."""
    if not ts:
        return L(31043, "Zatím neprohledáno")
    t = time.localtime(ts)
    return _swf(31041, "Naposledy prohledáno %s", "%d. %d. %d" % (t.tm_mday, t.tm_mon, t.tm_year))


def list_concerts_artist(artist_id):
    """Koncerty jednoho interpreta a na konci „Znovu prohledat“ s datem posledního hledání."""
    set_content("videos")
    index = concertcat.load_index(STORE)
    entry = (index.get("items") or {}).get(artist_id) or {}
    name = (entry.get("meta") or {}).get("name")
    for g in concertcat.artist(index, artist_id):   # jméno interpreta i tady: „Kabát – Koncert v Aréně (2014)“
        _concert_item(g, "%s – %s" % (name, _concert_label(g)) if name else _concert_label(g))
    if name:
        st = concertcat.status(index, "").get(concertcat._key(name)) or {}
        action_item("%s – %s" % (L(31040, "Znovu prohledat"), _concert_searched(st.get("searched"))),
                    build_url(action="concerts_add", name=name, exact=1), icon="DefaultAddonsUpdates.png")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def concerts_search():
    """Ruční hledání interpreta: zadaný text, pak výpis kandidátů (jako výsledky hledání titulů)."""
    text = xbmcgui.Dialog().input(L(31039, "Interpret")).strip()
    if not text:
        return
    # Last.fm se ptá tady, s ukazatelem průběhu: výpis by jinak po zmizení kolečka ~3 s stál bez odezvy
    bg = xbmcgui.DialogProgressBG()
    bg.create(L(30922, "Koncerty"), "%s: %s" % (L(31039, "Interpret"), text))
    try:
        _concert_candidates(text)
    finally:
        bg.close()
    xbmc.executebuiltin("Container.Update(%s)" % build_url(action="concerts_find", q=text))


def _concert_candidates(text):
    """Kandidáti z Last.fm pro výpis hledání, 10 min v cache (hledání a výpis jsou dva běhy pluginu)."""
    return STORE.cached_if("concerts_find:" + concertcat._key(text), 600,
                           lambda: concertcat.lastfm_search(setting("lastfm_key").strip(), text))


def list_concerts_find(text):
    """Výsledky hledání interpreta: nalezení v katalogu a kandidáti z Last.fm (Lucie → Lucie, Lucie Bílá…).
    Interpret s koncerty je složka, neprohledaný nebo bez nálezu se klikem prohledá ve zdrojích zařízení."""
    set_content("files")
    known = concertcat.status(concertcat.load_index(STORE), text)
    shown = set()

    def add(name, listeners=None, exact=1):
        k = concertcat._key(name)
        if k in shown:
            return
        shown.add(k)
        st = known.get(k) or {}
        lines = [_swf(31042, "%s posluchačů na Last.fm", "{:,}".format(listeners).replace(",", " "))] \
            if listeners else []
        if st.get("count"):
            li = xbmcgui.ListItem(label="%s (%d)" % (st["name"], st["count"]))
            li.setArt({"icon": CONCERT_ICON})
            li.getVideoInfoTag().setPlot("\n".join(lines))
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action="concerts_artist", a=st["id"]), li, isFolder=True)
            return
        lines.append(_concert_searched(st.get("searched")) + (" – " + L(31044, "nic nenalezeno")
                                                               if st.get("searched") else ""))
        li = xbmcgui.ListItem(label=st.get("name") or name)
        li.setArt({"icon": "DefaultMusicArtists.png"})
        li.getVideoInfoTag().setPlot("\n".join(lines))
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="concerts_add", name=name, exact=exact), li,
                                    isFolder=False)

    for st in sorted((v for v in known.values() if v["match"] and v["count"]), key=lambda v: v["name"].casefold()):
        add(st["name"])
    for c in _concert_candidates(text):
        add(c["name"], c["listeners"])
    add(text, exact=0)   # záloha: zadaný text (bez klíče s opravou jména přes Last.fm, je-li klíč)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def concerts_add(name, exact):
    """Prohledá interpreta ve zdrojích zařízení (nově přidaného i „Znovu prohledat“) a otevře jeho koncerty."""
    bg = xbmcgui.DialogProgressBG()
    bg.create(L(30922, "Koncerty"), L(31038, "Hledám koncerty…"))
    try:
        mid = concertcat.add_artist(engine_of(get_apis()), STORE, name, should_stop, exact=exact)
    finally:
        bg.close()
    usage.mark_feature(STORE, "concerts")
    if mid is None:
        notify(L(31036, "Zdroje teď neodpovídají, zkus to později."), xbmcgui.NOTIFICATION_WARNING)
        return
    if not concertcat.artist(concertcat.load_index(STORE), mid):
        notify(_swf(31037, "Koncerty interpreta %s se nenašly.", name), xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
        return
    if xbmc.getInfoLabel("Container.FolderPath").find("action=concerts_artist") >= 0:
        xbmc.executebuiltin("Container.Refresh")
    else:
        xbmc.executebuiltin("Container.Update(%s)" % build_url(action="concerts_artist", a=mid))


def concerts_setup():
    """Nastavit koncerty: chybí-li klíč Last.fm, zeptá se na něj a ověří ho; pak výběr hudebních žánrů."""
    dlg = xbmcgui.Dialog()
    if not setting("lastfm_key").strip():
        dlg.ok(L(30922, "Koncerty"), L(30226, "Koncerty potřebují vlastní API klíč Last.fm. Je zdarma na "
                                              "last.fm/api – vytvoř si ho a opiš."))
        key = dlg.input(L(30785, "Last.fm API klíč"), type=xbmcgui.INPUT_ALPHANUM).strip()
        if not key:
            return
        try:
            ok = concertcat.check_key(key)
        except concertcat.ConcertError:
            notify(L(30996, "Last.fm se nepodařilo zeptat. Zkus to později."), xbmcgui.NOTIFICATION_WARNING)
            return
        if not ok:
            notify(L(30923, "Klíč Last.fm neplatí."), xbmcgui.NOTIFICATION_ERROR)
            return
        ADDON.setSetting("lastfm_key", key)
    tags = list(CONCERT_TAG_LABELS)
    current = concertcat.config(STORE)["tags"]
    chosen = dlg.multiselect(L(30792, "Hudební žánry"), [concert_tag_label(t) for t in tags],
                             preselect=[i for i, t in enumerate(tags) if t in current])
    if chosen is None:
        return
    if not chosen:
        notify(L(30259, "Vyber aspoň jeden hudební žánr."), xbmcgui.NOTIFICATION_WARNING)
        return
    concertcat.configure(STORE, [tags[i] for i in chosen])
    usage.mark_feature(STORE, "concerts")
    xbmc.executebuiltin("Container.Refresh")
    if dlg.yesno(L(30740, "Spustit hledání koncertů nyní?"),
                 L(30018, "První dávka prohledá víc interpretů najednou, ať je v katalogu hned co ukázat. "
                          "Běží na pozadí.")):
        xbmcgui.Window(10000).setProperty(VERIFY_MANUAL_PROP, "%s:%s" % (CONCERTS, FIRST_BATCH_SIZE))


def play_ref(apis, ref, name="", alts=""):
    """Přehraje vnitřní odkaz (`dav:`/`ws:`/`hs:`/`fs:`) bez titulu; nejde-li první, zkusí kopie z `alts` (po čárkách)."""
    mylist_play(apis, "|".join([ref] + [a for a in (alts or "").split(",") if a]), name)


def lastfm_check():
    """Tlačítko „Ověřit klíč“ v nastavení Last.fm."""
    try:
        ok = bool(setting("lastfm_key").strip()) and concertcat.check_key(setting("lastfm_key").strip())
    except concertcat.ConcertError:
        notify(L(30996, "Last.fm se nepodařilo zeptat. Zkus to později."), xbmcgui.NOTIFICATION_WARNING)
        return
    if ok:
        notify(L(30978, "Klíč Last.fm je v pořádku."), xbmcgui.NOTIFICATION_INFO)
    else:
        notify(L(30923, "Klíč Last.fm neplatí."), xbmcgui.NOTIFICATION_ERROR)


def tmdb_check():
    """Tlačítko „Ověřit klíč“ v nastavení TMDB (vlastní klíč; bez něj jdou dotazy přes server Nokturna)."""
    key = setting("tmdb_api_key").strip()
    if not key:
        notify(L(31030, "Bez vlastního klíče se TMDB ptá přes server Nokturna."), xbmcgui.NOTIFICATION_INFO)
        return
    try:
        TmdbApi(key)._get("/configuration")
    except TmdbError as err:
        if "neplatný" in str(err):
            notify(L(31028, "Klíč TMDB neplatí."), xbmcgui.NOTIFICATION_ERROR)
        else:
            notify(L(31029, "TMDB se nepodařilo zeptat. Zkus to později."), xbmcgui.NOTIFICATION_WARNING)
        return
    notify(L(31027, "Klíč TMDB je v pořádku."), xbmcgui.NOTIFICATION_INFO)


# --- hledání + historie -----------------------------------------------------------

def search_title(kind):
    return {"movie": L(30010), "series": L(30011), "ws": L(30045),
            "hs": L(30197, "Hledat na HellSpy"), "dav": L(30386, "Hledat ve vlastním úložišti"),
            "any": L(30150, "Hledat")}.get(kind, L(30150, "Hledat"))


def search_history(kind):
    """Pro sjednocené hledání i dřívější dotazy z časů oddělených složek."""
    if kind != "any":
        return STORE.history(kind)
    seen, out = set(), []
    for key in ("any", "movie", "series"):
        for q in STORE.history(key):
            if q.lower() not in seen:
                seen.add(q.lower())
                out.append(q)
    return out


def search_menu(kind):
    """Složka hledání: nové hledání + historie dotazů."""
    folder_item(L(30040), build_url(action="search_new", type=kind), icon="DefaultAddonsSearch.png",
                info=L(31094, "Zadej název a doplněk ho vyhledá ve všech zdrojích."))
    history = search_history(kind)
    for q in history:
        folder_item(q, build_url(action="search_run", type=kind, q=q), icon="DefaultAddonsSearch.png",
                    context=[(L(30042), runplugin(action="history_remove", type=kind, q=q))])
    if history:
        # ne-složka: vymazání není výpis, Kodi ji spustí s handle −1 (viz action_item)
        action_item(L(30041), build_url(action="history_clear", type=kind), icon="DefaultVideoDeleted.png",
                    info=L(31095, "Smaže uloženou historii hledání."))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def search_new(apis, kind):
    query = xbmcgui.Dialog().input(search_title(kind), type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        # zrušený dialog = Kodi zůstane v menu hledání; `succeeded=True` by ho navedlo
        # do prázdné složky. Řádek `GetDirectory - Error getting …` v logu je cena za to.
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    search_run(apis, kind, query)


# pomocné metody jádra bez stavu (porovnání názvů, sloučení, rok) — nepotřebují klienty ani úložiště
_JADRO = Engine.__new__(Engine)


def same_title(luna_meta, sosac_meta):
    """Stejný film/seriál v obou zdrojích (viz `Engine._same_title`)."""
    return _JADRO._same_title(luna_meta, sosac_meta)


def merge_results(luna_metas, sosac_metas):
    """[(meta, alt)] – titul z Luny s přibaleným id Sosáče, zbylé položky Sosáče zvlášť (jádro)."""
    return _JADRO._merge(luna_metas, sosac_metas)


def split_year(query):
    """„Pět švestek 2026“ → („Pět švestek“, „2026“) — jako `Engine.split_year`, rok jako text
    (jde do odkazů a klíčů cache)."""
    base, year = Engine.split_year(query)
    return base, str(year) if year else ""


def filter_year(merged, year):
    """Rok v dotazu je filtr: projdou jen tituly z toho roku (a ty, kde ho zdroj neuvádí)."""
    return _JADRO._by_year(merged, int(year) if str(year).isdigit() else None)


class SearchProgress:
    """Ukazatel průběhu hledání.

    Kroků je tolik, kolik je doopravdy dotazů na zdroje, tedy dva typy krát
    zapnuté zdroje. Dokud se počítaly jen typy, uměl ukazatel skočit z nuly na
    polovinu a rovnou na konec. Ze dvou vláken se do něj sahá zároveň, proto zámek.
    """

    def __init__(self, bar, total):
        self.bar, self.total, self.done = bar, max(1, total), 0
        self.lock = threading.Lock()
        self.sources = []   # [(label, count), ...] v pořadí, jak zdroje dorazily
        self.audio_done = self.audio_total = 0   # čtení hlaviček (ověření zvuku) — poslední fáze

    def _show(self):
        """„Streamy: 35“ (součet ze zdrojů, průběžně přibývá) je vidět pořád, během ověřování
        k němu přibude „Meta: 3/12“ (zkrácené 2026-09-17, přání uživatele). Dřív se vypisoval každý zdroj
        zvlášť („Luna: 8 · WebShare: 12 · …“) — na TV nečitelné (2026-09-16, přání uživatele)."""
        percent = int(self.done / self.total * 100)
        parts = []
        if self.sources:
            parts.append(L(30240, "Streamy: {count}").format(count=sum(n for _label, n in self.sources)))
        if self.audio_total:
            parts.append(L(30239, "Meta: {done}/{total}").format(
                done=self.audio_done, total=self.audio_total))
        if parts:
            self.bar.update(percent, " · ".join(parts))
        else:
            # hledání titulu (search_run) source()/audio() nehlásí — nechává si text z create()
            self.bar.update(percent)

    def tick(self):
        with self.lock:
            self.done = min(self.done + 1, self.total)
            self._show()

    def reach(self, value):
        """Dorovná ukazatel — z cache se výsledek vrátí rovnou a kroky neproběhnou."""
        with self.lock:
            if value > self.done:
                self.done = min(value, self.total)
                self._show()

    def set(self, done, total):
        """`on_progress` jádra: to si počet kroků upravuje za běhu (kolik hlaviček se čte)."""
        with self.lock:
            self.total = max(1, total)
            self.done = min(done, self.total)
            self._show()

    def source(self, label, count):
        """`on_source_done` jádra: doplní přehled, odkud kolik streamů zatím přišlo."""
        with self.lock:
            self.sources.append((label, count))
            self._show()

    def audio(self, done, total):
        """`on_audio_progress` jádra: kolik hlaviček souborů je ověřeno z kolika se čte —
        poslední a nejdelší fáze, kdy už `source()` dál nepřibývá."""
        with self.lock:
            self.audio_done, self.audio_total = done, total
            self._show()


def _search_merge(apis, ctype, query, want_year, errors, tick=None):
    """Sloučené výsledky primárního zdroje a přihlášeného Sosáče pro jeden typ
    (film / seriál), BEZ popisů — stačí na počty pro volbu Filmy/Seriály.
    Řetězec zdrojů (TMDB → Luna → veřejný Sosáč → Cinemeta, + přihlášený Sosáč)
    a cache jsou v jádru, viz `Engine.search_pairs`."""
    failures = []
    try:
        return engine_of(apis).search_pairs(ctype, query, int(want_year) if want_year else None, on_tick=tick,
                                            failures=failures, with_enrich=False)
    finally:
        errors.extend(SourceFailure(label, err) for label, err in failures)


def search_source(apis, ctype, query, want_year, errors):
    """`_search_merge()` + doplněné popisy — pro skutečné zobrazení seznamu (jádro
    cachuje holý katalog a doplněný výsledek zvlášť, volba Filmy/Seriály na popisy nečeká)."""
    failures = []
    try:
        return engine_of(apis).search_pairs(ctype, query, int(want_year) if want_year else None,
                                            failures=failures)
    finally:
        errors.extend(SourceFailure(label, err) for label, err in failures)


def dav_only_item(apis, raw_query):
    """„Jen v mém úložišti“ ve společném hledání. Úložiště se při hledání nečte, počet nálezů se neukazuje."""
    if apis.get("dav"):
        folder_item(L(31116, "Jen v mém úložišti"), build_url(action="search_run", type="dav", q=raw_query),
                    icon="DefaultHardDisk.png",
                    info=L(31117, "Hledá dotaz jen mezi soubory ve vlastním úložišti."))


def search_run(apis, kind, query, offset=0):
    # `search_new` prázdný dotaz nepustí dál, ale sem se dá dostat i přímo (crafted plugin://
    # URL, widget) — prázdné `q=` u Sosáče/WebSharu/HellSpy spadne na nerozparsovatelné odpovědi
    if not str(query or "").strip():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    if kind not in ("hs", "dav"):
        # HellSpy se hledá jen jako odbočka z dotazu, který v katalozích nic
        # nenašel — do historie patří ten původní dotaz, ne tahle odbočka
        STORE.add_history(kind, query)
    if kind == "ws":
        list_ws_results(apis, query, offset)
        return
    if kind == "hs":
        list_hs_results(apis, query, offset)
        return
    if kind == "dav":
        list_dav_results(apis, query, offset)
        return
    raw_query = query
    query, want_year = split_year(query)
    errors = []
    if kind == "any":
        # jedno hledání pro obojí; volba se nabídne, jen když dotaz sedí na filmy i seriály.
        # Oba dotazy běží souběžně — jinak by procházení čekalo na součet obou (7 s místo 4 s).
        # Jen holý katalog (_search_merge), bez popisů — na volbu Filmy/Seriály
        # stačí počty a čekání na enrich by ji zbytečně zdrželo.
        bar = xbmcgui.DialogProgressBG()
        bar.create(L(30000, "Nokturno"), L(30150, "Hledat"))
        bar.update(0)
        # primární zdroj je vždy jeden krok (TMDB/Luna, nebo za ně zaskočí sosac_db/Cinemeta
        # — viz _search_merge); přihlášený Sosáč se sčítá zvlášť, běží nezávisle na primárním zdroji
        sources = 1 + (1 if apis.get("sosac") else 0)
        progress = SearchProgress(bar, 2 * sources)
        results = {}
        try:
            with ThreadPoolExecutor(max_workers=2) as pool:
                futures = {pool.submit(_search_merge, apis, "movie", query, want_year, errors,
                                       progress.tick): "movie",
                          pool.submit(_search_merge, apis, "series", query, want_year, errors,
                                      progress.tick): "series"}
                # aktualizace v pořadí, jak doopravdy dobíhají — zůstat na pevném
                # pořadí (nejdřív film) by procento drželo na 0 %, dokud nedoběhnou oba
                finished = 0
                for future in as_completed(futures):
                    results[futures[future]] = future.result()
                    finished += 1
                    progress.reach(finished * sources)
        finally:
            bar.close()
        movies, _ = results["movie"]
        series, _ = results["series"]
        if movies and series:
            set_content("files")
            folder_item(f"{L(30012)} ({len(movies)})", build_url(action="search_run", type="movie", q=raw_query),
                       icon="DefaultMovies.png")
            folder_item(f"{L(30013)} ({len(series)})", build_url(action="search_run", type="series", q=raw_query),
                       icon="DefaultTVShows.png")
            dav_only_item(apis, raw_query)
            for e in errors:
                log_error(e)
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            return
        kind = "series" if series else "movie"
    ctype = kind
    set_content("tvshows" if ctype == "series" else "movies")
    # vždy přes search_source() — i po volbě z Filmy/Seriály; holý katalog výše
    # je z vlastní cache (_search_merge) skoro zadarmo, teprve tady se čeká na popisy
    merged, mixed = search_source(apis, ctype, query, want_year, errors)
    rate([meta for meta, _alt in merged], ctype)
    for meta, alt in merged:
        add_meta_item(meta, ctype, alt=alt, tag_source=mixed)
    dav_only_item(apis, raw_query)
    # bez Luny (nebo když zrovna neodpovídá) nabídneme rovnou soubory z WebShare
    # (jinak je má Luna: Search u titulu — tam by šlo o duplicitu)
    luna_down = any(error_label(e) == "Luna" for e in errors)
    if apis["ws"] and (not apis["luna"] or luna_down):
        try:
            files, _total = apis["ws"].search(query, sort=SORTS[int(setting("ws_sort", "0"))], limit=WS_PAGE)
            remember_ws_token(apis["ws"])
            for f in files:
                add_ws_file(f)
        except WebshareError as e:
            errors.append(e)
    if not merged:
        # V katalozích nic. WebShare ani HellSpy tituly neznají, jsou to úložiště
        # souborů — soubor pojmenovaný stejně tam ale být může a starší nebo
        # okrajové věci bývají jen tam. Nabídne se to až tady, do rozcestníku
        # fulltext nepatří a běžné hledání by jen zdržoval.
        if apis.get("ws"):
            folder_item(L(30045), build_url(action="search_run", type="ws", q=query),
                       icon="DefaultAddonsSearch.png")
        if apis.get("hs"):
            folder_item(L(30197, "Hledat na HellSpy"), build_url(action="search_run", type="hs", q=query),
                       icon="DefaultAddonsSearch.png")
    for e in errors:
        log_error(e)
    if errors:
        # blokující dialog, ne jen toast — ať si uživatel opravdu všimne, že nějaký zdroj
        # neodpověděl, a ví přesně který; výsledky ze zbylých zdrojů se zobrazí hned po OK
        # (endOfDirectory běží až za tímhle). Jen po kliku ve výpisu Nokturna: výsledky
        # hledání jdou i do widgetu / přes JSON-RPC (HA) a tam by modál čekal na OK,
        # které nikdo nedá, a blokoval i vypínání Kodi (pravidlo v CLAUDE.md)
        if browsing_nokturno():
            xbmcgui.Dialog().ok(L(30360, "Zdroj neodpověděl"), describe_errors(errors))
        else:
            notify(skipped_notice(errors), xbmcgui.NOTIFICATION_WARNING, 7000)
            li = xbmcgui.ListItem(label=f"[COLOR {WARN_COLOR}]{L(30360, 'Zdroj neodpověděl')}[/COLOR]: "
                                  + describe_errors(errors).replace("\n", " · "))
            li.setArt({"icon": "DefaultIconError.png"})
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action="settings"), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_ws_results(apis, query, offset=0):
    api = apis["ws"]
    if api is None:
        raise WebshareError(L(30104))
    # „videos" je obecný typ a skiny k němu nabízejí jen základní seznam;
    # u konkrétního typu je na výběr celá sada zobrazení. Kodi si zobrazení
    # pamatuje podle typu obsahu, takže tyhle seznamy sdílejí nastavení s Filmy.
    set_content("movies")
    files, total = api.search(query, sort=SORTS[int(setting("ws_sort", "0"))], limit=WS_PAGE, offset=offset)
    remember_ws_token(api)
    for f in files:
        add_ws_file(f)
    if offset + len(files) < total and files:
        next_page_item(build_url(action="search_run", type="ws", q=query, offset=offset + len(files)))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False, updateListing=UPDATE_LISTING)


def list_hs_results(apis, query, offset=0):
    api = apis.get("hs")
    if api is None:
        raise HellspyError(L(30104))
    set_content("movies")
    files, _next = api.search(query, limit=HS_PAGE, offset=offset)
    for f in files:
        add_hs_file(f)
    # HellSpy neposílá celkový počet, jen další offset; další strana se nabídne,
    # dokud chodí plná dávka
    if len(files) == HS_PAGE:
        next_page_item(build_url(action="search_run", type="hs", q=query, offset=offset + len(files)))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False, updateListing=UPDATE_LISTING)


def _storage_ok(api, errors):
    """Jde úložiště přečíst? Chyba se připíše k ostatním a úložiště se přeskočí."""
    try:
        api.files()
        return True
    except StorageError as e:
        errors.append(SourceFailure(api.name, e))
        return False


def list_dav_browse(apis, slot=0, path=""):
    """Moje úložiště — procházení po složkách.

    Složky se neptají serveru po jedné: strom se skládá ze zapamatovaného seznamu
    souborů (`StorageApi.files`), takže přechod do podsložky je okamžitý. Ukazují se
    jen složky, ve kterých je aspoň jedno video — prázdné by jen překážely. Napřed
    se vždy vybírá úložiště (i jen jedno nastavené, 2026-09-15) — uživatel tak vidí
    jeho jméno a ví, do čeho se dívá, než se napojí na jeho data."""
    storages = apis.get("dav") or []
    if not storages:
        raise StorageError(L(30104))
    if not slot:
        for api in storages:
            folder_item(api.name, build_url(action="dav_browse", slot=api.slot), icon="DefaultHardDisk.png")
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    api = next((s for s in storages if s.slot == slot), storages[0])
    prefix = f"{path.strip('/')}/" if path.strip("/") else ""
    folders, files = {}, []
    for f in api.files():
        if not f["path"].startswith(prefix):
            continue
        rest = f["path"][len(prefix):]
        if "/" in rest:
            name = rest.split("/", 1)[0]
            folders[name] = folders.get(name, 0) + 1
        else:
            files.append(f)
    for name in sorted(folders, key=str.casefold):
        count = folders[name]
        folder_item(f"{name}  [COLOR FF9A9A9A]{count}[/COLOR]",
                    build_url(action="dav_browse", slot=api.slot, path=prefix + name), icon="DefaultFolder.png")
    if files:
        set_content("movies")
    files = sorted(files, key=lambda f: f["name"].casefold())
    # ponytail: popisy jen prvním 60 souborům složky (bez stránkování), víc až se stránkováním výpisu
    metas = dav_titles(apis, files[:60])
    for f in files:
        add_dav_file(api, f, meta=metas.get(f["path"]))
    if not folders and not files:
        notify(L(30102))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_dav_results(apis, query, offset=0):
    storages = apis.get("dav") or []
    if not storages:
        raise StorageError(L(30104))
    set_content("movies")
    errors, rows = [], []
    for api in storages:
        if _storage_ok(api, errors):
            rows += [(api, f) for f in api.search(query, limit=10 ** 6)[0]]
    page = rows[offset:offset + WS_PAGE]
    metas = dav_titles(apis, [f for _api, f in page])
    for api, f in page:
        add_dav_file(api, f, meta=metas.get(f["path"]))
    if offset + WS_PAGE < len(rows):
        next_page_item(build_url(action="search_run", type="dav", q=query, offset=offset + WS_PAGE))
    if errors:
        notify(skipped_notice(errors), xbmcgui.NOTIFICATION_WARNING, 7000)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False, updateListing=UPDATE_LISTING)


def history_remove(kind, query):
    # sjednocené hledání ("any") zobrazuje i historii z "movie"/"series"
    # (viz search_history) — dotaz je proto potřeba smazat ze všech tří
    for k in (("any", "movie", "series") if kind == "any" else (kind,)):
        STORE.remove_history(k, query)
    xbmc.executebuiltin("Container.Refresh")


def history_clear(kind):
    # adresář nezavírá — položka je ne-složka (handle −1) jako u `history_remove`;
    # ze staré oblíbené položky s handle ≥ 0 ho zavře `_tlacitko` v routeru
    for k in (("any", "movie", "series") if kind == "any" else (kind,)):
        STORE.clear_history(k)
    xbmc.executebuiltin("Container.Refresh")


# --- zhlédnuto, Můj seznam, Pokračovat ----------------------------------------------

def prune_mylist(keys=None, apis=None):
    """Zhlédnuté pryč z Mého seznamu (jádro `favprune`). Bez `apis` jen filmy a díly —
    seriál potřebuje metadata, dožene ho `prefetch` ze služby."""
    if not on("fav_drop_watched"):
        return []
    try:
        removed = favprune.prune(STORE, engine_of(apis) if apis else None, keys)
    except Exception as e:  # noqa: BLE001 – úklid seznamu nesmí shodit zhlédnutí ani zahřívání
        log_error(f"Můj seznam: {e}")
        return []
    if removed:
        xbmc.log(f"[{ADDON_ID}] z Mého seznamu (zhlédnuto): {', '.join(removed)}", xbmc.LOGINFO)
        request_sync()
        xbmcgui.Window(10000).setProperty("nokturno.trakt_pull", "1")   # odebrání i na Trakt Watchlist
    return removed


def set_watched(key, watched):
    """Zhlédnuto/nezhlédnuto do evidence, do HA (synchronizace) i do Traktu."""
    STORE.set_watched(key, watched)
    if watched:
        prune_mylist([key])
    request_sync()
    trakt = get_trakt()
    if trakt and trakt.logged_in():
        base, season, episode = split_episode_id(key)
        try:
            (trakt.mark_watched if watched else trakt.unmark_watched)(base, season, episode)
        except TraktError as e:
            log_error(f"trakt: {e}")


def toggle_watched(key):
    watched = not STORE.playcount(key)
    set_watched(key, watched)
    if watched and split_episode_id(key)[1] is not None:
        prune_mylist([key], get_apis())   # ručně označený poslední díl → seriál pryč hned
    xbmc.executebuiltin("Container.Refresh")


def adopt_kodi_marks():
    """„Označit jako zhlédnuté“ ze skinu Kodi → evidence Nokturna (viz `kodi_marks`).

    Kodi po označení výpis hned obnoví, takže tohle běží dřív, než se položky
    nakreslí — a nakreslí se už se správnou fajfkou. Chyba nesmí shodit výpis."""
    def apply(changes):
        for key, watched in changes.items():
            if bool(STORE.playcount(key)) != watched:
                xbmc.log(f"[{ADDON_ID}] zhlédnuto z Kodi: {key} → {'ano' if watched else 'ne'}", xbmc.LOGINFO)
                set_watched(key, watched)
    try:
        kodi_marks.collect(STORE, xbmcvfs.translatePath("special://database/"), apply=apply,
                           write=kodi_marks.rpc_writer(xbmc.executeJSONRPC))
    except Exception as e:  # noqa: BLE001 – cizí databáze, cokoli neočekávaného jen do logu
        log_error(f"zhlédnuto z Kodi: {e}")


def remove_progress(key, series=None):
    """Odebrání z Pokračovat ve sledování — vynuluje rozkoukanost (`resume`/`total`),
    ne zhlédnutí. Nový `ts` (nastaví ho `set_resume`) je to, co odebrání přenese
    i na ostatní synchronizovaná Kodi — bez novějšího času by ho starší rozkoukaný
    záznam odjinud zase přepsal zpátky (viz sync.py, vyhrává vždy novější).

    Volá se z kontextového menu (RunPlugin), ale i z integrace pro Home Assistant
    přes `Files.GetDirectory` (`ExecuteAddon` neumí RunPlugin akce spustit) — proto
    `succeeded=False` jako u „Vymazat mezipaměť": bez něj by na tenhle typ volání
    Kodi čekalo na výpis složky, který nikdy nepřijde."""
    STORE.set_resume(key, 0, 0)
    if series:
        # „Další díl“ není rozkoukaný — dopočítává se z posledního zhlédnutého dílu,
        # takže vynulované resume ho nezmění a položka se hned vrátila (Hospoda 1x02
        # v kartě HA). Pamatuje se proto skrytý díl: jakmile se zhlédne další a na řadě
        # je jiný, nabídne se zase.
        STORE.hide_next(series, key)   # synchronizuje se na ostatní Kodi a do HA
    request_sync()
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
    xbmc.executebuiltin("Container.Refresh")


def toggle_fav(apis, key, ctype, series_id=None, alt=None):
    info = STORE.item(key)
    if (not info or thin_snapshot(info)) and not str(key).startswith("ws:"):
        try:
            meta, video = load_meta(apis, ctype, key, series_id)
            info = snapshot(meta, ctype, video, series_id, alt)
        except Errors as e:
            log_error(e)
            info = info or {"type": ctype, "id": key, "title": key, "series": series_id, "alt": alt, "art": {}}
    added = STORE.toggle_favourite(key, info)
    notify(L(30065) if added else L(30066))
    request_sync()
    # Trakt Watchlist = Můj seznam; služba změnu pošle hned, ne až v dalším kole
    xbmcgui.Window(10000).setProperty("nokturno.trakt_pull", "1")
    xbmc.executebuiltin("Container.Refresh")


def list_favourites():
    # „videos" je obecný typ a skiny k němu nabízejí jen základní seznam;
    # u konkrétního typu je na výběr celá sada zobrazení. Kodi si zobrazení
    # pamatuje podle typu obsahu, takže tyhle seznamy sdílejí nastavení s Filmy.
    set_content("movies")
    apis = None
    for key in STORE.favourites():
        snap = STORE.item(key)
        if snap and thin_snapshot(snap):
            apis = apis or get_apis()
            snap = recover_snapshot(apis, key, (snap or {}).get("type")) or snap
        if snap:
            add_snapshot_item(key, snap)
    # z hlavního menu sem — patří k „mým“ titulům a synchronizuje se s nimi
    folder_item(L(30064), build_url(action="recent"), icon="DefaultRecentlyAddedMovies.png",
                info=L(31096, "Filmy a seriály, které jsi naposledy přehrával."))
    if sync_targets():
        folder_item(L(30184, "Synchronizovat teď"), build_url(action="sync_now"), icon="DefaultAddonsUpdates.png",
                    info=L(31097, "Srovná seznam a rozkoukaná videa s ostatními tvými zařízeními."))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# --- Hlídané -----------------------------------------------------------------------
# Nové díly sledovaných seriálů a tituly, které čekají na stream (nebo na lepší). Logika,
# seznamy i synchronizace jsou v jádru (`lib/watch.py`) a sdílí je karta v Home Assistantu —
# tady je jen menu. Kontrolu dělá služba na pozadí (`WatchChecker`) přes `action=watch_check`,
# stejnou cestou jako obnovu stavu zdrojů.

WATCH_TRIGGER_PROP = "nokturno.watch_check"
WATCH_STATE = "watch_state"          # watch_state.json: {"last_run": čas poslední kontroly}
WATCH_NEW = "FFE8A33D"               # nový díl, kontrolovat dál
WATCH_OK = "FF6FCF7F"                # lze pustit


def request_watch_check(force=False):
    """Kontrolu dělá služba — plugin skončí dřív, než by hledání doběhlo."""
    xbmcgui.Window(10000).setProperty(WATCH_TRIGGER_PROP, "force" if force else "1")
    if force:
        notify(L(30920, "Kontroluji Hlídané…"))


def watch_context(ctype, key, alt=None):
    """Hlídat / Přestat hlídat v kontextovém menu titulu."""
    if ctype == "series":
        on_ = watch_lib.is_series_watched(STORE, key)
        return (L(30902, "Přestat hlídat nové díly") if on_ else L(30901, "Hlídat nové díly"),
                runplugin(action="watch_series", id=key, alt=alt))
    on_ = watch_lib.is_wanted(STORE, key)
    return (L(30904, "Přestat hlídat") if on_ else L(30903, "Hlídat, až bude k dispozici"),
            runplugin(action="want", id=key, type=ctype, alt=alt))


def watch_info(apis, ctype, key, alt=None):
    """Název, rok a plakát do seznamu — ze snímku, jinak z metadat."""
    snap = STORE.item(key)
    if not snap or thin_snapshot(snap):
        try:
            meta, _video = load_meta(apis, ctype, key)
            snap = snapshot(meta, ctype, alt=alt)
            STORE.remember_item(key, snap)
        except Errors as e:
            log_error(e)
            snap = snap or {}
    art = snap.get("art") or {}
    return {"title": strip_year(snap.get("title"), snap.get("year")) or key, "year": snap.get("year") or "",
            "poster": art.get("poster") or art.get("thumb") or "", "alt": alt, "type": ctype}


def toggle_watch_series(apis, sid, alt=None):
    if watch_lib.is_series_watched(STORE, sid):
        watch_lib.unwatch_series(STORE, sid)
        notify(L(30917, "Odebráno z Hlídaných"))
    else:
        watch_lib.watch_series(STORE, sid, watch_info(apis, "series", sid, alt))
        notify(L(30916, "Přidáno do Hlídaných"))
        request_watch_check()
    request_sync()
    xbmc.executebuiltin("Container.Refresh")


def toggle_want(apis, wid, ctype="movie", alt=None):
    if watch_lib.is_wanted(STORE, wid):
        watch_lib.unwant(STORE, wid)
        notify(L(30917, "Odebráno z Hlídaných"))
    else:
        watch_lib.want(STORE, wid, watch_info(apis, ctype, wid, alt))
        notify(L(30916, "Přidáno do Hlídaných"))
        request_watch_check()
    request_sync()
    xbmc.executebuiltin("Container.Refresh")


def offer_watch(meta, ctype, item_id, video, series_id, alt):
    """Žádný stream ani po uvolněném hledání — nabídnout, že se Nokturno ozve samo.
    U dílu se hlídá celý seriál (nový díl = přesně tohle), u filmu titul."""
    if video:
        sid = series_id or split_episode_id(item_id)[0]
        if watch_lib.is_series_watched(STORE, sid):
            return
        if xbmcgui.Dialog().yesno(L(30577, "Žádný stream nenalezen"),
                                  L(30925, "Ozvat se, až díl bude k dispozici?[CR]Seriál se zařadí do Hlídaných "
                                           "a Nokturno ho kontroluje každých šest hodin.")):
            watch_lib.watch_series(STORE, sid, {"title": meta.get("_title") or meta.get("name") or sid,
                                                "poster": meta.get("poster") or "", "alt": alt})
            request_sync()
            notify(L(30916, "Přidáno do Hlídaných"))
        return
    if watch_lib.is_wanted(STORE, item_id):
        return
    if xbmcgui.Dialog().yesno(L(30577, "Žádný stream nenalezen"),
                              L(30924, "Ozvat se, až bude k dispozici?[CR]Titul se zařadí do Hlídaných "
                                       "a Nokturno ho jednou denně zkontroluje.")):
        year = str(meta.get("year") or meta.get("releaseInfo") or "")[:4]
        watch_lib.want(STORE, item_id, {"title": display_name(meta), "year": year, "type": ctype,
                                        "poster": meta.get("poster") or "", "alt": alt})
        request_sync()
        notify(L(30916, "Přidáno do Hlídaných"))


def watch_flag(wid):
    watch_lib.toggle_flag(STORE, wid)
    request_sync()
    xbmc.executebuiltin("Container.Refresh")


def watch_episode_context(sid, ep_id, alt=None):
    """„Kontrolovat dál“ u dílu: díl má streamy, ale ne takové, jaké uživatel chce
    (třeba bez CZ titulků) — hlídá se jako titul a ozve se, až streamů přibude."""
    _base, season, episode = split_episode_id(ep_id)
    on_ = watch_lib.is_flagged(STORE, ep_id) and watch_lib.is_wanted(STORE, ep_id)
    text = L(30906, "Nekontrolovat dál") if on_ else L(30905, "Kontrolovat dál")
    return (f"{text} {season}x{episode:02d}", runplugin(action="watch_episode", id=ep_id, series=sid, alt=alt))


def toggle_watch_episode(apis, ep_id, sid, alt=None):
    if watch_lib.is_wanted(STORE, ep_id):
        watch_lib.unwant(STORE, ep_id)
        notify(L(30917, "Odebráno z Hlídaných"))
    else:
        _base, season, episode = split_episode_id(ep_id)
        info = watch_info(apis, "series", sid, alt)
        info.update(title=f"{info['title']} · {season}x{episode:02d}", year="", series=sid)
        watch_lib.want(STORE, ep_id, info)
        if not watch_lib.is_flagged(STORE, ep_id):
            watch_lib.toggle_flag(STORE, ep_id)
        notify(L(30916, "Přidáno do Hlídaných"))
        request_watch_check()
    request_sync()
    xbmc.executebuiltin("Container.Refresh")


def watch_seen(sid=None):
    watch_lib.mark_seen(STORE, sid)
    request_sync()
    xbmc.executebuiltin("Container.Refresh")


def watch_open(apis, sid, alt=None):
    """Seriál z Hlídaných: otevřít = nový díl je vidět, zhasne i v kartě HA."""
    if (watch_lib.series(STORE).get(sid) or {}).get("new"):
        watch_lib.mark_seen(STORE, sid)
        request_sync()
    list_seasons(apis, sid, alt=alt)


def watch_status(rec, flagged):
    """Stav hlídaného titulu slovem v barvě — ✔/✘ fonty skinů nekreslí."""
    if rec.get("streams"):
        if flagged:
            return f"[COLOR {WATCH_NEW}]{L(30905, 'Kontrolovat dál').lower()}[/COLOR]"
        return f"[COLOR {WATCH_OK}]{L(30909, 'lze pustit')}[/COLOR]"
    if not rec.get("checked"):
        return ""
    return f"[COLOR {GREY}]{L(30911, 'hlídá se') if rec.get('pending') else L(30910, 'zatím ne')}[/COLOR]"


def _watch_li(label, key, poster):
    li = xbmcgui.ListItem(label=label)
    snap = STORE.item(key)
    if snap and snap.get("type") not in ("ws", "hs", "dav"):
        fill_info_snapshot(li, snap)
    if poster:
        li.setArt({"poster": poster, "thumb": poster})
    return li


def prune_watched_wants():
    """Zhlédnuté pryč z Hlídaných: film i díl, a díl i tehdy, když je zhlédnutý některý
    z dalších (obývák 2026-10-19: 2x03 zhlédnutý, v Hlídaných dál „lze pustit“)."""
    seen = STORE.load("watched", {})
    done_eps = {}
    for key, rec in seen.items():
        base, season, episode = split_episode_id(key)
        if season is not None and int((rec or {}).get("playcount") or 0):
            done_eps[base] = max(done_eps.get(base, (0, 0)), (season, episode))

    def done(key):
        if int((seen.get(key) or {}).get("playcount") or 0):
            return True
        base, season, episode = split_episode_id(key)
        return season is not None and done_eps.get(base, (0, 0)) >= (season, episode)

    rows = dict(watch_lib.wanted(STORE))
    rows.update(watch_lib.results(STORE))
    gone = [wid for wid, rec in rows.items() if done(wid) or done(rec.get("found_id") or wid)]
    for wid in gone:
        watch_lib.unwant(STORE, wid)
    if gone:
        xbmc.log(f"[{ADDON_ID}] z Hlídaných (zhlédnuto): {', '.join(gone)}", xbmc.LOGINFO)
        request_sync()
    return gone


def list_watch():
    """Sledované seriály (nové díly nahoře) a hlídané tituly."""
    set_content("movies")
    prune_watched_wants()
    check_now = (L(30918, "Zkontrolovat teď"), runplugin(action="watch_check_now"))
    items = sorted(watch_lib.series(STORE).items(),
                   key=lambda kv: (not kv[1].get("new"), (kv[1].get("title") or "").lower()))
    flags = watch_lib.flags(STORE)
    # díl s „kontrolovat dál“ u sledovaného seriálu patří na řádek seriálu, ne na vlastní
    flagged_eps = {}
    for wid in watch_lib.wanted(STORE):
        base, season, _ep = split_episode_id(wid)
        if season is not None and wid in flags and base in dict(items):
            flagged_eps.setdefault(base, []).append(wid)
    for sid, item in items:
        label = item.get("title") or sid
        new, avail = item.get("new"), item.get("available")
        if new:
            label += f" · [COLOR {WATCH_NEW}]{L(30908, 'nový díl')} {int(new['season'])}x{int(new['episode']):02d}[/COLOR]"
        elif avail:
            label += f" · [COLOR {GREY}]{int(avail['season'])}x{int(avail['episode']):02d}[/COLOR]"
        for wid in sorted(flagged_eps.get(sid, [])):
            _b, season, episode = split_episode_id(wid)
            if not avail or avail.get("id") != wid:
                label += f" · [COLOR {GREY}]{season}x{episode:02d}[/COLOR]"
            label += f" · [COLOR {WATCH_NEW}]{L(30905, 'Kontrolovat dál').lower()}[/COLOR]"
        li = _watch_li(label, sid, item.get("poster"))
        ctx = ([(L(30907, "Označit nový díl jako viděný"), runplugin(action="watch_seen", id=sid))] if new else [])
        if avail and avail.get("id"):
            ctx.append(watch_episode_context(sid, avail["id"], item.get("alt")))
        ctx += episodes_context(sid, (new or avail or item.get("latest") or {}).get("season"), item.get("alt"))
        li.addContextMenuItems(ctx + [(L(30902, "Přestat hlídat nové díly"),
                                       runplugin(action="watch_series", id=sid)), check_now])
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="watch_open", id=sid, alt=item.get("alt")), li,
                                    isFolder=True)
    # vlastní seznam + výsledky kontroly (i titulů z Traktu); co ještě neprošlo kontrolou,
    # je jen v seznamu
    rows = dict(watch_lib.wanted(STORE))
    rows.update(watch_lib.results(STORE))
    for wids in flagged_eps.values():
        for wid in wids:
            rows.pop(wid, None)
    order = sorted(rows.items(), key=lambda kv: (not kv[1].get("streams"), kv[0] in flags,
                                                (kv[1].get("title") or "").lower()))
    for wid, rec in order:
        title = rec.get("title") or wid
        year = str(rec.get("year") or "")[:4]
        label = f"{title} ({year})" if year and year not in title else title
        status = watch_status(rec, wid in flags)
        if status:
            label += " · " + status
        own = watch_lib.is_wanted(STORE, wid)
        ctx = []
        if rec.get("streams"):
            ctx.append((L(30906, "Nekontrolovat dál") if wid in flags else L(30905, "Kontrolovat dál"),
                        runplugin(action="watch_flag", id=wid)))
        if own:
            ctx.append((L(30904, "Přestat hlídat"), runplugin(action="want", id=wid, type=rec.get("type"))))
        ctx.append(check_now)
        target = rec.get("found_id") or wid
        li = _watch_li(label, target, rec.get("poster"))
        _sid, season, _ep = split_episode_id(target)
        if season is not None:
            ctx += episodes_context(rec.get("series") or _sid, season, rec.get("alt"))
        li.addContextMenuItems(ctx)
        if season is not None:
            # hlídaný díl — rovnou výběr streamu
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action="title", type="series", id=target,
                                                          series=rec.get("series") or _sid,
                                                          alt=rec.get("alt")), li, isFolder=False)
        elif str(target).startswith("q:"):
            # titul zatím žádný zdroj nezná — aspoň hledání podle názvu
            url = build_url(action="search_run", type=rec.get("type", "movie"), q=rec.get("query") or title)
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
        elif rec.get("type") == "series":
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action="seasons", id=target, alt=rec.get("alt")), li,
                                        isFolder=True)
        else:
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action="title", type="movie", id=target,
                                                          alt=rec.get("alt")), li, isFolder=False)
    action_item(L(30918, "Zkontrolovat teď"), build_url(action="watch_check_now"), icon="DefaultAddonsUpdates.png",
                info=L(31098, "Hned zjistí, jestli nevyšly nové díly nebo lepší streamy hlídaných titulů."))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def watch_check(apis, force=False):
    """Kontrola Hlídaných — volá ji služba přes JSON-RPC (`WatchChecker`). Jen seriály
    a tituly, které nikdo ve skupině synchronizace nekontroloval v posledních 6 h / 24 h."""
    engine = engine_of(apis)
    try:
        with engine.background():   # na pozadí: počká na hledání, na které uživatel čeká (`Engine.gate`)
            done = watch_lib.check_series(engine, STORE, force=force, should_stop=should_stop)
            done += watch_lib.check_wanted(engine, STORE, force=force, should_stop=should_stop)
    except Aborted:
        raise
    except Exception as e:  # noqa: BLE001 – kontrola na pozadí nesmí nic shodit
        log_error(f"kontrola Hlídaných: {e}")
        done = []
    STORE.save(WATCH_STATE, {"last_run": int(time.time())})
    if done:
        xbmc.log(f"[{ADDON_ID}] Hlídané: zkontrolováno {len(done)}", xbmc.LOGINFO)
        request_sync()
    # jako `accounts_refresh()`: prázdný, ale úspěšně zavřený adresář
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)


def list_recent():
    # „videos" je obecný typ a skiny k němu nabízejí jen základní seznam;
    # u konkrétního typu je na výběr celá sada zobrazení. Kodi si zobrazení
    # pamatuje podle typu obsahu, takže tyhle seznamy sdílejí nastavení s Filmy.
    set_content("movies")
    apis = None
    for key, _entry in STORE.recently_watched():
        snap = STORE.item(key)
        # zhlédnuté z jiného zařízení (synchronizace) přijdou bez snímku — bez
        # dohledání by je výpis tiše vynechal a „Naposledy" na druhém Kodi zůstalo prázdné
        if not snap or thin_snapshot(snap):
            apis = apis or get_apis()
            snap = recover_snapshot(apis, key, (snap or {}).get("type")) or snap
        if snap:
            add_snapshot_item(key, snap)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def aired_videos(videos, today):
    """Díly, které už vyšly — bez speciálů, setříděné podle sezóny a čísla.

    Datum vydání (`released`, u TMDB `air_date`) se do 6.3.3 nečetlo vůbec: po dílu
    číslo 1 se prostě vzal první s vyšším číslem, i kdyby vycházel za tři měsíce.
    Vadily tím obě cesty, kterými se další díl používá:

    - `prefetch(kind="next")` na něj každé kolo zahřívání pustí `collect_streams()`,
      tedy hledání napříč všemi zdroji. Kolo běží po `WARM_EVERY` (2,5 h) a po každém
      dokoukání dílu, nejvýš pro `PREFETCH_SERIES` seriálů — u seriálu, který běží
      týdně, to je až několik desítek marných hledání denně. Ukládá se jen nález
      (`cached_if`), takže se prázdný výsledek nikdy neodloží a opakuje se pořád dokola.
      Právě opakovanými dotazy na zdroje si doplněk už dvakrát řekl o blokaci od
      HellSpy (6.0.2 a 6.0.4).
    - Řádek „Další díl" v Pokračovat ve sledování (`list_continue`, synchronizuje se
      i do karty v Home Assistantu) nabízel díl, který ještě nešlo nikde sehnat.

    Seriály, kterým TMDB data nedává vůbec, se řídí dál starým pravidlem: nemá-li
    datum ani jeden díl, projde celý seznam. Jinak by u nich další díl přestal
    fungovat úplně.

    Díl bez data je něco jiného než díl, který ve zdrojích chybí — chybějící díl se
    hledat má, nevydaný ne.
    """
    known = [v for v in videos if int(v.get("season") or 0) > 0]
    if any(v.get("released") for v in known):
        known = [v for v in known if v.get("released") and str(v["released"])[:10] <= today]
    return sorted(known, key=lambda v: (int(v.get("season") or 0), int(v.get("episode") or 0)))


def next_episode(apis, snap):
    """Další už vydaná epizoda po zhlédnuté (podle meta seriálu), nebo None."""
    series_id = snap.get("series")
    if not series_id or snap.get("season") is None:
        return None
    try:
        # meta_for má záložní zdroje (TMDB, Cinemeta) — bez Luny seriál z Pokračovat nezmizí
        meta = meta_for(apis, "series", series_id)
    except Errors:
        return None
    videos = aired_videos(meta.get("videos") or [], time.strftime("%Y-%m-%d"))
    cur = (int(snap.get("season") or 0), int(snap.get("episode") or 0))
    for v in videos:
        if (int(v.get("season") or 0), int(v.get("episode") or 0)) > cur:
            return v, meta


def recover_snapshot(apis, key, ctype=None):
    """Snímek pro titul, který má záznam o rozkoukání, ale v `items.json` chybí,
    nebo je „hubený" (`thin_snapshot` — bez popisu i fotky, viz volající).

    Chybějící snímek: stávalo se, když zápis z přehrání přepsal jiný proces
    (rejstřík Sosáče, do 2.0.22) — a bez snímku výpis položku tiše vynechal,
    takže titul v Pokračovat ve sledování „nebyl". Hubený snímek: titul se
    přidal do Mého seznamu/Pokračovat dřív, než pro něj doběhlo obohacení
    (TMDB, přepočet na pozadí) — `snapshot()` pak nemá co dát do popisu ani
    fotky, a bez týhle opravy zůstane prázdný navždy, i když data mezitím
    dorazila. Dohledá se z meta a uloží, ať to příště nestojí dotaz na síť.
    Soubory WebShare/HellSpy meta nemají, u těch není z čeho.
    """
    if key.startswith(("ws:", "hs:", "dav:", "dl:")):
        return None
    base, season, _episode = split_episode_id(key)
    # typ z hubeného snímku (seriál z Watchlistu Traktu nemá číslo dílu, a jako film
    # by se dohledal úplně jiný titul — Black Warrant jako „Roshagadu", 2026-10-03)
    if season is not None or ctype not in ("movie", "series"):
        ctype = "series" if season is not None else "movie"
    try:
        meta, video = load_meta(apis, ctype, key)
        snap = snapshot(meta, ctype, video, base if video else None, None)
    except Errors as e:
        log_error(f"snímek {key}: {e}")
        return None
    STORE.remember_item(key, snap)
    return snap


def list_continue(apis):
    """Rozkoukané tituly + další díly po naposledy zhlédnutých epizodách."""
    # „videos" je obecný typ a skiny k němu nabízejí jen základní seznam;
    # u konkrétního typu je na výběr celá sada zobrazení. Kodi si zobrazení
    # pamatuje podle typu obsahu, takže tyhle seznamy sdílejí nastavení s Filmy.
    set_content("movies")
    rozkoukane = STORE.in_progress()
    serie_rozkoukane = set()
    for key, _entry in rozkoukane:
        snap = STORE.item(key)
        if not snap or thin_snapshot(snap):
            snap = recover_snapshot(apis, key, (snap or {}).get("type")) or snap
        if snap:
            if snap.get("season") is not None and snap.get("series"):
                serie_rozkoukane.add(snap["series"])
            add_snapshot_item(key, snap, [(L(30365, "Odebrat z Pokračovat ve sledování"),
                                          runplugin(action="remove_progress", id=key))])
    seen_series = set()
    snaps = []
    for key, _entry in STORE.recently_watched(40):
        snap = STORE.item(key)
        # seriál s rozkoukaným dílem má jeden řádek – „Další díl“ se k němu nepřidává
        if not snap or snap.get("season") is None or snap.get("series") in seen_series \
                or snap.get("series") in serie_rozkoukane:
            continue
        seen_series.add(snap.get("series"))
        snaps.append(snap)
    # meta každého seriálu je dotaz na síť (Luna 10 min, TMDB 30 dní v cache) — souběžně,
    # dřív se Pokračovat s deseti seriály otevíralo deset dotazů za sebou;
    # SparePool přežije „can't start new thread“ (Android) – Pokračovat se zobrazí, jen pomaleji
    with SparePool(max_workers=6) as pool:
        nalezeno = list(pool.map(lambda s: next_episode(apis, s), snaps))
    for snap, found in zip(snaps, nalezeno):
        if not found:
            continue
        video, meta = found
        ep_id = video.get("id") or f"{snap['series']}:{video.get('season')}:{video.get('episode')}"
        # rozkoukaný další díl už je nahoře mezi rozkoukanými – podruhé jako „Další díl“ ne
        if STORE.playcount(ep_id) or STORE.next_hidden(snap["series"]) == ep_id or ep_id in dict(rozkoukane):
            continue
        li = xbmcgui.ListItem(label=f"{L(30067)}: {meta.get('_title') or meta.get('name')} – "
                                    f"{int(video.get('season') or 0)}x{int(video.get('episode') or 0):02d} {video.get('title') or ''}")
        li.setArt(art_for(meta, video))
        fill_info(li, meta, "series", video=video)
        apply_watched(li, ep_id, [fav_context(ep_id, "series", snap["series"], snap.get("alt")),
                                  (L(30365, "Odebrat z Pokračovat ve sledování"),
                                   runplugin(action="remove_progress", id=ep_id, series=snap["series"]))]
                      + episodes_context(snap["series"], video.get("season"), snap.get("alt"))
                      + streams_context("series", ep_id, snap["series"], snap.get("alt")))
        add_playable(li, "series", ep_id, series_id=snap["series"], alt=snap.get("alt"))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# --- seriály ---------------------------------------------------------------------

def list_seasons(apis, series_id, alt=None):
    meta = meta_for(apis, "series", series_id)
    if is_sosac_id(series_id):
        enrich_one(meta, apis["luna"], STORE, "series", tmdb=get_tmdb())
    rate([meta], "series")
    videos = meta.get("videos") or []
    seasons = sorted({int(v.get("season") or 0) for v in videos}, key=lambda s: (s == 0, s))
    set_content("seasons")
    for s in seasons:
        tpl = L(30023)
        label = L(30022) if s == 0 else (tpl % s if "%d" in tpl else f"{tpl} {s}")
        li = xbmcgui.ListItem(label=label)
        li.setArt(art_for(meta))
        fill_info(li, meta, "series")
        tag = li.getVideoInfoTag()
        tag.setMediaType("season")
        tag.setSeason(s)
        # `fill_info()` nastaví Title na název seriálu (správně pro epizody/film) —
        # tady jde o výběr sezóny, skin (řádek sezón) kreslí `ListItem.Title`, ne
        # `ListItem.Label`, takže bez přepsání byly všechny položky pojmenované
        # stejně jako seriál místo „1. série“/„2. série“ (2026-09-15, nahlásil
        # uživatel screenshotem: „Lupin Lupin Lupin“ místo čísel sérií).
        tag.setTitle(label)
        # sezóna je zhlédnutá, když jsou zhlédnuté všechny její epizody
        eps = [v for v in videos if int(v.get("season") or 0) == s]
        if eps and all(STORE.playcount(v.get("id") or f"{series_id}:{s}:{v.get('episode')}") for v in eps):
            li.getVideoInfoTag().setPlaycount(1)
        url = build_url(action="episodes", id=series_id, season=s, alt=alt)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    similar_item("series", series_id)
    xbmcplugin.endOfDirectory(HANDLE)


def list_episodes(apis, series_id, season, alt=None):
    meta = meta_for(apis, "series", series_id)
    set_content("episodes")
    videos = [v for v in meta.get("videos") or [] if int(v.get("season") or 0) == season]
    videos.sort(key=lambda v: int(v.get("episode") or 0))
    ep_ids = [v.get("id") or f"{series_id}:{season}:{v.get('episode')}" for v in videos]
    # „další na řadě" = první nezhlédnutý díl za posledním zhlédnutým v téhle sezóně;
    # dokud v ní nic zhlédnuté není, neoznačuje se nic (nemá co navazovat)
    watched = [bool(STORE.playcount(ep_id)) for ep_id in ep_ids]
    next_up = next((i for i in range(max((i for i, w in enumerate(watched) if w), default=-1) + 1, len(videos))
                    if not watched[i]), None) if any(watched) else None
    for i, v in enumerate(videos):
        label = "%d. %s" % (int(v.get("episode") or 0), v.get("title") or "")
        if i == next_up:
            label = f"[COLOR {LANG_COLORS.get('CZ', 'FFFFC94D')}]»[/COLOR] {label}"
        li = xbmcgui.ListItem(label=label)
        if i == next_up:
            li.setProperty("nokturno.next", "true")
        li.setArt(art_for(meta, v))
        fill_info(li, meta, "series", video=v)
        ep_id = ep_ids[i]
        apply_watched(li, ep_id, [fav_context(ep_id, "series", series_id, alt)]
                      + streams_context("series", ep_id, series_id, alt)
                      + [watch_episode_context(series_id, ep_id, alt)])
        add_playable(li, "series", ep_id, series_id=series_id, alt=alt)
    # widget a výpis v Nokturnu mívají stejnou adresu, položky se ale liší podle okna (add_playable)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def similar_item(ctype, item_id):
    """Složka „Podobné tituly“ na konci seznamu streamů filmu a sezón seriálu."""
    if IMDB_ID_RE.match(str(item_id or "")):
        folder_item(L(30482, "Podobné tituly"), build_url(action="similar", type=ctype, id=item_id),
                    icon="DefaultVideoPlaylists.png", info=L(31099, "Tituly, které se podobají tomuto."))


def foryou_seeds(apis, ctype, limit=foryou.SEEDS):
    """Tituly, ze kterých se doporučuje — naposledy zhlédnuté daného typu."""
    return foryou.seed_ids(STORE.recently_watched(), ctype, limit=limit)


def foryou_seed_names(seeds):
    """`{id vzoru: název}` ze snímků titulů v profilu (`items.json`) — žádný dotaz
    na síť. Co snímek nemá, do „Protože jsi viděl …" prostě nepůjde."""
    hledane, out = set(seeds), {}
    for key, _entry in STORE.recently_watched():
        base, season, _episode = split_episode_id(key)
        if base not in hledane or base in out:
            continue
        snap = STORE.item(key) or {}
        name = strip_year(snap.get("tvshow") if season is not None else snap.get("title"), snap.get("year"))
        if name:
            out[base] = name
    return out


def foryou_build(apis, ctype, seeds):
    """Doporučení ke vzorům: s vlastním klíčem přímo z TMDB, bez něj (nebo při jeho
    chybě) z dashboardu, který se na TMDB zeptá za doplněk — stejná dvojice jako
    u „Podobné tituly" (`list_similar`)."""
    tmdb, dash = apis.get("tmdb"), apis.get("dash")

    def similar(item_id):
        if should_stop():
            # pět vzorů = až patnáct dotazů na TMDB za sebou; při vypínání Kodi
            # se smyčka nesmí dotáhnout do konce (CLAUDE.md, „Přerušení při vypnutí")
            raise Aborted()
        if tmdb is not None:
            try:
                return tmdb.similar(ctype, item_id, limit=foryou.PER_SEED)
            except TmdbError as e:
                log_error(f"pro tebe {item_id}: {e}")
        if dash is not None:
            return dash.similar(ctype, item_id)
        return []

    skip = foryou.known_ids(STORE.recently_watched(limit=WATCHED_MAX), STORE.in_progress())
    return foryou.recommend(seeds, similar, skip=skip)


def foryou_items(apis, ctype, seeds):
    """Seznam „Pro tebe" z cache; přepočítá se, jen když je stará nebo se změnily vzory.

    Klíč je jeden na typ a seznam vzorů se ukládá dovnitř — po zhlédnutí nového titulu
    se doporučení přepočítají hned (jinak by týden stála na místě), ale při výpadku TMDB
    i dashboardu je pořád z čeho ukázat poslední známý stav místo prázdna
    (`FORYOU_STALE_TTL`). Značka výpadku `FORYOU_DOWN_KEY` drží doplněk od toho, aby
    při každém otevření znovu čekal na timeout — přesně jako `nokturno:trend:down`
    v `trend_api.py` (6.2.2, nález 30)."""
    key = f"nokturno:foryou:{ctype}"
    rec = STORE.peek_cached(key, FORYOU_TTL) or {}
    stara = STORE.peek_cached(key, FORYOU_REFRESH_AFTER) is None
    if rec.get("items") and rec.get("seeds") == seeds and not (warming() and stara):
        return rec["items"]
    zaloha = (STORE.peek_cached(key, FORYOU_STALE_TTL) or {}).get("items") or []
    if STORE.peek_cached(FORYOU_DOWN_KEY, FORYOU_DOWN_TTL) is not None:
        return zaloha
    items = foryou_build(apis, ctype, seeds)
    if not items:
        # buď zdroj neodpověděl, nebo TMDB k těmhle vzorům nic nezná — tak jako tak
        # se to nemá zkoušet znovu při každém otevření seznamu
        STORE.cached_if(FORYOU_DOWN_KEY, FORYOU_DOWN_TTL, lambda: {"t": int(time.time())}, fresh=True)
        return zaloha
    STORE.cached_if(key, FORYOU_TTL, lambda: {"seeds": seeds, "items": items}, fresh=True)
    return items


def verify_refresh(apis, target="", size=8, pool_only=False):
    """Ověří `size` nejpotřebnějších titulů ověřovaného vlastního katalogu `target` (volá služba přes
    `action=verify_refresh`); bez UI, bez modálu. `pool_only` = jen obnova kandidátů (zařízení s cizími výsledky).
    Cíl `concerts` = modul Koncerty (`concertcat.refresh`).

    Služba ji volá po jednom titulu s odstupem: plugin běží v jednom interpretu (reuse invoker), takže dlouhý
    běh by držel všechna ostatní kliknutí v menu, dokud nedoběhne."""
    try:
        if should_stop():
            return
        if target == CONCERTS:
            concertcat.refresh(engine_of(apis), STORE, size, should_stop=should_stop)
        else:
            mycat.refresh(engine_of(apis), STORE, apis.get("dash"), target, size, verify=not pool_only,
                          should_stop=should_stop)
    except Errors as e:
        log_error(f"verify_refresh {target}: {e}")
    finally:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)


def list_foryou(apis, ctype):
    """„Pro tebe" — doporučení k tomu, co uživatel dokoukal naposledy.

    Kreslení menu tohle nezdrží: položka v `browse_menu()` je obyčejná složka a
    počítá se až tady, po vstupu do ní."""
    note_foryou_open(ctype)
    set_content("tvshows" if ctype == "series" else "movies")
    seeds = foryou_seeds(apis, ctype)
    items = foryou_items(apis, ctype, seeds) if seeds else []
    names = foryou_seed_names(seeds) if items else {}
    rate(items, ctype)
    for m in items:
        because = names.get(m.get("_because") or "")
        if because:
            popis = Lf(30606, because)
            m = dict(m, description=f"{popis}\n\n{m.get('description') or ''}".strip())
        add_meta_item(m, ctype)
    if not items:
        # notifikace, ne modál — sem se dá dostat i z widgetu a z JSON-RPC
        notify(L(30607, "Zatím není z čeho doporučovat – seznam vzniká z naposledy zhlédnutých titulů."),
               xbmcgui.NOTIFICATION_INFO, 4000)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def random_source(apis, ctype):
    """Odkud losovat: TMDB s vlastním klíčem, jinak Luna, jinak Cinemeta — stejné
    pořadí jako v `browse_menu()`."""
    kind = "series" if ctype == "series" else "movie"
    if apis.get("tmdb") is not None:
        return "tmdb", "popular"
    if apis.get("luna") is not None:
        return "luna", f"tmdb.top_{kind}"
    if apis.get("cinemeta") is not None:
        return "cinemeta", "top"
    return None, None


def random_candidates(apis, ctype):
    """Kandidáti na náhodný titul a žánr, ve kterém se losovalo (prázdný = losovalo se ze všeho).

    Žánr je vážený tím, co uživatel viděl (`foryou.pick_genre`) — kdo kouká hlavně
    komedie, dostane spíš komedii, ale ne pokaždé. Bere se jen ze žánrů, které zdroj
    sám nabízí: snímky mají žánry tak, jak je vrátil zdroj (TMDB česky, Luna
    a Cinemeta anglicky), a cizí slovo by katalog nenašel.

    Stránka se losuje taky (`FORYOU_PAGES`), jinak by se pořád vybíralo z týchž
    dvaceti nejpopulárnějších."""
    src, cid = random_source(apis, ctype)
    if not src:
        return [], ""
    api = apis[src]
    nabidka = set(next((c.get("genres") or [] for c in api.catalogs(ctype) if c["id"] == cid), []))
    snaps = [STORE.item(key) for key, _entry in STORE.recently_watched()]
    counts = {g: n for g, n in foryou.genre_counts(snaps).items() if g in nabidka}
    genre = foryou.pick_genre(counts)
    skip = PAGE * random.randrange(FORYOU_PAGES)
    metas = api.catalog(ctype, cid, genre=genre, skip=skip) or []
    if not metas and (genre or skip):
        genre, metas = "", (api.catalog(ctype, cid) or [])
    videne = foryou.known_ids(STORE.recently_watched(limit=WATCHED_MAX))
    volba = [m for m in metas if m.get("id") not in videne] or metas
    return volba, (genre or "")


def has_pref_lang(streams, pref):
    """Má některý stream preferovaný jazyk ve zvuku, nebo titulky v něm (či v náhradním
    jazyce, CZ ↔ SK — `SUBTITLE_FALLBACK`)? Jazyk odhadnutý z názvu souboru se počítá."""
    subs_ok = set(SUBTITLE_FALLBACK.get(pref, (pref,)))
    for s in streams:
        if pref in (s.get("langs") or []) or subs_ok & set(s.get("subs") or []):
            return True
    return False


def random_by_language(apis, ctype, candidates, pref):
    """První z náhodně vybraných kandidátů, který má `pref` ve zvuku nebo titulcích.

    Kandidáti se ověřují souběžně stejným lehkým hledáním jako jazykové katalogy
    (`raw_streams(probe_audio=False)`, bez čtení hlaviček) a výsledek zůstává v cache
    streamů, takže dialog vybraného titulu naběhne hned. Celé ověřování má strop
    `RANDOM_BUDGET_S`; nikdo nevyhověl (nebo nestihl) = `(None, False)`."""
    engine = engine_of(apis)
    cands = random.sample(candidates, min(RANDOM_CANDIDATES, len(candidates)))

    t0 = time.time()

    def check(cand):
        try:
            streams = engine.raw_streams(cand.get("type") or ctype, cand["id"], strict=True, probe_audio=False)
            ok = has_pref_lang(streams, pref)
            xbmc.log(f"[{ADDON_ID}] náhodný titul: {cand['id']} {'má' if ok else 'nemá'} {pref} "
                     f"({len(streams)} streamů, {time.time() - t0:.1f} s)", xbmc.LOGINFO)
            return ok
        except Exception as e:  # noqa: BLE001 – výpadek u jednoho kandidáta nesmí shodit losování
            log_error(f"náhodný titul, {cand.get('id')}: {e}")
            return False

    from concurrent.futures import FIRST_COMPLETED, wait as wait_futures
    pool = ThreadPoolExecutor(max_workers=RANDOM_WORKERS)
    futures = {pool.submit(check, c): c for c in cands}
    pending = set(futures)
    deadline = time.time() + RANDOM_BUDGET_S
    # neblokující ukazatel, ne modál — sem se dá dostat i z widgetu a z JSON-RPC
    bar = xbmcgui.DialogProgressBG()
    bar.create(L(30000, "Nokturno"), L(30660, "Looking for a title in your preferred language…"))
    try:
        while pending:
            if should_stop():
                raise Aborted()
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            done, pending = wait_futures(pending, timeout=min(remaining, 0.5), return_when=FIRST_COMPLETED)
            for f in done:
                if f.result():
                    return futures[f], True
        xbmc.log(f"[{ADDON_ID}] náhodný titul: žádný z {len(cands)} kandidátů nevyhověl", xbmc.LOGINFO)
    finally:
        bar.close()
        for f in pending:
            f.cancel()
        pool.shutdown(wait=False)
    return None, False


def random_pick(apis, ctype):
    """Náhodný titul (s preferovaným jazykem, když se ho podaří najít) a žánr; viz `random_choose`."""
    meta, genre, _ok = random_choose(apis, ctype)
    return meta, genre


def random_choose(apis, ctype):
    """`(titul, žánr, má_jazyk)`. Bez preferovaného jazyka (nastavení „Žádný") se neověřuje
    a `má_jazyk` je True; jinak se hledá titul s `pref_lang` a když žádný nevyhoví, vezme se
    prostě první vylosovaný a `má_jazyk` je False."""
    volba, genre = random_candidates(apis, ctype)
    if not volba:
        return None, genre, True
    pref = PREF_LANGS[int(setting("pref_lang", "0"))]
    if pref:
        meta, ok = random_by_language(apis, ctype, volba, pref)
        if ok:
            return meta, genre, True
        return random.choice(volba), genre, False
    return random.choice(volba), genre, True


def random_title(apis, ctype):
    """„Náhodný film" / „Náhodný seriál": vylosuje titul a otevře nad ním výběr streamu.

    Položka je ve výpisu ne-složka, takže klik ji Kodi spustí jako skript s handle −1
    (dialog), kdežto Přehrát ze skinu ji rozklíčovává s handle ≥ 0 (`setResolvedUrl`) —
    stejné rozdělení jako u titulu v režimu seznamu (5.2.7~beta20). Výpis se tu nikdy
    nekreslí, takže widget ani JSON-RPC žádný dialog neotevřou."""
    try:
        meta, genre, has_lang = random_choose(apis, ctype)
    except Errors as e:
        log_error(f"náhodný titul: {e}")
        meta, genre, has_lang = None, "", True
    if meta is None:
        notify(L(30610, "Není z čeho losovat"), xbmcgui.NOTIFICATION_WARNING, 4000)
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    jmeno = display_name(meta)
    if genre:
        jmeno = f"{jmeno} · {genre}"
    if not has_lang:
        jmeno += " · " + L(30659, "no preferred language")
    notify(jmeno, xbmcgui.NOTIFICATION_INFO, 4000)
    if HANDLE < 0:
        pick_title(apis, ctype, meta["id"])
    else:
        play(apis, ctype, meta["id"], ask="1")


def list_similar(apis, ctype, item_id):
    """Podobné tituly: s vlastním TMDB klíčem přímo z TMDB, bez něj (nebo při jeho chybě)
    z dashboardu, který se na TMDB ptá za doplněk."""
    ctype = "series" if ctype == "series" else "movie"
    items = []
    tmdb = apis.get("tmdb")
    if tmdb is not None:
        try:
            items = tmdb.similar(ctype, item_id)
        except TmdbError as e:
            log_error(e)
            items = []
    if not items and apis.get("dash") is not None:
        items = apis["dash"].similar(ctype, item_id)
    set_content("tvshows" if ctype == "series" else "movies")
    if not items:
        notify(L(30493, "Žádné podobné tituly"), xbmcgui.NOTIFICATION_INFO, 3000)
    rate(items, ctype)
    for m in items:
        add_meta_item(m, ctype)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


TV_KINDS = ("", "movie", "series")


def tv_day_label(day, today):
    """`2026-09-18` → „Zítra (pá 18. 9.)“ — dny v týdnu z řetězce 30491 (lokalizace bez locale)."""
    import datetime
    try:
        d = datetime.date(*map(int, day.split("-")))
        t = datetime.date(*map(int, (today or day).split("-")))
    except (ValueError, AttributeError):
        return day or ""
    names = L(30491, "Mon,Tue,Wed,Thu,Fri,Sat,Sun").split(",")
    short = f"{names[d.weekday()] if len(names) == 7 else ''} {d.day}. {d.month}.".strip()
    rel = {0: L(30489, "Dnes"), 1: L(30490, "Zítra")}.get((d - t).days)
    return f"{rel} ({short})" if rel else short


def tv_url(day="", kind="", channel=""):
    return build_url(action="tv", date=day or None, kind=kind or None, channel=channel or None)


def list_tv(apis, day="", kind="", channel=""):
    """TV program: filmy a seriály, které dnes (nebo jiný den) dávají v české a slovenské
    televizi a které server spároval s TMDB. Nahoře tři volby (den, stanice, typ) jako
    ne-složky — klik je spustí se handle −1 (`action=tv_pick`, výběr v dialogu), takže
    výpis sám, widget ani JSON-RPC žádný dialog neotevře."""
    dash = apis.get("dash")
    data = dash.tv_program(day or None, kind or None, channel or None) if dash else None
    set_content("movies")
    if not data:
        notify(L(30492, "TV program teď není dostupný"), xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    day = data.get("date") or day
    channel_name = next((c["name"] for c in data["channels"] if c["slug"] == channel), "") or L(30487, "Všechny stanice")
    kind_name = {"": L(30488, "Filmy i seriály"), "movie": L(30012), "series": L(30013)}.get(kind, "")
    picks = (
        ("day", f"{L(30484, 'Den')}: {tv_day_label(day, data.get('today'))}", "DefaultYear.png"),
        ("channel", f"{L(30485, 'Stanice')}: {channel_name}", "DefaultAddonPVRClient.png"),
        ("kind", f"{L(30486, 'Typ')}: {kind_name}", "DefaultGenre.png"),
    )
    if day == data.get("today"):   # dnes: přepínač skončených pořadů úplně první
        state = L(30585, "ukázané") if on("tv_show_ended", "false") else L(30586, "skryté")
        picks = (("ended", f"{L(30584, 'Skončené pořady')}: {state}", "DefaultInProgressShows.png"),) + picks
    for field, label, icon in picks:
        li = xbmcgui.ListItem(label=f"[B]{label}[/B]")
        li.setArt({"icon": icon})
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="tv_pick", field=field, date=day or None,
                                                      kind=kind or None, channel=channel or None),
                                    li, isFolder=False)
    now = time.time()
    shown = 0
    for it in data["items"]:
        if day == data.get("today") and it["stop"] < now and not on("tv_show_ended", "false"):
            continue   # dnes už skončené pořady jen zabírají místo
        start = time.strftime("%H:%M", time.localtime(it["start"]))
        live = it["start"] <= now < it["stop"]
        clock = f"[COLOR {LANG_COLORS.get('CZ', 'FFFFC94D')}]{start}[/COLOR]" if live else start
        name = display_name(it["meta"]) if it["kind"] == "movie" else (it["meta"].get("name") or it["title"])
        if it["kind"] == "series" and it.get("season") is not None and it.get("episode") is not None:
            name = f"{name} {int(it['season'])}x{int(it['episode']):02d}"
        if it.get("episode_title"):
            name = f"{name} {it['episode_title']}"
        label = f"{clock}  [COLOR {GREY}]{it['channel_name']}[/COLOR]  {name}"
        add_meta_item(it["meta"], it["kind"], label=label)
        shown += 1
    if not shown:
        li = xbmcgui.ListItem(label=f"[COLOR {GREY}]{L(30494, 'V tomto výběru nejsou žádné pořady')}[/COLOR]")
        xbmcplugin.addDirectoryItem(HANDLE, tv_url(day, kind, channel), li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def tv_pick(apis, field, day="", kind="", channel=""):
    """Klik na volbu nad TV programem (handle −1, jen z výpisu Nokturna) → dialog → přepnout výpis."""
    data = apis["dash"].tv_program(day or None, kind or None, channel or None) or {}
    if field == "ended":
        ADDON.setSetting("tv_show_ended", "false" if on("tv_show_ended", "false") else "true")
    elif field == "day":
        dates = data.get("dates") or []
        if not dates:
            return
        idx = xbmcgui.Dialog().select(L(30484, "Den"), [tv_day_label(d, data.get("today")) for d in dates],
                                      preselect=dates.index(day) if day in dates else 0)
        if idx < 0:
            return
        day = dates[idx]
    elif field == "channel":
        channels = [{"slug": "", "name": L(30487, "Všechny stanice")}] + (data.get("channels") or [])
        slugs = [c["slug"] for c in channels]
        idx = xbmcgui.Dialog().select(L(30485, "Stanice"), [c["name"] for c in channels],
                                      preselect=slugs.index(channel) if channel in slugs else 0)
        if idx < 0:
            return
        channel = slugs[idx]
    else:
        names = [L(30488, "Filmy i seriály"), L(30012), L(30013)]
        idx = xbmcgui.Dialog().select(L(30486, "Typ"), names,
                                      preselect=TV_KINDS.index(kind) if kind in TV_KINDS else 0)
        if idx < 0:
            return
        kind = TV_KINDS[idx]
    xbmc.executebuiltin(f"Container.Update({tv_url(day, kind, channel)},replace)")


# --- přehrávání ------------------------------------------------------------------

def upnext_episode(meta, v, series_id):
    """Popis dílu ve tvaru, jaký čeká služba Up Next (service.upnext)."""
    art = art_for(meta, v)
    ep_id = v.get("id") or f"{series_id}:{int(v.get('season') or 0)}:{int(v.get('episode') or 0)}"
    runtime = runtime_minutes(v.get("runtime") or meta.get("runtime"))
    return {
        "episodeid": ep_id,
        "tvshowid": series_id,
        "title": v.get("title") or "",
        "art": {
            "thumb": art.get("thumb", ""),
            "tvshow.poster": art.get("poster", ""),
            "tvshow.fanart": art.get("fanart", ""),
            "tvshow.landscape": art.get("landscape", ""),
            "tvshow.clearlogo": art.get("clearlogo", ""),
            "tvshow.clearart": "",
        },
        "season": int(v.get("season") or 0),
        "episode": int(v.get("episode") or 0),
        "showtitle": meta.get("_title") or meta.get("name") or "",
        "plot": v.get("overview") or v.get("description") or "",
        "playcount": 1 if STORE.playcount(ep_id) else 0,
        "rating": str(meta.get("imdbRating") or ""),
        "firstaired": str(v.get("released") or "")[:10],
        "runtime": runtime * 60,
    }, ep_id


def upnext_notify(meta, video, series_id, alt=None):
    """Oznámí službě Up Next (je-li nainstalovaná) následující díl, aby ke konci
    epizody nabídla „Další díl“ a uměla ho pustit zase přes tenhle plugin.

    Up Next čeká signál `upnext_data` (JSONRPC.NotifyAll, payload base64 JSON) —
    stejný formát posílá i modul AddonSignals, ten ale kvůli jednomu volání netaháme.
    """
    if not xbmc.getCondVisibility("System.HasAddon(service.upnext)"):
        return
    videos = [v for v in meta.get("videos") or [] if v.get("episode") is not None]
    # speciály (sezóna 0) až na konec, jinak podle sezóny a čísla dílu
    videos.sort(key=lambda v: (int(v.get("season") or 0) == 0, int(v.get("season") or 0), int(v.get("episode") or 0)))
    cur = (int(video.get("season") or 0), int(video.get("episode") or 0))
    idx = next((i for i, v in enumerate(videos)
                if (int(v.get("season") or 0), int(v.get("episode") or 0)) == cur), None)
    if idx is None or idx + 1 >= len(videos):
        return
    current, _ = upnext_episode(meta, video, series_id)
    following, next_id = upnext_episode(meta, videos[idx + 1], series_id)
    payload = {
        "current_episode": current,
        "next_episode": following,
        "play_url": build_url(action="play", type="series", id=next_id, series=series_id, alt=alt),
    }
    encoded = base64.b64encode(json.dumps(payload).encode("utf-8")).decode("ascii")
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "JSONRPC.NotifyAll", "params": {
        "sender": f"{ADDON_ID}.SIGNAL", "message": "upnext_data", "data": [encoded]}}))


def pick_title(apis, ctype, item_id, series_id=None, alt=None, fulltext=False, download=False, fresh=False):
    """Klik na titul ve výpisu Nokturna (handle −1, viz `add_playable`) i „Vybrat stream“ v kontextovém
    menu: najít streamy s ukazatelem průběhu v rohu (`DialogProgressBG`), ukázat dialog a vybraný stream
    pustit přes `PlayMedia` s jeho referencí — `play()` ji jen rozklíčuje a zapamatuje volbu u seriálu.
    `fresh=True` (kontextové menu) = streamy se hledají znovu bez cache zdrojů (`raw_streams(refresh=True)`).
    Modál je tu v pořádku: tuhle cestu spouští jen klik uživatele, widget ani JSON-RPC položku
    `action=title` nerozklíčují jako skript.

    Přísný filtr fulltextových zdrojů (`Engine._title_queries`) může skutečnou shodu zahodit kvůli
    neobvyklému názvu souboru: bez výsledku se rovnou zkusí uvolněný, s výsledky ho nabídne dialog.

    `download=True` („Stáhnout“ v kontextovém menu): stejný dialog, vybraný stream jde do fronty
    stahování (`download_stream`) místo přehrání. Bez složky pro stahování se nic nehledá."""
    if download and not download_dir():
        return
    meta, video = load_meta(apis, ctype, item_id, series_id)
    has_fulltext_source = bool(apis.get("ws") or apis.get("hs") or apis.get("st") or apis.get("fs")
                               or apis.get("pt"))

    def collect(strict, meta=meta):
        bar = xbmcgui.DialogProgressBG()   # načítání jen ukazatelem v rohu, modální je až výběr streamu
        bar.create(L(30000, "Nokturno"), L(30238, "Načítám streamy…"))
        errors = []
        try:
            found = collect_streams(apis, ctype, item_id, meta, alt,
                                    SearchProgress(bar, Engine.STREAM_SOURCE_STEPS + AUDIO_PROBE_MAX), strict, errors,
                                    refresh=fresh)
        finally:
            bar.close()
        if download:
            # CZtor stahování povoluje jen u části streamů (`allow_download`) — ostatní se ke stažení nenabízí
            found = [s for s in found if not s.get("_no_download")]
        if errors:
            notify(skipped_notice(errors), xbmcgui.NOTIFICATION_WARNING, 7000)
        return found, errors

    strict = not fulltext
    streams, errors = collect(strict)
    if not fulltext:
        year = str(meta.get("year") or meta.get("releaseInfo") or "")[:4]
        mark_viewed(item_id, bare_title(meta), year if year.isdigit() else None, "series" if video else ctype)
    if not streams and strict and has_fulltext_source:
        strict = False
        streams, errors = collect(strict)
    if not streams:
        if not errors:
            notify(L(30102))
        # nic nenašel ani uvolněný filtr: nabídnout hledání pod jiným názvem (fulltext zdrojů hledá
        # v názvech souborů, ty mívají jiný název než TMDB — u seriálu doplní SxxEyy engine sám)
        if has_fulltext_source and xbmcgui.Dialog().yesno(
                L(30577, "Žádný stream nenalezen"),
                L(30578, "Zkusit hledat pod jiným názvem?[CR]Zadaný název se hledá fulltextem ve zdrojích "
                         "(u dílu seriálu se přidá číslo série a dílu).")):
            typed = xbmcgui.Dialog().input(L(30579, "Název pro hledání"), defaultt=str(
                meta.get("_title") or meta.get("name") or "")).strip()
            if typed:
                streams, errors = collect(False, dict(meta, _title=typed, name=typed))
        if not streams:
            if not download and not errors:
                offer_watch(meta, ctype, item_id, video, series_id, alt)
            return
    pref_key = (series_id or split_episode_id(item_id)[0]) if video else None
    remembered = preferred_stream(streams, STORE.stream_pref(pref_key)) if pref_key else None
    picked = choose_stream(streams, remembered, relax=strict and has_fulltext_source,
                           expand=lambda: expand_streams(apis, streams, meta, video),
                           refresh=engine_of(apis).refresh_media)
    if picked == FULLTEXT:
        pick_title(apis, ctype, item_id, series_id, alt, fulltext=True, download=download, fresh=fresh)
        return
    if picked is None:
        return
    if download:
        title = (video or {}).get("title") or display_name(meta)
        download_stream(apis, picked["url"], f"{title} [{picked['label']}]", item_id, ctype, series_id, alt)
        return
    xbmc.executebuiltin("PlayMedia(%s)" % build_url(
        action="play", type=ctype, id=item_id, series=series_id, alt=alt, url=picked["url"],
        subs="|".join(picked.get("subtitles") or []), pref=pref_param(picked), alts=alts_param(picked)))


def play(apis, ctype, item_id, series_id=None, url=None, alt=None, subs="", pref="", ask="", alts="", sw=""):
    """`ask=1` = Přehrát nad položkou Nokturna (detail, widget) nebo player TMDb Helperu → výběr
    v dialogu (`choose_stream`, zapamatovaný stream předvybraný). Bez `ask` (Up Next, HA) hraje
    zapamatovaný nebo nejlepší stream bez ptaní."""
    meta, video = load_meta(apis, ctype, item_id, series_id)
    # u seriálu si pamatujeme, jaký stream si uživatel vybral — další díl (Up Next,
    # Pokračovat, widget) pak jede stejně bez ptaní; klíč je seriál, ne díl
    pref_key = (series_id or split_episode_id(item_id)[0]) if video else None
    resolved_path = None
    streams = []
    if url:
        try:
            # sloučené verze (`alts`) jsou tentýž film jinde — zkusí se, než se hledá znovu
            # u SyncWatch jen tentýž soubor, `alts` se ignorují
            same_urls = [url] + [a for a in (alts or "").split("|") if a and not sw]
            url, resolved_path = resolve_first(apis, same_urls, same=len(same_urls))
        except Errors as e:
            if sw:
                # SyncWatch: jen přesně tentýž stream jako vedoucí (stejná kvalita, zvuk i délka),
                # jiný soubor by se rozjel — žádné hledání ani náhrada z jiného zdroje
                xbmc.log(f"[{ADDON_ID}] SyncWatch: stream vedoucího nejde přehrát: {e}", xbmc.LOGWARNING)
                notify(Lf(30834, str(e) or L(30102)), xbmcgui.NOTIFICATION_ERROR, 8000)
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return
            # uložená reference streamu (Pokračovat ve sledování, viz add_playable) nebo dřív
            # vybraný stream ze seznamu mezitím zmizely ze zdroje — vzít to jako by url vůbec
            # nepřišla a normálně prohledat všechny zdroje znovu, ne rovnou ukázat chybu
            xbmc.log(f"[{ADDON_ID}] uložený stream nejde přehrát, hledám znovu: {e}", xbmc.LOGINFO)
            url = None
        else:
            chosen = {"url": url, "subtitles": [s for s in subs.split("|") if s]}
            if pref_key and pref_from_param(pref):
                STORE.set_stream_pref(pref_key, pref_from_param(pref))
    if not url:
        errors = []
        # z přehrání (widget, TMDb Helper) je jinak vidět jen točící se kolečko Kodi — streamy se
        # načítají i 15 s, tak aspoň stejný průběh jako nad seznamem streamů. NE modální
        # DialogProgress — tahle cesta se spouští z widgetu, TMDb Helperu i JSON-RPC (CLAUDE.md:
        # „nikdy modální dialog v cestě, kterou může spustit widget nebo JSON-RPC“), a modální
        # dialog v tomhle přehrávacím kontextu přehrání buď spadlo, nebo se nic nezobrazilo
        # (Office 2026-09-16, nahlásil uživatel po zavedení cancelable_search v betě 7).
        # Zpět tu tedy hledání nezruší.
        bar = xbmcgui.DialogProgressBG()
        bar.create(L(30000, "Nokturno"), L(30238, "Načítám streamy…"))
        try:
            streams = collect_streams(apis, ctype, item_id, meta, alt,
                                      SearchProgress(bar, Engine.STREAM_SOURCE_STEPS + AUDIO_PROBE_MAX), errors=errors)
        finally:
            bar.close()
        dead = engine_of(apis).last_timings.get("nedostupné")
        if errors:
            text = skipped_notice(errors)
            if dead:
                text = f"{text} · {Lf(30741, dead)}"
            notify(text, xbmcgui.NOTIFICATION_WARNING, 7000)
        elif dead:
            notify(Lf(30741, dead), xbmcgui.NOTIFICATION_WARNING, 7000)
        if not streams:
            if not errors:
                notify(L(30102))
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            # modál tu nesmí (přehrávací kontext), tak ho otevře samostatný skript až po neúspěšném
            # přehrání: dialog „hledat pod jiným názvem“ / uvolněné hledání (`pick_title`).
            # Jen po kliku ve výpisu Nokturna — přehrání z widgetu Pokračovat, z karty HA nebo
            # z TMDb Helperu by jinak vyhodilo dialog, na který nikdo neodpoví (a zamklo vypínání)
            if browsing_nokturno():
                xbmc.executebuiltin("RunPlugin(%s)" % build_url(action="title", type=ctype, id=item_id,
                                                                series=series_id, alt=alt, fulltext="1"))
            return
        remembered = preferred_stream(streams, STORE.stream_pref(pref_key)) if pref_key else None
        chosen = remembered or streams[0]
        if ask and not sw:
            picked = choose_stream(streams, remembered, expand=lambda: expand_streams(apis, streams, meta, video),
                                   refresh=engine_of(apis).refresh_media)
            if picked is None:
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return
            chosen = picked
            if pref_key:
                STORE.set_stream_pref(pref_key, stream_signature(chosen))
    title = (video or {}).get("title") or display_name(meta)
    # label i InfoTag: při přímém otevření (JSON-RPC, widgety) nemá Kodi původní položku seznamu
    if not resolved_path:
        # nejen zvolený stream a jeho sloučené kopie, ale i další nálezy — viz PLAY_FALLBACKS
        poradi = play_candidates(chosen, streams)
        used, resolved_path = resolve_first(apis, [u for u, _ in poradi], same=len(version_urls(chosen)))
        if used != chosen["url"]:
            chosen = next(s for u, s in poradi if u == used)
    li = xbmcgui.ListItem(label=title, path=resolved_path)
    li.setArt(art_for(meta, video))
    fill_info(li, meta, "series" if video else ctype, video=video)
    # bez tohohle Kodi u přímého přehrání (HA karta, widget, Up Next) nevědělo o rozkoukanosti
    # a vždycky pustilo od začátku — resume point se jinak nastavuje jen v seznamech (`apply_watched`)
    tag = li.getVideoInfoTag()
    count = STORE.playcount(item_id)
    if count:
        tag.setPlaycount(count)
    # SyncWatch: pozici určuje skupina, ne historie tohohle zařízení
    resume, total = STORE.resume(item_id) if not sw else (0, 0)
    from_start = bool(resume) and not count and chose_from_start()
    xbmc.log(f"[{ADDON_ID}] play resume: argv3={sys.argv[3] if len(sys.argv) > 3 else '-'} "
             f"resumable={xbmc.getCondVisibility('ListItem.IsResumable')} "
             f"focused={xbmc.getInfoLabel('ListItem.FileNameAndPath')[:120]!r} "
             f"stored={resume:.0f}/{total:.0f} from_start={from_start}", xbmc.LOGINFO)
    if resume and not count and not from_start:
        try:
            tag.setResumePoint(resume, total)
        except Exception:  # noqa: BLE001 – Kodi < 20
            pass
    subtitles = local_subtitles(apis, subtitle_refs(apis, chosen, resolved_path, video, ctype))
    if subtitles:
        li.setSubtitles(subtitles)
    STORE.remember_item(item_id, snapshot(meta, ctype, video, series_id, alt))
    year = str(meta.get("year") or meta.get("releaseInfo") or "")[:4]
    # bez roku – ten se posílá zvlášť polem `year`, display_name() by ho zdvojil
    stats_title = episode_stats_title(video, meta)
    # SyncWatch: ostatním jen přesně tentýž stream — stejná kvalita, zvuk i délka; jiná verze
    # (ani sloučená kopie) by se rozjela, proto žádné `alts`
    replay = sw_replay(action="play", type=ctype, id=item_id, series=series_id, alt=alt, url=chosen.get("url"),
                       subs="|".join(chosen.get("subtitles") or []))
    mark_playing(item_id, stats_title, year if year.isdigit() else None, "series" if video else ctype,
                stream_url=chosen.get("url"), stream_subs="|".join(chosen.get("subtitles") or []),
                stream_langs=list(chosen.get("langs") or []), replay=replay,
                # soubor se rozklíčoval, ale nerozjel (mrtvý odkaz) – služba pak otevře výběr streamu
                pick=None if sw else build_url(action="title", type=ctype, id=item_id, series=series_id, alt=alt))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    if video and not sw:
        upnext_notify(meta, video, series_id or split_episode_id(item_id)[0], alt)


def play_ws(apis, ident, name=""):
    api = apis["ws"]
    if api is None:
        raise WebshareError(L(30104))
    link = api.file_link(ident)
    remember_ws_token(api)
    if not link:
        notify(L(30102))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(label=name or ident, path=link)
    li.getVideoInfoTag().setTitle(name or ident)
    STORE.remember_item("ws:" + ident, {"type": "ws", "id": "ws:" + ident, "title": name or ident, "art": {}})
    mark_playing("ws:" + ident, name, kind="ws", replay=sw_replay(action="play_ws", ident=ident, name=name))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def play_dav(apis, slot, path, name=""):
    key = f"dav:{slot}:{path}"
    replay = sw_replay(action="play_dav", slot=slot, path=path, name=name)
    api, path = storage_for(apis, key)
    li = xbmcgui.ListItem(label=name or path, path=api.kodi_url(path))
    li.getVideoInfoTag().setTitle(name or path)
    mark_playing(key, name, kind="dav", replay=replay)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    # plakát a popis do snímku pro Pokračovat/Naposledy; až po spuštění přehrávání, hledání smí chvíli trvat
    snap = {"type": "dav", "id": key, "title": name or path, "art": {}}
    try:
        meta = dav_titles(apis, [{"path": path}], deadline=4).get(path)
    except Exception:  # noqa: BLE001 – popis je navíc, snímek se uloží i bez něj
        meta = None
    if meta:
        snap.update(art=art_for(meta, None), plot=meta.get("description") or "",
                    year=str(meta.get("year") or "")[:4])
    STORE.remember_item(key, snap)


def play_hs(apis, file_id, file_hash, name=""):
    api = apis.get("hs") or HellspyApi(cache=STORE)
    key = f"hs:{file_id}:{file_hash}"
    link = api.file_link(file_id, file_hash)
    if not link:
        notify(L(30102))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(label=name or key, path=link)
    li.getVideoInfoTag().setTitle(name or key)
    STORE.remember_item(key, {"type": "hs", "id": key, "title": name or key, "art": {}})
    mark_playing(key, name, kind="hs", replay=sw_replay(action="play_hs", id=file_id, hash=file_hash, name=name))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# --- stahování ---------------------------------------------------------------------

def download_dir():
    d = setting("download_dir")
    if not d:
        notify(L(30076), xbmcgui.NOTIFICATION_WARNING, 6000)
        return None
    return xbmcvfs.translatePath(d)


def safe_filename(name):
    import re
    name = re.sub(r"[\\/:*?\"<>|]+", "_", name or "").strip(" _.") or "video"
    return name[:150]


VIDEO_EXTS = (".mkv", ".mp4", ".avi", ".ts", ".mov", ".m4v", ".webm", ".wmv")


def strip_inner_ext(name):
    """Popisek „Díl [soubor.mkv]“ (CZtor a spol. mají název souboru v hranaté závorce) —
    přípona uvnitř závorky pryč, jinak cílový soubor dostal `….mkv].mkv`."""
    low = name.lower()
    for ext in VIDEO_EXTS:
        if low.endswith(ext + "]"):
            return name[:-len(ext) - 1] + "]"
    return name


def guess_ext(url, name):
    for ext in VIDEO_EXTS:
        if name.lower().endswith(ext):
            return ""
        if url.lower().split("?")[0].endswith(ext):
            return ext
    return ".mkv"


def enqueue_download(url, name, key, dest_name=None, link=None):
    """Do fronty jde VNITŘNÍ odkaz (`ws:`, `hs:`, `st:`, `fs:`, `cz:`, `pt:`, `streamuj:`, `dav:`) — služba ho
    rozklíčuje až ve chvíli stahování (`service.resolve_internal`). Hotový odkaz WebShare
    vyprší za pár hodin: třetí soubor ve frontě nebo cokoli po restartu Kodi dřív končilo
    chybou. `link` je volitelný už rozklíčovaný odkaz jen kvůli odhadu přípony."""
    d = download_dir()
    if not d:
        return
    base = safe_filename(strip_inner_ext(dest_name or name))
    dest = os.path.join(d, base + guess_ext(link or url, base))
    entry = {"id": key, "url": url, "name": name, "dest": dest}
    if STORE.add_download(entry):
        notify(Lf(30072, name))
    else:
        notify(L(30077))


def download_stream(apis, url, name, key, ctype, series_id=None, alt=None):
    if thin_snapshot(STORE.item(key)) or not STORE.item(key):
        try:
            meta, video = load_meta(apis, ctype, key, series_id)
            STORE.remember_item(key, snapshot(meta, ctype, video, series_id, alt))
        except Errors:
            pass
    # id z hashlib: `hash(str)` je náhodně seedovaný per proces, takže tentýž soubor
    # dostal po restartu Kodi jiné id a dedup ve frontě ho stáhl podruhé
    import hashlib
    dl_id = f"dl:{key}:{hashlib.sha1(url.encode('utf-8')).hexdigest()[:8]}"
    # rozklíčovat jen kvůli příponě, když ji název nemá (Luna/Sosáč mají místo názvu popisek)
    # u CZtor se přehrávací adresa nevolá jen kvůli příponě — adresa ke stažení se bere až ve službě
    link = None if name.lower().endswith(VIDEO_EXTS) or url.startswith("cz:") else resolve_url(apis, url)
    enqueue_download(url, name, dl_id, dest_name=name, link=link)


def download_ws(apis, ident, name):
    api = apis["ws"]
    if api is None:
        raise WebshareError(L(30104))
    link = api.file_link(ident)   # ověření, že soubor existuje; stahuje se až z fronty
    remember_ws_token(api)
    if not link:
        notify(L(30102))
        return
    enqueue_download("ws:" + ident, name, f"dl:ws:{ident}", dest_name=name, link=link)


def download_hs(apis, file_id, file_hash, name):
    api = apis.get("hs") or HellspyApi(cache=STORE)
    link = api.file_link(file_id, file_hash)
    if not link:
        notify(L(30102))
        return
    enqueue_download(f"hs:{file_id}:{file_hash}", name, f"dl:hs:{file_id}", dest_name=name, link=link)


def list_downloads():
    # jen režim Home Assistant — soubory stahuje a podepsané odkazy vydává HA,
    # slepý relay žádné nemá (a „adresa“ v jeho nastavení není server, jen značka)
    if sync_settings() and not sync_via_relay():
        folder_item(L(30190, "Staženo v HA"), build_url(action="ha_files"), icon="DefaultNetwork.png",
                    info=L(31100, "Soubory, které stáhl Home Assistant. Přehraješ je přímo odsud."))
    set_content("videos")
    status_labels = {"queued": L(30078), "running": L(30079), "done": L(30080), "error": L(30081), "cancel": L(30082)}
    for d in STORE.downloads():
        status = d.get("status")
        pct = int(d.get("done", 0) * 100 / d["size"]) if d.get("size") else 0
        detail = f"{status_labels.get(status, status)}"
        if status == "running":
            detail += f" {pct} % · {human_size(d.get('done', 0))} / {human_size(d.get('size', 0))}"
        elif status == "done":
            detail += f" · {human_size(d.get('size', 0))}"
        elif status == "error":
            detail += f" · {d.get('error', '')[:60]}"
        li = xbmcgui.ListItem(label=f"{d.get('name', '')}  [COLOR FF9A9A9A]{detail}[/COLOR]")
        tag = li.getVideoInfoTag()
        tag.setMediaType("video")
        tag.setTitle(d.get("name", ""))
        tag.setPlot(d.get("dest", ""))
        # "done" fakticky maže soubor z disku (po potvrzení, viz download_remove) — "Odebrat ze
        # seznamu" by tam matlo, že zůstane ležet na kartě (nahlásil uživatel 2026-09-18)
        if status in ("queued", "running"):
            remove_label = L(30083)
        elif status == "done":
            remove_label = L(30516, "Delete")
        else:
            remove_label = L(30084)
        ctx = [(remove_label, runplugin(action="download_remove", id=d["id"]))]
        if status == "error":
            ctx.append((L(30085), runplugin(action="download_retry", id=d["id"])))
        li.addContextMenuItems(ctx)
        if status == "done" and os.path.exists(d.get("dest", "")):
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(HANDLE, d["dest"], li, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action="downloads"), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def download_remove(dl_id):
    d = next((x for x in STORE.downloads() if x.get("id") == dl_id), None)
    if not d:
        return
    if d.get("status") == "running":
        STORE.update_download(dl_id, status="cancel")  # služba smaže .part i záznam
    else:
        if d.get("status") == "done" and xbmcgui.Dialog().yesno(L(30000), Lf(30086, d.get("name", ""))):
            xbmcvfs.delete(d["dest"])     # xbmcvfs umí i síťovou složku (smb://)
        else:
            xbmcvfs.delete(d["dest"] + ".part")   # rozdělané už nikdo nedostahuje
        STORE.remove_download(dl_id)
    xbmc.executebuiltin("Container.Refresh")


def download_retry(dl_id):
    STORE.update_download(dl_id, status="queued", done=0, error="")
    xbmc.executebuiltin("Container.Refresh")


# --- Trakt -------------------------------------------------------------------------

def trakt_auth():
    trakt = get_trakt()
    if not trakt or not trakt.client_id or not trakt.client_secret:
        xbmcgui.Dialog().ok(L(30000), L(30094))
        return
    try:
        code = trakt.device_code()
    except TraktError as e:
        log_error(e)
        notify(L(30096), xbmcgui.NOTIFICATION_ERROR)
        return
    dialog = xbmcgui.DialogProgress()
    dialog.create(L(30090), Lf(30095, code.get("verification_url", ""), code.get("user_code", "")))
    interval = int(code.get("interval") or 5)
    deadline = time.time() + int(code.get("expires_in") or 600)
    tokens = None
    while time.time() < deadline and not dialog.iscanceled():
        dialog.update(int(100 - (deadline - time.time()) / int(code.get("expires_in") or 600) * 100))
        xbmc.sleep(interval * 1000)
        try:
            tokens = trakt.poll_token(code["device_code"])
        except TraktError as e:
            log_error(e)
            break
        if tokens:
            break
    dialog.close()
    notify(L(30097) if tokens else L(30096), xbmcgui.NOTIFICATION_INFO if tokens else xbmcgui.NOTIFICATION_ERROR)


def cztor_pair():
    """Spáruje zařízení s účtem CZtor: PIN se potvrdí na webu, doplněk se jen ptá."""
    api = cztor_client()
    try:
        pin = api.start_pin()
    except CztorError as e:
        log_error(e)
        xbmcgui.Dialog().ok(L(30560, "CZtor"), f"{L(30569, 'Spárování s CZtorem se nepodařilo.')}[CR]{e}")
        return
    dialog = xbmcgui.DialogProgress()
    text = L(30567, "Na telefonu nebo počítači otevři[CR][B]%s[/B][CR]přihlas se a zadej PIN [B]%s[/B]")
    dialog.create(L(30560, "CZtor"), text % (pin["url"], pin["pin"]))
    total = max(30, pin["expires"] - time.time())
    paired, error = False, None
    while time.time() < pin["expires"] and not dialog.iscanceled() and not MONITOR.abortRequested():
        dialog.update(int(100 - (pin["expires"] - time.time()) / total * 100))
        if MONITOR.waitForAbort(pin["interval"]) or dialog.iscanceled():
            break
        try:
            paired = api.poll_pin(pin["poll_token"])
        except CztorError as e:
            log_error(e)
            error = e
            break
        if paired:
            break
    canceled = dialog.iscanceled()
    dialog.close()
    if not paired:
        if error or not canceled:
            notify(L(30569, "Spárování s CZtorem se nepodařilo."), xbmcgui.NOTIFICATION_ERROR)
        return
    ADDON.setSetting("cz_enabled", "true")
    STORE.clear_cache()   # seznamy streamů bez CZtor jinak drží 72 h
    cztor_status()


def cztor_status():
    api = cztor_client()
    if not api.paired():
        xbmcgui.Dialog().ok(L(30560, "CZtor"), L(30571, "CZtor není spárovaný – použij Spárovat PINem."))
        return
    try:
        account = api.profile()
    except CztorError as e:
        log_error(e)
        xbmcgui.Dialog().ok(L(30560, "CZtor"), str(e))
        return
    text = L(30568, "CZtor: %s, předplatné %s do %s") % (
        account.get("name") or "?", account.get("plan") or "?", account.get("valid_until") or "?")
    if not account.get("active"):
        text += "[CR]" + L(30572, "Předplatné CZtor není aktivní.")
    xbmcgui.Dialog().ok(L(30560, "CZtor"), text)


def cztor_logout():
    cztor_client().logout()
    notify(L(30570, "CZtor odhlášen."))


def trakt_logout():
    STORE.set_trakt({})
    notify(L(30098))


# volby dialogu „Uspat zdroj": (sekundy, id řetězce, český fallback)
SOURCE_PAUSE_CHOICES = list(zip(PAUSE_CHOICES, (30743, 30744, 30745), ("10 minut", "1 hodina", "12 hodin")))


def source_pause(source):
    """Dialog „Uspat zdroj" nad řádkem ve Stavu zdrojů — zapíše pauzu do `accounts.pause()`,
    kterou jádro čte v `raw_streams()` (`accounts.paused_for`), ať se nedostupný zdroj
    přestane hledat, dokud pauza neskončí."""
    labels = [L(sid, fallback) for _s, sid, fallback in SOURCE_PAUSE_CHOICES]
    if accounts_paused_for(STORE, source) > 0:
        labels.append(L(30746, "Zrušit uspání"))
    choice = xbmcgui.Dialog().select(L(30742, "Uspat zdroj"), labels)
    if choice < 0:
        return
    if choice < len(SOURCE_PAUSE_CHOICES):
        seconds, sid, fallback = SOURCE_PAUSE_CHOICES[choice]
        accounts_pause(STORE, source, seconds)
        notify(Lf(30747, (source_tag(source) or ACCOUNT_TAGS.get(source, source)), L(sid, fallback)))
    else:
        accounts_pause(STORE, source, 0)
        notify(L(30746, "Zrušit uspání"))


# --- router ---------------------------------------------------------------------

def router(query):
    p = dict(urllib.parse.parse_qsl(query.lstrip("?")))
    action = p.get("action")
    if action in ("search", "manualsearch") and "languages" in p:
        subs_service_search(get_apis(), p)   # dialog Titulky v Kodi, ne hledání v doplňku
        return
    if action == "subs_download":
        subs_service_download(get_apis(), p.get("id"))
        return
    global UPDATE_LISTING
    UPDATE_LISTING = p.get("paged") == "1"
    # akce bez seznamu (RunPlugin) a bez API
    simple = {
        "history_remove": lambda: history_remove(p["type"], p.get("q", "")),
        "history_clear": lambda: _tlacitko(lambda: history_clear(p["type"])),
        "mycats": lambda: list_mycats(p.get("type", "movie")),
        "mycat_new": lambda: _tlacitko(lambda: mycat_new(p.get("type", "movie"))),
        "mycat_remote": lambda: _tlacitko(lambda: mycat_remote(p.get("id") or None, p.get("type", "movie"))),
        "concerts_setup": lambda: _tlacitko(concerts_setup),
        "concerts_search": lambda: _tlacitko(concerts_search),
        "concerts_add": lambda: _tlacitko(lambda: concerts_add(p.get("name", ""), p.get("exact") == "1")),
        "lastfm_check": lambda: _tlacitko(lastfm_check),
        "tmdb_check": lambda: _tlacitko(tmdb_check),
        "mycat_edit": lambda: _tlacitko(lambda: mycat_edit(p.get("id", ""))),
        "mycat_delete": lambda: _tlacitko(lambda: mycat_delete(p.get("id", ""))),
        "mycat_menu": lambda: _tlacitko(lambda: mycat_menu(p.get("id", ""), p.get("on") == "1")),
        "home_pick": lambda: _tlacitko(home_pick),
        "mycat_batch": lambda: _tlacitko(lambda: mycat_batch(p.get("id", ""))),
        "menu_hide": lambda: _tlacitko(lambda: menu_hide(p.get("key", ""))),
        "menu_edit": lambda: _tlacitko(menu_edit),
        "menu_reset": lambda: _tlacitko(menu_reset),
        "toggle_watched": lambda: toggle_watched(p["id"]),
        "remove_progress": lambda: remove_progress(p["id"], p.get("series")),
        "search": lambda: search_menu(p.get("type") or p.get("kind") or "any"),
        "favourites": list_favourites,
        "watchlist": list_watch,
        "watch_flag": lambda: watch_flag(p["id"]),
        "watch_seen": lambda: watch_seen(p.get("id")),
        "watch_check_now": lambda: _tlacitko(lambda: request_watch_check(force=True)),
        "recent": list_recent,
        "downloads": list_downloads,
        "download_remove": lambda: download_remove(p["id"]),
        "download_retry": lambda: download_retry(p["id"]),
        "trakt_auth": trakt_auth,
        "trakt_logout": trakt_logout,
        # akce z nastavení, žádný výpis — succeeded=False jako u "clear_cache"
        "cztor_pair": lambda: (cztor_pair(), xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)),
        "sync_create": lambda: _tlacitko(sync_create),
        # SyncWatch: tlačítka s okny (handle −1); složka skupiny je `sw_menu`
        "syncwatch": lambda: _tlacitko(sw_entry),
        "sw_menu": sw_menu,
        "sw_intro": lambda: _tlacitko(sw_intro),
        "sw_create": lambda: _tlacitko(sw_create),
        "sw_join": lambda: _tlacitko(sw_join),
        "sw_window": lambda: _tlacitko(sw_window),
        "sw_leave": lambda: _tlacitko(sw_leave),
        "sw_rejoin": lambda: _tlacitko(sw_rejoin),
        "sw_lock": lambda: _tlacitko(sw_lock),
        "sync_join": lambda: _tlacitko(sync_join),
        "sync_leave": lambda: _tlacitko(sync_leave),
        "cztor_status": lambda: (cztor_status(), xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)),
        "cztor_logout": lambda: (cztor_logout(), xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)),
        # succeeded=False jako u "settings" — jinak by Kodi navigoval do prázdné složky
        # a musel by se dát Zpět, i když jde jen o akci, ne o výpis
        "clear_cache": lambda: (STORE.clear_cache(), notify(L(30099)),
                                xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)),
        "stats_send": stats_send,
        "log_send": log_send,
        "test_sources": lambda: _tlacitko(test_sources),
        "source_pause": lambda: _tlacitko(lambda: source_pause(p["source"])),
        "remote_setup": lambda: remote_setup_action(p.get("section")),
        "transfer_send": lambda: (transfer_send(),
                                  xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)),
        "transfer_receive": lambda: (transfer_receive(),
                                     xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)),
        "transfer_file_save": lambda: (transfer_file_save(),
                                       xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)),
        "transfer_file_load": lambda: (transfer_file_load(),
                                       xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)),
        "stream_layout_reset": lambda: (stream_layout_reset(),
                                        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)),
        "setup_wizard": lambda: _tlacitko(lambda: setup_wizard(force=True)),
        "sub_status": sub_status,
        # tlačítka s dialogem, žádný výpis: z nastavení (RunPlugin, handle −1) je to jedno, ale z
        # výpisu (Stav zdrojů → Luna) má Kodi handle ≥ 0 a bez endOfDirectory nahlásí GetDirectory
        # failed a čeká na timeout
        "luna_check": lambda: _tlacitko(lambda: luna_check(ask=True)),
        "os_check": lambda: _tlacitko(os_check),
        "luna_find": lambda: _tlacitko(luna_find),
        "speedtest": lambda: _tlacitko(speedtest),
        "update_repos": lambda: _tlacitko(update_repos),
        "tmdbhelper_player": lambda: _tlacitko(tmdbhelper_player),
        "sync_now": sync_now,
        "info_install": lambda: _tlacitko(info_install),
        "info_terms": lambda: _tlacitko(info_terms),
        "whats_new": whats_new,
        "ha_files": list_ha_files,
        "settings": lambda: (xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False) if HANDLE >= 0 else None,
                             ADDON.openSettings()),
    }
    try:
        if action == "title_download":
            # „Stáhnout“ v kontextovém menu (RunPlugin, handle −1) — z widgetu/JSON-RPC s handle nic
            if HANDLE < 0:
                pick_title(get_apis(), p.get("type", "movie"), p["id"], p.get("series"), alt=p.get("alt"),
                           download=True)
            else:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
            return
        if action in ("title", "streams") and HANDLE < 0:
            # klik na titul ve výpisu Nokturna: Kodi ne-přehratelnou položku spustí jako skript
            # bez handle → streamy v dialogu na dva řádky (viz add_playable, pick_title)
            pick_title(get_apis(), p.get("type", "movie"), p["id"], p.get("series"), alt=p.get("alt"),
                       fulltext=bool(p.get("fulltext")), fresh=bool(p.get("fresh")))
            return
        if action in ("streams", "streams_filter"):
            # výpis streamů jako složka zrušen v `5.2.14~beta4` — starý odkaz (oblíbené, widget) nic
            # nevypíše, z okna Nokturna otevře dialog; z widgetu/JSON-RPC nikdy modál
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
            if browsing_nokturno():
                xbmc.executebuiltin(runplugin(action="title", type=p.get("type", "movie"), id=p.get("id"),
                                              series=p.get("series"), alt=p.get("alt")))
            return
        if action == "random":
            # ne-složka jako titul v režimu seznamu: klik (handle −1) i Přehrát ze skinu
            # (handle ≥ 0) vedou na tutéž cestu, výpis se nekreslí nikdy
            random_title(get_apis(), p.get("type", "movie"))
            return
        if action == "page":
            # „Další“ ve výpisu: nahradit stránku, ať Zpět nevede přes všechny předchozí
            target = p.get("url", "")
            if target.startswith(BASE_URL + "?"):
                if browsing_nokturno():
                    xbmc.executebuiltin(f"Container.Update({target},replace)")
                else:
                    xbmc.executebuiltin(f"ActivateWindow(Videos,{target},return)")
            if HANDLE >= 0:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
            return
        if action == "tv_pick":
            # volba nad TV programem: dialog jen po kliku ve výpisu (handle −1), jinak nic
            if HANDLE < 0:
                tv_pick(get_apis(), p.get("field", ""), p.get("date", ""), p.get("kind", ""), p.get("channel", ""))
            else:
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        if action in simple:
            # stejná pojistka jako u výpisů níž: akce bez `type` (starý odkaz z widgetu, ruční
            # URL z HA) dřív vyletěla KeyError mimo `_fail`, Kodi nechalo neuzavřený handle
            # a při souběhu s dalším dialogem se celé ukončilo („two concurrent busydialogs")
            simple[action]()
            return
        apis = get_apis()
        if not action:
            main_menu(apis, home=p.get("home") == "1")
        elif action == "menu_move":
            _tlacitko(lambda: menu_move(apis, p.get("key", ""), -1 if p.get("step") == "-1" else 1))
        elif action == "accounts":
            list_accounts(apis)
        elif action == "accounts_refresh":
            accounts_refresh(apis)
        elif action == "browse":
            browse_menu(apis, p.get("type", "movie"))
        elif action == "foryou":
            list_foryou(apis, p.get("type", "movie"))
        elif action == "hq":   # uložený odkaz na zrušené „Filmy ve vysoké kvalitě“ → předvolba, jinak hlavní menu
            if any(c.get("id") == "pre-movie-hq" for c in mycats("movie")):
                list_mycat(apis, "movie", "pre-movie-hq")
            else:
                main_menu(apis)
        elif action in ("hq_refresh", "verify_refresh"):   # `hq_refresh` = starý odkaz
            verify_refresh(apis, p.get("target") or "", size=max(1, min(20, int(p.get("size") or 8))),
                           pool_only=p.get("pool_only") == "1")
        elif action in ("hq_setup", "hq_info", "hq_batch"):   # staré uložené odkazy: nic se neděje
            _tlacitko(lambda: None)
        elif action == "similar":
            list_similar(apis, p.get("type", "movie"), p.get("id", ""))
        elif action == "tv":
            list_tv(apis, p.get("date", ""), p.get("kind", ""), p.get("channel", ""))
        elif action == "genres":
            list_genres(apis, p["type"], p["catalog"], p.get("src", "luna"), show_all=not p.get("noall"))
        elif action == "mycat":
            list_mycat(apis, p.get("type", "movie"), p.get("id", ""), int(p.get("page") or 1))
        elif action in ("concerts_artist", "mycat_artist"):   # `mycat_artist` = starý odkaz z bety 1
            list_concerts_artist(p.get("a", ""))
        elif action == "concerts_find":
            list_concerts_find(p.get("q", ""))
        elif action == "concerts":
            list_concerts()
        elif action == "concerts_recent":
            list_concerts_recent()
        elif action == "concerts_tags":
            list_concerts_tags()
        elif action == "concerts_tag":
            list_concerts_tag(p.get("tag", ""))
        elif action == "concerts_letters":
            list_concerts_letters()
        elif action == "concerts_letter":
            list_concerts_letter(p.get("l", ""))
        elif action == "play_ref":
            play_ref(apis, p.get("ref", ""), p.get("name", ""), p.get("alts", ""))
        elif action == "dash_group":
            list_dash_group(apis, p["catalog"], p.get("type", "movie"))
        elif action == "home_row":
            list_home_row(apis, int(p.get("slot") or 0))
        elif action == "catalog":
            list_catalog(apis, p["type"], p["catalog"], p.get("src", "luna"), genre=p.get("genre"),
                         search=p.get("search"), skip=int(p.get("skip") or 0))
        elif action == "search_new":
            search_new(apis, p["type"])
        elif action == "search_run":
            search_run(apis, p["type"], p.get("q", ""), offset=int(p.get("offset") or 0))
        elif action == "continue":
            list_continue(apis)
        elif action == "prefetch":
            prefetch(apis, p.get("kind", "next"))
        elif action == "toggle_fav":
            toggle_fav(apis, p["id"], p.get("type", "movie"), p.get("series"), p.get("alt"))
        elif action == "watch_series":
            toggle_watch_series(apis, p["id"], p.get("alt"))
        elif action == "watch_episode":
            toggle_watch_episode(apis, p["id"], p["series"], p.get("alt"))
        elif action == "want":
            toggle_want(apis, p["id"], p.get("type", "movie"), p.get("alt"))
        elif action == "watch_open":
            watch_open(apis, p["id"], p.get("alt"))
        elif action == "watch_check":
            watch_check(apis, force=bool(p.get("force")))
        elif action == "seasons":
            list_seasons(apis, p["id"], alt=p.get("alt"))
        elif action == "episodes":
            list_episodes(apis, p["id"], int(p.get("season") or 0), alt=p.get("alt"))
        elif action == "title":
            # Přehrát nad titulem v režimu seznamu (Estuary/Arctic Fuse/TMDb Helper/tlačítko Play):
            # Kodi položku rozklíčovává a čeká setResolvedUrl → dialog výběru streamu
            play(apis, p.get("type", "movie"), p["id"], p.get("series"), alt=p.get("alt"), ask="1")
        elif action == "mylist":
            list_mylist(apis, p.get("path", ""), mylist_slot(p.get("slot")))
        elif action == "mylist_play":
            mylist_play(apis, p.get("refs", ""), p.get("name", ""))
        elif action == "play":
            play(apis, p["type"], p["id"], p.get("series"), url=p.get("url"), alt=p.get("alt"), subs=p.get("subs", ""),
                 pref=p.get("pref", ""), ask=p.get("ask", ""), alts=p.get("alts", ""), sw=p.get("sw", ""))
        elif action == "play_ws":
            play_ws(apis, p["ident"], p.get("name", ""))
        elif action == "play_hs":
            play_hs(apis, p["id"], p["hash"], p.get("name", ""))
        elif action == "dav_browse":
            list_dav_browse(apis, int(p.get("slot") or 0), p.get("path", ""))
        elif action == "play_dav":
            play_dav(apis, int(p.get("slot") or 0), p.get("path", ""), p.get("name", ""))
        elif action == "download":
            download_stream(apis, p["url"], p.get("name", ""), p["id"], p.get("type", "movie"), p.get("series"), p.get("alt"))
        elif action == "download_ws":
            download_ws(apis, p["ident"], p.get("name", ""))
        elif action == "download_hs":
            download_hs(apis, p["id"], p["hash"], p.get("name", ""))
        else:
            main_menu(apis)
    except Aborted:
        # Kodi končí, nebo uživatel zrušil — žádná hláška, jen zavřít handle, ať Kodi
        # nečeká na timeout (viz `should_stop`; přerušené hledání se nikde necachuje)
        xbmc.log(f"[{ADDON_ID}] {action}: přerušeno (Kodi končí nebo zrušeno uživatelem)", xbmc.LOGINFO)
        _close(action)
    except Errors as e:
        log_error(e)
        _fail(action, describe_error(e))
    except Exception as e:  # noqa: BLE001 – KeyError z chybějícího parametru, RuntimeError z Kodi API…
        # bez úklidu handle by Kodi u přehrání čekalo na timeout a hlásilo „Chyba skriptu"
        log_error(f"{action}: {traceback.format_exc()}")
        _fail(action, f"{type(e).__name__}: {e}")
        report_crash(action, e)


def _fail(action, message):
    notify(message, xbmcgui.NOTIFICATION_ERROR, 5000)
    _close(action)


def _close(action):
    """Zavře handle Kodi jako neúspěšný — bez toho by Kodi u přehrání čekalo na timeout."""
    # "title" s handle ≥ 0 = Přehrát nad titulem (Kodi čeká setResolvedUrl, viz router);
    # s handle < 0 se sem nedostane, router tu větev ukončí dřív
    if action in ("play", "play_ws", "play_hs", "play_dav", "title", "play_ref"):
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    elif action not in ("download", "download_ws", "download_hs", "toggle_fav"):
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


# Akce, u kterých se před výpisem nevyplatí číst `MyVideos*.db` (`adopt_kodi_marks`): nic
# se nekreslí, takže zhlédnuto ze skinu nemá kde chybět — plugin ho převezme při příštím
# výpisu titulů a služba jednou za minutu. Přehrání (widget Pokračovat, HA, Up Next) a
# zahřívání cache jinak platily čtení celé databáze (stovky řádků u velké knihovny) navíc.
MARKS_SKIP = frozenset((
    # přehrání a streamy
    "play", "play_ws", "play_hs", "play_dav", "play_ref", "title", "title_download", "prefetch", "hq_refresh",
    "verify_refresh", "mycat_batch", "hq_setup", "hq_info", "hq_batch",
    "download", "download_ws", "download_hs", "toggle_fav", "streams", "streams_filter", "subs_download",
    "dav_browse", "tv_pick", "page",
    # akce bez výpisu titulů (tlačítka v nastavení, hledání, stahování, Trakt, CZtor…)
    "history_remove", "history_clear", "remove_progress", "search", "search_new", "downloads",
    "download_remove", "download_retry", "trakt_auth", "trakt_logout", "cztor_pair",
    "cztor_status", "cztor_logout", "clear_cache", "stats_send", "log_send", "website_info",
    "test_sources", "source_pause", "remote_setup", "stream_layout_reset", "setup_wizard", "sub_status",
    "luna_check", "luna_find", "os_check", "speedtest", "update_repos", "tmdbhelper_player", "sync_now",
    "sync_create", "sync_join", "sync_leave", "mycats", "mycat_artist", "lastfm_check", "tmdb_check", "mycat_new", "mycat_edit", "mycat_delete", "mycat_menu", "home_pick",
    "mycat_remote", "concerts", "concerts_recent", "concerts_tags", "concerts_tag", "concerts_letters",
    "concerts_letter", "concerts_artist", "concerts_setup", "concerts_find", "concerts_add",
    "watch_series", "want", "watch_episode", "watch_flag", "watch_seen", "watch_check", "watch_check_now",
    "whats_new", "ha_files", "settings", "transfer_send", "transfer_receive",
    "transfer_file_save", "transfer_file_load", "menu_move", "menu_hide", "menu_edit", "menu_reset",
))


def _tlacitko(fn):
    """Spustí akci s dialogem a výpis zavře jako neúspěšný (nic se nekreslí, Kodi nikam nenavigne)."""
    try:
        fn()
    finally:
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)


set_host_stop(should_stop)   # úlohy na pozadí v jádru se po žádosti o konec už nespustí


def main(query):
    try:
        # zrušená volba střediska „HA i dashboard"; patří sem, ne do `migrate_on_start`
        # — ta běží na úrovni modulu, tedy dřív, než je tahle funkce definovaná
        migrate_sync_mode()
        migrate_sync_mode_default()
        migrate_terms()
        migrate_luna_default()
        migrate_third_party_default()
        migrate_catalogs_v2()
        action = dict(urllib.parse.parse_qsl(query.lstrip("?"))).get("action") or ""
        # do nastavení a k textu podmínek se uživatel musí dostat i bez souhlasu — jinak
        # by neměl kde ho dát (přepínač je první kategorie nastavení)
        if action not in TERMS_FREE and not ensure_terms():
            _close(action)
            return
        if action not in MARKS_SKIP:
            adopt_kodi_marks()
        router(query)
    finally:
        # sdílený executor popisů (`enrich`) nechává po sobě nečinná vlákna, na která Kodi
        # po doběhnutí pluginu čeká navždy — i při vypínání (Office 2026-09-16: widget
        # „Nově přidané" zablokoval Application.Quit natrvalo). Rozběhnuté dotazy doběhnou
        # do cache; když Kodi končí, nezačaté se zruší.
        release_enrich(cancel=should_stop())
        release_probe_pool()
        # nezačaté úlohy na pozadí (hlavně fronta hlaviček) se ruší vždy, ne jen při vypínání:
        # Kodi na vlákna pluginu po doběhnutí čeká, další klik do doplňku mezitím selže
        # a čtení se během přehrávání pere o linku a CPU (obývák 2026-10-19: přes 100 s
        # „waiting on thread", pak zamrzlé Kodi). Rozběhnuté doběhnou na vlastní timeout.
        cancel_background()
        drain_threads()


DRAIN_LIMIT = 3.0   # s – Kodi po doběhnutí skriptu čeká na vlákna jen 5 s, pak interpret zabije


def drain_threads(limit=None):
    """Krátce počká na vlákna, která po sobě plugin nechal (dopozdilé zdroje, hlavičky), a
    zaloguje, která to jsou. Kodi po návratu skriptu čeká na každé vlákno interpretu
    („waiting on thread"), po 5 s skript zabije („script didn't stop in 5 seconds") a zabití
    interpretu s běžícími vlákny je SIGSEGV v `PyDict_SetItem` nebo GUI zaseklé na busy dialogu
    (obývák 2026-10-15 až 22: 9 pádů, naposledy zamrznutí po 25 spuštěních `streams` za minutu).
    Čekání nic neprodlužuje: Kodi by čekalo stejně. Co nedoběhne, se jen zapíše do logu."""
    end = time.monotonic() + (DRAIN_LIMIT if limit is None else limit)
    me = threading.current_thread()
    for t in threading.enumerate():
        if t is not me and t is not threading.main_thread() and t.is_alive():
            t.join(max(0.0, end - time.monotonic()))
    left = [t for t in threading.enumerate() if t is not me and t is not threading.main_thread() and t.is_alive()]
    if not left:
        return 0
    frames = sys._current_frames()
    names = []
    for t in left:
        frame = frames.get(t.ident)
        where = f"{os.path.basename(frame.f_code.co_filename)}:{frame.f_lineno}" if frame else "?"
        names.append(f"{t.name}{'*' if t.daemon else ''}@{where}")
    xbmc.log(f"[{ADDON_ID}] po konci pluginu běží {len(left)} vláken: {', '.join(names[:8])}", xbmc.LOGWARNING)
    return len(left)


if __name__ == "__main__":
    keepalive.enable()   # spojení k API zdrojů se drží mezi dotazy (testy volají main() přímo, tam zůstává vypnuté)
    main(sys.argv[2] if len(sys.argv) > 2 else "")
