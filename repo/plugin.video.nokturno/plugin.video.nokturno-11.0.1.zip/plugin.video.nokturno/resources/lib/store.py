"""Trvalá data doplňku — JSON soubory v profilu (bez závislosti na Kodi).

history.json     historie hledání {kind: [dotazy]}
watched.json     {klíč: {"playcount", "resume", "total", "ts"}}
items.json       snímky titulů podle klíče (název, plakát, typ, id…) pro Pokračovat / Můj seznam
sosac_index.json snímky z rejstříku Sosáče (`idx:` klíče) — zvlášť, viz `Index`
favourites.json  [klíče] – Můj seznam
downloads.json   fronta stahování [{"id", "url", "name", "dest", "status", "done", "size", "error", "ts"}]
trakt.json       tokeny Traktu
cache/           odpovědi API s TTL (manifesty, meta)

`cache/` a `sosac_index.json` jdou kdykoli stáhnout znovu. Hostitel je může poslat
jinam (`cache_dir`) — HA je drží v `.cache/nokturno`, aby nebyly v každé záloze HA.

Kodi si u položek z pluginu zhlédnutí samo nepamatuje spolehlivě (cesta streamu
se mění), proto vlastní evidence.
"""
import contextlib
import hashlib
import json
import logging
import os
import threading
import time

try:                      # POSIX (Linux, CoreELEC, Android, macOS)
    import fcntl
except ImportError:       # pragma: no cover – Windows
    fcntl = None
try:                      # Windows
    import msvcrt
except ImportError:       # pragma: no cover – POSIX
    msvcrt = None

_LOGGER = logging.getLogger(__name__)

OLD_ADDON_ID = "plugin.video.luna"  # do 1.3.0 se doplněk jmenoval takhle
DATA_FILES = ("history", "watched", "items", "favourites", "downloads", "trakt", "streampref", "favlog", "histlog",
              "streamfilter")
HISTORY_MAX = 10
WATCHED_MAX = 5000
ITEMS_MAX = 2000
INDEX_MAX = 3000
INDEX_REFRESH = 86400   # s – jak často obnovit razítko u nezměněného snímku v rejstříku
TMP_MAX_AGE = 3600   # s – starší rozepsané `*.tmp` po zabitém procesu se uklidí


def migrate_profile(new_dir):
    """Jednorázově přenese data z profilu starého ID (plugin.video.luna) do nového.

    Vrací cestu ke starému settings.xml (plugin z něj přebere nastavení), nebo None.
    """
    marker = os.path.join(new_dir, ".migrated")
    if os.path.exists(marker):
        return None
    old_dir = os.path.join(os.path.dirname(new_dir.rstrip("/\\")), OLD_ADDON_ID)
    os.makedirs(new_dir, exist_ok=True)
    old_settings = None
    if os.path.isdir(old_dir):
        import shutil
        for name in DATA_FILES:
            src = os.path.join(old_dir, name + ".json")
            dst = os.path.join(new_dir, name + ".json")
            if os.path.exists(src) and not os.path.exists(dst):
                shutil.copy(src, dst)
        if os.path.exists(os.path.join(old_dir, "settings.xml")):
            old_settings = os.path.join(old_dir, "settings.xml")
            # soubor zkopírovat dřív, než si Kodi založí prázdný; plugin navíc hodnoty aplikuje přes setSetting
            if not os.path.exists(os.path.join(new_dir, "settings.xml")):
                shutil.copy(old_settings, os.path.join(new_dir, "settings.xml"))
    with open(marker, "w") as f:
        f.write("1")
    return old_settings


_MISSING = object()   # `_read_cached`: záznam chybí nebo prošel (None je platná hodnota)


class Store:
    def __init__(self, directory, cache_dir=None):
        self.dir = directory
        # cache API a rejstřík Sosáče (data, která jdou stáhnout znovu); bez zadání vedle ostatních
        self.cache_dir = cache_dir or directory
        os.makedirs(directory, exist_ok=True)
        os.makedirs(os.path.join(self.cache_dir, "cache"), exist_ok=True)
        # Soubory sdílí víc procesů najednou (doplněk v Kodi = nový proces na každý
        # výpis, plus služba na pozadí). Načtený obsah se drží v paměti jen dokud se
        # soubor na disku nezmění (`_sigs`: mtime + velikost) — jinak by zápis
        # z procesu se starší kopií přepsal, co mezitím uložil jiný (přehrání
        # uložilo snímek titulu, výpis katalogu ho vzápětí smazal).
        self._cache = {}
        self._sigs = {}
        self._index = None
        self._clean_tmp()
        # úložiště rejstříku Sosáče založené hned tady, ne v `index()`: ten se volá i ze smyčky
        # událostí HA (atributy senzoru) a konstruktor Store čte disk (`_clean_tmp`)
        self._index_files = Store(self.cache_dir) if self.cache_dir != directory else None
        # Hledání pro film i seriál běží souběžně ve dvou vláknech (default.py
        # search_run) a obě sahají na tenhle jeden Store — bez zámku dvě vlákna
        # měnila stejný sdílený dict zároveň s tím, jak ho druhé zapisovalo
        # (json.dump) nebo prořezávalo (_trim), a Python na to spadl s
        # "dictionary changed size during iteration". RLock, ne Lock: metody
        # se volají navzájem (remember_item → load/save) ze stejného vlákna.
        self._lock = threading.RLock()
        # Kolikrát je soubor zamčený mezi procesy v tomhle vlákně (`updating`).
        # Zámek na soubor patří otevřenému popisovači, ne procesu — vnořené volání
        # (`toggle_favourite` → `remember_item`) by si přes druhý `open()` zamklo
        # samo sebe, proto se bere jen v nejvyšší úrovni.
        self._held = {}
        # rozpracovaná transakce na soubor (`updating`) — vnořené volání nad týmž jménem
        # dostane tentýž objekt a ukládá se jednou, na konci té vnější. Jinak by vnitřní
        # načetla data znovu z disku a vnější je svým uložením přepsala zpátky.
        self._tx = {}
        # zámky per klíč cache (`cached_if`), viz `_key_lock`
        self._key_locks = {}
        self._key_locks_guard = threading.Lock()
        # dočasně kratší platnost cache pro jedno vlákno (`fresher`)
        self._local = threading.local()

    # --- soubory ------------------------------------------------------------
    def _path(self, name):
        return os.path.join(self.dir, name + ".json")

    def _sig(self, path):
        try:
            st = os.stat(path)
            return (st.st_mtime_ns, st.st_size)
        except OSError:
            return None

    def _clean_tmp(self):
        try:
            for name in os.listdir(self.dir):
                path = os.path.join(self.dir, name)
                if name.endswith(".tmp") and time.time() - os.path.getmtime(path) > TMP_MAX_AGE:
                    os.remove(path)
        except OSError:
            pass

    @contextlib.contextmanager
    def _file_lock(self, name):
        """Výhradní zámek na soubor mezi procesy. Nejde-li zamknout, pokračuje se bez něj.

        Kodi je na ten soubor víc procesů najednou: plugin se spouští znovu při každém
        kliknutí, služba na pozadí běží pořád (pozici přehrávání zapisuje každých 30 s).
        `os.replace` je atomický, ale celý cyklus načti–uprav–ulož ne — prohrávající
        zápis tiše zahodil, co mezitím uložil ten druhý (zhlédnuto, fronta stahování).
        Zamyká se prázdný soubor `<name>.lock` vedle dat, ne data samotná: zámek tak
        přežije `os.replace`, kterým se data nahrazují.
        """
        if self._held.get(name) or (fcntl is None and msvcrt is None):
            self._held[name] = self._held.get(name, 0) + 1
            try:
                yield
            finally:
                self._held[name] -= 1
            return
        path = os.path.join(self.dir, name + ".lock")
        handle = None
        try:
            handle = open(path, "a+b")
            if fcntl is not None:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            else:                                   # pragma: no cover – jen Windows
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        except OSError as err:
            # síťový disk bez zámků, Android SAF, plný disk… radši bez zámku než spadnout
            _LOGGER.debug("zámek %s nejde vzít (%s) – pokračuji bez něj", path, err)
            if handle is not None:
                handle.close()
                handle = None
        self._held[name] = 1
        try:
            yield
        finally:
            self._held[name] -= 1
            if handle is not None:
                try:
                    if fcntl is not None:
                        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
                    else:                           # pragma: no cover – jen Windows
                        handle.seek(0)
                        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                except OSError:
                    pass
                handle.close()

    @contextlib.contextmanager
    def updating(self, name, default):
        """Načti–uprav–ulož pod zámkem: `with store.updating("watched", {}) as data:`.

        Data se uvnitř mění **na místě** (dict/list), protože uložit se musí týž objekt.
        Čte se vždy čerstvě z disku — kopie v paměti může být starší než zápis z jiného
        procesu.
        """
        with self._lock:
            if name in self._tx:
                yield self._tx[name]
                return
            with self._file_lock(name):
                data = self.reload(name, default)
                self._tx[name] = data
                try:
                    yield data
                    self.save(name, data)
                finally:
                    self._tx.pop(name, None)

    def load(self, name, default):
        with self._lock:
            path = self._path(name)
            sig = self._sig(path)
            if name in self._cache and self._sigs.get(name) == sig:
                return self._cache[name]
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
            except (OSError, ValueError):
                data = default
            self._cache[name] = data
            self._sigs[name] = sig
            return data

    def _tmp(self, path):
        """Dočasný soubor musí být unikátní — plugin i služba (a víc instancí pluginu)
        zapisují souběžně a se společným jménem si ho navzájem přejmenují pod rukama
        (`FileNotFoundError: items.json.tmp -> items.json`)."""
        return f"{path}.{os.getpid()}.{threading.get_ident()}.tmp"

    def save(self, name, data):
        with self._lock:
            self._cache[name] = data
            path = self._path(name)
            tmp = self._tmp(path)
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False)
                try:
                    # `trakt.json`, `cztor_session.json` a spol. nesou přístupové tokeny;
                    # výchozí práva bývají 0644, tedy čitelné pro kohokoli na stroji.
                    # Na FAT/SAF (Android) chmod neprojde — soubor tam práva nemá vůbec.
                    os.chmod(tmp, 0o600)
                except OSError:
                    pass
                os.replace(tmp, path)
                self._sigs[name] = self._sig(path)
            except OSError as err:  # zápis není kritický, ať kvůli němu nepadne výpis — ale ať je vidět
                _LOGGER.warning("zápis %s selhal: %s", path, err)
                try:
                    os.remove(tmp)
                except OSError:
                    pass

    def reload(self, name, default):
        """Načte znovu z disku. `load` si změnu z jiného procesu pozná sám, tohle
        zůstává pro volající, kteří to chtějí najisto (sync)."""
        with self._lock:
            self._cache.pop(name, None)
            self._sigs.pop(name, None)
            return self.load(name, default)

    def index(self):
        """Rejstřík Sosáče nad vlastním souborem, viz `Index`."""
        with self._lock:
            if self._index is None:
                self._index = Index(self, files=self._index_files)
            return self._index

    # --- historie hledání -------------------------------------------------------
    def history(self, kind):
        with self._lock:
            return list(self._hist_map().get(kind, []))

    def _hist_map(self):
        """Historie jako {kind: [dotazy]}. Starší HA verze ji ukládala jako plochý
        seznam — ten se bere jako přihrádka "any" (hlavní hledání, sdílené s doplňkem)."""
        h = self.load("history", {})
        return {"any": list(h)} if isinstance(h, list) else h

    # historie se vede i jako časovaný deník `histlog` (klíč "kind\tdotaz"),
    # aby šla synchronizovat mezi Kodi vč. mazání — zobrazený seznam `history`
    # se z něj přepočítá (novější dotaz výš), viz rebuild_history / sync.py
    @staticmethod
    def _hkey(kind, query):
        return f"{kind}\t{query.strip().lower()}"

    def _log_history(self, kind, query, on):
        with self.updating("histlog", {}) as log:
            log[self._hkey(kind, query)] = {"kind": kind, "q": query.strip(), "on": on, "ts": int(time.time())}
            self._trim(log, 500)

    def rebuild_history(self):
        """Zobrazený seznam `history` podle deníku: aktivní dotazy, novější výš, na kind."""
        log = self.load("histlog", {})
        by_kind = {}
        for rec in log.values():
            if rec.get("on") and rec.get("q"):
                by_kind.setdefault(rec.get("kind"), []).append(rec)
        data = {k: [r["q"] for r in sorted(v, key=lambda r: -(r.get("ts") or 0))][:HISTORY_MAX]
                for k, v in by_kind.items()}
        self.save("history", data)

    def add_history(self, kind, query):
        query = (query or "").strip()
        if not query:
            return
        with self._lock:
            with self._file_lock("history"):
                data = self._hist_map()
                items = [q for q in data.get(kind, []) if q.lower() != query.lower()]
                data[kind] = ([query] + items)[:HISTORY_MAX]
                self.save("history", data)
            self._log_history(kind, query, True)

    def remove_history(self, kind, query):
        with self._lock:
            with self._file_lock("history"):
                data = self._hist_map()
                data[kind] = [q for q in data.get(kind, []) if q != query]
                self.save("history", data)
            self._log_history(kind, query, False)

    def clear_history(self, kind):
        with self._lock:
            with self._file_lock("history"):
                data = self._hist_map()
                data[kind] = []
                self.save("history", data)
            now = int(time.time())
            with self.updating("histlog", {}) as log:
                for key, rec in list(log.items()):
                    if rec.get("kind") == kind and rec.get("on"):
                        log[key] = {**rec, "on": False, "ts": now}

    # --- zhlédnuto / rozkoukáno ---------------------------------------------------
    def watched(self, item_id):
        with self._lock:
            return self.load("watched", {}).get(str(item_id))

    def playcount(self, item_id):
        return int((self.watched(item_id) or {}).get("playcount") or 0)

    def resume(self, item_id):
        w = self.watched(item_id) or {}
        return float(w.get("resume") or 0), float(w.get("total") or 0)

    def resume_stream(self, item_id):
        """Vnitřní reference streamu (`ws:…`/`hs:…:…`/…) a titulky, se kterými se titul
        naposledy hrál — na rozdíl od podepsaného odkazu zdroje nevyprší, jde ji tedy
        použít znovu při pokračování ve sledování a přeskočit tím nové hledání (`stream_url`
        z `set_resume`). `None`, když u záznamu není (starší záznam, nebo se nikdy nezapsal
        — např. položka z jiného zařízení přes sync).

        Jen u rozkoukaného nebo zhlédnutého titulu: odebrání z Pokračovat ve sledování
        vynuluje pozici, ale referenci nechá — titul se pak všude kreslil jako přímé
        přehrání starého streamu od začátku, bez výběru (Četník na Office 2026-09-26)."""
        w = self.watched(item_id) or {}
        url = w.get("stream_url")
        if not url or not (float(w.get("resume") or 0) > 0 or w.get("playcount")):
            return None
        return url, w.get("stream_subs") or ""

    def set_watched(self, item_id, watched=True):
        with self.updating("watched", {}) as data:
            entry = data.get(str(item_id)) or {}
            entry["playcount"] = 1 if watched else 0
            entry["resume"] = 0
            entry["ts"] = int(time.time())
            data[str(item_id)] = entry
            self._trim(data, WATCHED_MAX)

    def set_resume(self, item_id, position, total, stream_url=None, stream_subs=None):
        """`stream_url`/`stream_subs`: jen když se pozice zapisuje za běhu přehrávání
        (`Player.save_resume`) — cross-device sync a ruční nastavení pozice žádný stream
        nezná, tam se předchozí zapamatovaná reference (pokud existuje) ponechá beze změny."""
        with self.updating("watched", {}) as data:
            entry = data.get(str(item_id)) or {}
            entry["resume"] = round(float(position), 1)
            entry["total"] = round(float(total), 1)
            entry["ts"] = int(time.time())
            if stream_url is not None:
                entry["stream_url"] = stream_url
                entry["stream_subs"] = stream_subs or ""
            data[str(item_id)] = entry
            self._trim(data, WATCHED_MAX)

    # --- skrytý „Další díl“ -------------------------------------------------------
    # {id seriálu: {"ep": id dílu, "ts": čas}} — synchronizuje se mezi Kodi a HA
    # (viz sync.py), aby odebrání z Pokračovat ve sledování platilo i na Kodi,
    # které bylo zrovna vypnuté. Starší doplňky ukládaly jen {seriál: díl}.

    def hide_next(self, series_id, episode_id):
        with self.updating("next_hidden", {}) as data:
            data[str(series_id)] = {"ep": str(episode_id), "ts": int(time.time())}

    def next_hidden(self, series_id):
        """Id dílu, který uživatel u seriálu skryl, nebo prázdný řetězec."""
        rec = self.load("next_hidden", {}).get(str(series_id))
        if isinstance(rec, dict):
            return str(rec.get("ep") or "")
        return str(rec or "")

    def in_progress(self):
        """Rozkoukané: [(klíč, záznam)] od nejnovějšího."""
        with self._lock:
            data = self.load("watched", {})
            rows = [(k, v) for k, v in data.items() if float(v.get("resume") or 0) > 0 and not v.get("playcount")]
            return sorted(rows, key=lambda kv: -kv[1].get("ts", 0))

    def recently_watched(self, limit=50):
        with self._lock:
            data = self.load("watched", {})
            rows = [(k, v) for k, v in data.items() if v.get("playcount")]
            return sorted(rows, key=lambda kv: -kv[1].get("ts", 0))[:limit]

    @staticmethod
    def _trim(data, limit):
        if len(data) > limit:
            for key in sorted(data, key=lambda k: data[k].get("ts", 0))[: len(data) - limit]:
                del data[key]

    # --- zapamatovaná volba streamu u seriálu ----------------------------------------
    # {id seriálu: {"source", "quality", "langs", "ts"}} — jakou kombinaci si uživatel
    # vybral naposledy; další díly se pak pustí bez dialogu, když ji mají k dispozici.
    def stream_pref(self, series_id):
        with self._lock:
            return self.load("streampref", {}).get(str(series_id))

    def set_stream_pref(self, series_id, pref):
        with self.updating("streampref", {}) as data:
            data[str(series_id)] = dict(pref, ts=int(time.time()))
            self._trim(data, 300)

    # --- naposledy zvolený filtr streamů ---------------------------------------------
    # jeden společný filtr pro celý doplněk (ne na titul) — soubor je v profilu
    # tohoto Kodi, takže si ho každá instalace pamatuje sama za sebe, bez synchronizace
    def last_stream_filter(self):
        with self._lock:
            return self.load("streamfilter", {})

    def set_last_stream_filter(self, filt):
        with self._lock:
            self.save("streamfilter", dict(filt))

    # --- snímky titulů (pro seznamy bez dotazu na API) --------------------------------
    def remember_item(self, key, info):
        with self.updating("items", {}) as data:
            info = dict(info)
            info["ts"] = int(time.time())
            data[str(key)] = info
            self._trim(data, ITEMS_MAX)

    def item(self, key):
        with self._lock:
            return self.load("items", {}).get(str(key))

    # --- Můj seznam ---------------------------------------------------------------
    def favourites(self):
        with self._lock:
            return list(self.load("favourites", []))

    def is_favourite(self, key):
        with self._lock:
            return str(key) in self.load("favourites", [])

    def toggle_favourite(self, key, info=None):
        with self._lock:
            key = str(key)
            with self.updating("favourites", []) as favs:
                if key in favs:
                    favs.remove(key)
                    added = False
                else:
                    favs.insert(0, key)
                    added = True
                    if info:
                        self.remember_item(key, info)
            # deník pro synchronizaci (viz sync.py): samotný seznam neumí říct,
            # kdy z něj co ubylo, a bez času by se odebrání nedalo přenést jinam
            with self.updating("favlog", {}) as log:
                log[key] = {"on": added, "ts": int(time.time())}
                self._trim(log, 1000)
            return added

    # --- stahování ------------------------------------------------------------------
    def downloads(self):
        with self._lock:
            return list(self.reload("downloads", []))

    def add_download(self, entry):
        with self.updating("downloads", []) as data:
            if any(d.get("id") == entry.get("id") for d in data):
                return False
            data.append(dict(entry, status="queued", done=0, size=0, error="", ts=int(time.time())))
            return True

    def update_download(self, dl_id, **fields):
        with self.updating("downloads", []) as data:
            for d in data:
                if d.get("id") == dl_id:
                    d.update(fields)

    def remove_download(self, dl_id):
        with self.updating("downloads", []) as data:
            data[:] = [d for d in data if d.get("id") != dl_id]

    # --- Trakt ------------------------------------------------------------------------
    def trakt(self):
        with self._lock:
            return self.load("trakt", {})

    def set_trakt(self, data):
        with self._lock:
            with self._file_lock("trakt"):
                self.save("trakt", data or {})

    # --- cache odpovědí API -------------------------------------------------------------
    def cached(self, key, ttl, loader):
        return self.cached_if(key, ttl, loader)

    @contextlib.contextmanager
    def fresher(self, max_age, prefixes=()):
        """Ve **svém vlákně** bere z cache jen záznamy mladší než `max_age` (s), a jen
        u klíčů začínajících `prefixes` (prázdné = všechny). Pro kontrolu Hlídaných:
        metadata seriálu se drží 30 dní a seznam streamů 72 h, takže by nový díl nebo
        přibylý zdroj kontrola uviděla až dlouho po tom, co existuje. Ostatní vlákna
        (výpisy, přehrávání) jedou z cache dál jako dřív; co se stáhne čerstvě, uloží se."""
        old = getattr(self._local, "cap", None)
        self._local.cap = (max(0, int(max_age)), tuple(prefixes))
        try:
            yield
        finally:
            self._local.cap = old

    def cached_if(self, key, ttl, loader, ok=bool, fresh=False):
        """Jako `cached()`, ale na disk zapíše jen když `ok(data)` je pravda — pro
        věci, co se mají zapamatovat jen při úspěchu (např. nalezené streamy),
        ne prázdný/neúspěšný výsledek, který má jít zkusit znovu hned příště.
        `fresh=True` cache jen zapíše, nečte (zahřívání na pozadí obnoví, co už tam je)."""
        # nezávislé na self._cache (soubor per hash klíče) — nepotřebuje self._lock.
        # Souběh nad týmž klíčem drží zámek per klíč: dřív se při něm stáhlo dvakrát
        # totéž, což u jednoho uživatele nevadilo, ale na serveru Stremia otevře nový
        # populární titul padesát lidí naráz a každý by šel na TMDB, HellSpy i pro
        # hlavičky souborů sám. Napřed se čte bez zámku (běžný případ, cache platná),
        # zámek se bere až při chybějícím záznamu a pod ním se čte ještě jednou.
        cap = getattr(self._local, "cap", None)
        if cap is not None and (not cap[1] or key.startswith(cap[1])):
            ttl = min(ttl, cap[0])
            fresh = fresh or ttl <= 0
        path = os.path.join(self.cache_dir, "cache", hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")
        if not fresh:
            data = self._read_cached(path, ttl)
            if data is not _MISSING:
                return data
        entry = self._key_lock(path)
        try:
            with entry[0]:
                if not fresh:
                    data = self._read_cached(path, ttl)
                    if data is not _MISSING:
                        return data
                # Kdo čekal na zámek, dostane to, co mezitím stáhl ten první — i když to
                # neprošlo `ok()` a na disk se nezapsalo. Bez toho by čekající po neúspěchu
                # spouštěli loader jeden po druhém: při výpadku Wikidat by pět zdrojů
                # čekalo 5 × 10 s za sebou místo 10 s naráz jako před zámkem (CI 3.8 to
                # ukázalo na `test_pomaly_zdroj_neblokuje_ostatni`, 4,8 → 12,4 s).
                if entry[2] is not _MISSING:
                    return entry[2]
                data = entry[2] = loader()
                if not ok(data):
                    return data
                tmp = self._tmp(path)
                try:
                    with open(tmp, "w", encoding="utf-8") as f:
                        json.dump(data, f, ensure_ascii=False)
                    os.replace(tmp, path)
                except (OSError, TypeError, ValueError):
                    # zápis do cache je bonus: plný disk i data, která nejdou serializovat (`set`), nesmí
                    # shodit hledání, na které se čeká (Office 2026-10-01: TypeError z částečného seznamu)
                    try:
                        os.remove(tmp)
                    except OSError:
                        pass
                return data
        finally:
            self._key_unlock(path, entry)

    def capped(self, key):
        """Platí ve vlákně `fresher()` omezení stáří i pro tenhle klíč? (`cached_if`, `peek_cached`)"""
        cap = getattr(self._local, "cap", None)
        return cap is not None and (not cap[1] or key.startswith(cap[1]))

    def cap_ttl(self, key, ttl):
        """`ttl` zkrácené omezením `fresher()` tohohle vlákna (bez něj beze změny)."""
        return min(ttl, self._local.cap[0]) if self.capped(key) else ttl

    @staticmethod
    def _read_cached(path, ttl):
        try:
            if time.time() - os.path.getmtime(path) < ttl:
                with open(path, encoding="utf-8") as f:
                    return json.load(f)
        except (OSError, ValueError):
            pass
        return _MISSING

    def _key_lock(self, path):
        """Zámek na jeden klíč cache; položka `[RLock, počet držitelů, výsledek]` zmizí,
        jakmile ji nikdo nedrží — jinak by slovník rostl s každým kdy použitým klíčem
        a výsledek by přežil do dalšího, nesouvisejícího volání. RLock, ne Lock: loader
        smí (byť neměl) sáhnout na tentýž klíč znovu."""
        with self._key_locks_guard:
            entry = self._key_locks.get(path)
            if entry is None:
                entry = self._key_locks[path] = [threading.RLock(), 0, _MISSING]
            entry[1] += 1
            return entry

    def _key_unlock(self, path, entry):
        with self._key_locks_guard:
            entry[1] -= 1
            if entry[1] <= 0:
                self._key_locks.pop(path, None)

    def peek_cached(self, key, ttl):
        """Vrátí, co pro `key` uložil `cached()`/`cached_if()`, jen když je to ještě
        v `ttl` — beze spuštění loaderu. Pro rozhodnutí předem (bez placení ceny
        výpočtu), jestli je něco vůbec připravené, např. než se nabídne drahý
        přepočet uživateli ke schválení místo automatického spuštění.

        Ve vlákně `fresher()` platí i tady jeho omezení stáří (jako u `cached_if`)."""
        ttl = self.cap_ttl(key, ttl)
        if ttl <= 0:
            return None
        path = os.path.join(self.cache_dir, "cache", hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")
        try:
            if time.time() - os.path.getmtime(path) < ttl:
                with open(path, encoding="utf-8") as f:
                    return json.load(f)
        except (OSError, ValueError):
            pass
        return None

    def clear_cache(self):
        cdir = os.path.join(self.cache_dir, "cache")
        for name in os.listdir(cdir):
            try:
                os.remove(os.path.join(cdir, name))
            except OSError:
                pass

    def prune_cache(self, max_age=31 * 86400, max_bytes=120 * 1024 * 1024):
        """Smaže soubory cache starší než `max_age` a pak nejstarší, dokud cache nepřesahuje
        `max_bytes`. TTL se hlídá jen při čtení, takže prošlé záznamy (hledání, streamy,
        katalogy) dřív ležely na disku navždy; v HA v `.storage`, tedy i v každé záloze.
        Vrací počet smazaných.

        31 dní, ne 72 h: soubory jsou pojmenované podle hashe klíče, takže se TTL
        jednotlivých záznamů nedá zjistit — a nejdelší z nich (hlavičky souborů, detail
        titulu z TMDB) platí 30 dní. Dřívější hranice 72 h tyhle záznamy mazala po třech
        dnech a každé další otevření titulu je pak četlo znovu ze sítě. Prošlé záznamy
        mezitím nepřekáží, strop velikosti hlídá, aby cache nerostla."""
        cdir = os.path.join(self.cache_dir, "cache")
        hranice = time.time() - max_age
        smazano = 0
        zbyva = []   # (mtime, velikost, cesta) toho, co přežilo stáří
        try:
            with os.scandir(cdir) as it:
                polozky = list(it)
        except OSError:
            return 0
        for entry in polozky:
            try:
                st = entry.stat()
                if st.st_mtime < hranice:
                    os.remove(entry.path)
                    smazano += 1
                else:
                    zbyva.append((st.st_mtime, st.st_size, entry.path))
            except OSError:
                pass
        celkem = sum(size for _mtime, size, _path in zbyva)
        for _mtime, size, path in sorted(zbyva):   # nejstarší první
            if celkem <= max_bytes:
                break
            try:
                os.remove(path)
                celkem -= size
                smazano += 1
            except OSError:
                pass
        return smazano



class Index:
    """Snímky z rejstříku Sosáče (`idx:<id>`) ve vlastním souboru `sosac_index.json`.

    Dřív šly do `items.json` vedle snímků pro Pokračovat / Můj seznam. Jenže rejstřík
    zapisuje každý výpis katalogu Sosáče — stovky položek z procesu, který si soubor
    načetl při svém startu. Jeho zápis pak přepsal snímek, který mezitím uložilo
    přehrávání v jiném procesu, a rozkoukaný titul se v Pokračovat ve sledování
    neukázal (Office 2026-09-13: 1168 z 1192 záznamů v items.json byl rejstřík,
    „rozkoukáno tt38061210" bez snímku). Vlastní soubor drží `items.json` malý
    a psaný jen z uživatelských akcí; staré `idx:` záznamy se odsud jednou odstěhují.
    """

    def __init__(self, store, name="sosac_index", files=None):
        # žádné čtení ani zápis souboru tady: `Engine.sources()` zakládá SosacDirect
        # (a tím rejstřík) i z atributů senzoru HA, tedy ve smyčce událostí, kde HA
        # blokující `open()` hlásí jako chybu. Stěhování proběhne až při prvním použití.
        self.store = store
        # kde leží soubor rejstříku (`Store.cache_dir`); `store` dál drží items.json
        self.files = files or store
        self.name = name
        self._migrated = False

    def _migrate(self):
        if self._migrated:
            return
        self._migrated = True
        with self.store._lock:
            items = self.store.load("items", {})
            old = [k for k in items if k.startswith("idx:")]
            if not old:
                return
            data = self.files.load(self.name, {})
            for k in old:
                data.setdefault(k, items.pop(k))
            self.files.save(self.name, data)
            self.store.save("items", items)

    def remember_item(self, key, info):
        self.remember_items({key: info})

    def remember_items(self, items):
        """Celý výpis jedním zápisem. Soubor má přes megabajt a zápis po položkách
        znamenal u seznamu 47 filmů 47× načíst a uložit celý rejstřík — na Office
        (32bit ARM) 45 s místo dvou (2026-09-14)."""
        if not items:
            return
        self._migrate()
        with self.store._lock:
            data = self.files.load(self.name, {})
            ts = int(time.time())
            changed = False
            for key, info in items.items():
                info = dict(info)
                old = data.get(str(key))
                # opakované otevření téhož seznamu nic nového nepřinese — bez zápisu;
                # razítko se obnoví jen jednou za den, aby `_trim` nevyhodil živé tituly
                if old and ts - old.get("ts", 0) < INDEX_REFRESH and \
                        {k: v for k, v in old.items() if k != "ts"} == json.loads(json.dumps(info)):
                    continue
                info["ts"] = ts
                data[str(key)] = info
                changed = True
            if not changed:
                return
            self.store._trim(data, INDEX_MAX)
            self.files.save(self.name, data)

    def item(self, key):
        """`idx:` klíče z rejstříku; ostatní (snímek přehraného titulu, ze kterého
        `SosacDirect.meta()` skládá meta neznámého filmu) z `items.json`."""
        self._migrate()
        with self.store._lock:
            snap = self.files.load(self.name, {}).get(str(key))
            if snap is None and not str(key).startswith("idx:"):
                snap = self.store.item(key)
            return snap
